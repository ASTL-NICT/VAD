/*-----------------------------------------------------------------------------
 NICTASREngine Application Implementation
-------------------------------------------------------------------------------
 Copyright (C) 2012 - 2016
   National Institute of Information and Communications Technology.
   All rights reserved.
-----------------------------------------------------------------------------*/

#ifdef WIN32
#ifdef _DEBUG
#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>
#endif
#endif

#include "NICTASREngine.hpp"

static bool LoopFlag = false ;

int main(int argc, char* argv[])
{
  #ifdef WIN32
  #ifdef _DEBUG
      _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
      _crtBreakAlloc = 233 ;
  #endif
  #endif

  const char *ver="V302";

  const char *name="NICTmmcv";

  // FROMAT_ARGLIST FROMAT_ARGNHLIST 時に使用
  // 引数に設定ファイル以外があれば、ArgFileList に設定する
  std::vector<std::string>   ArgFileList;

  // 引数のチェック
  if( argc < 2 ) {

    fprintf( stderr, "The settings file is not specified.\n" ) ;

    // 使用方法を表示して終了する
    fprintf( stderr, "-----------------------------------------------------------------\n" ) ;
    fprintf( stderr, "%s [%s %s %s]\n",name,ver,__DATE__,__TIME__);
    fprintf( stderr, "usage： %s <IniFileName> [data-file...]\n\n",name ) ;
    fprintf( stderr, "  option：\n" ) ;
    fprintf( stderr, "   <IniFileName> : The settings file name is specified. \n" ) ;
    fprintf( stderr, "-----------------------------------------------------------------\n" ) ;
    exit(1) ;
  } else if ( argc > 2 ) {
    for ( int i = 2 ; i < argc ; i++ ) {
      ArgFileList.push_back(argv[i]);
    }
  }

#ifdef _WIN32
  // ソケット初期化
  WSADATA wsaData;
  if( WSAStartup(MAKEWORD(1,1), &wsaData) != 0 ){
    fprintf( stderr, "Winsock initialization has failed.\n" ) ;
    exit( 1 ) ;
  }
#endif
  // 設定情報読み込み処理
  NICTASREngineConfigure *Config = new NICTASREngineConfigure();
  if( Config->ReadIniFile( argv[1], ArgFileList ) ) {

    // 初期化処理
    NICTSpeechRex *SR = (NICTSpeechRex*)new NICTSpeechRex() ;
    if( !SR->Initialize(
			Config->ModuleRoutingTable,
			Config->inputFormatId,
			Config->outputFormatId,
			Config->SignalConfig,
			Config->FilterConfig,
			Config->TimeStamp,
			Config->UseMemory,
			Config->convertFeatureOrder
			) ) {
      // 初期化完了
      fprintf( stderr, "Initialization is complete.\n" ) ;
      // 入出力サイズ取得
      int InSize1, InSize2 ;
      int OutSize1, OutSize2 ;
      SR->GetInputSize( InSize1, InSize2 ) ;
      SR->GetOutputSize( OutSize1, OutSize2 ) ;
      // 入出力インスタンス生成処理
      NICTASREngineDataFile InputFile ;
      NICTASREngineDataFile OutputFile ;

      // 入出力ファイルのオープン処理
      if( InputFile.OpenFile( false, Config->inputFd.c_str(), Config->inputFormatId, InSize1, InSize2, Config->inputEndianId ) == true ) {
	if( OutputFile.OpenFile( true, Config->outputFd.c_str(), Config->outputFormatId, OutSize1, OutSize2, Config->outputEndianId ) == true ) {
	  int status = SR_SUCCESS ;
	  string result ;
	  int InBufSize   = InputFile.GetIOBufferSize() ;
	  int OutBufSize  = OutputFile.GetIOBufferSize() ;
	  char *INBuffer  = InputFile.GetIOBuffer() ;
	  char *OUTBuffer = OutputFile.GetIOBuffer() ;
	  // 割り込み設定
	  signal( SIGINT, sigint );
	  // 開始
	  SR->Start() ;
	  // データ入出力(ループ)
	  LoopFlag = true;
	  int stat ;

	  while( LoopFlag ) {

	    // データ読み込み(EOFならループを抜ける)
	    if( (stat=InputFile.ReadData( InBufSize, INBuffer )) == -1 ) {

	      // 次のデータファイルがあるならオープンし処理の初期化を行う
	      if ( Config->SetNextList() ) {
		InputFile.CloseFile() ;
		int InSize1, InSize2 ;
		SR->GetInputSize( InSize1, InSize2 ) ;
		if(! InputFile.OpenFile( false, Config->inputFd.c_str(), Config->inputFormatId, InSize1, InSize2, Config->inputEndianId ) == true ) {
		  status = SR_SUCCESS ;
		  break ;
		}
		// バッファの再取得
	        InBufSize = InputFile.GetIOBufferSize() ;
                INBuffer = InputFile.GetIOBuffer() ;
		// 処理の終了と初期化
		SR->End();
		SR->Start();
		continue ;
	      }

	      status = SR_SUCCESS ;
	      break ;
	    }

	    if( stat == 0 ) continue ;
	    // データ処理依頼
	    status = SR->SetInputData( InBufSize, INBuffer ) ;
	    if( status == SR_FAILURE ) {
	      fprintf( stderr, "An error occurred during SR processing.\n" ) ;
	      break ;
	    }

	    // 出力データ取得
	    do {
	      status = SR->GetOutputData( OutBufSize, OUTBuffer, result ) ;
              if( status == SR_NOT_EMPTY ) {
                // データ書き出し
                if( OutputFile.WriteData( OutBufSize, OUTBuffer ) != OutBufSize ) {
                  // 書き出しエラー
                  fprintf( stderr, "Output data export has failed.\n" ) ;
                  status = SR_FAILURE ;
                  break ;
                }
              }
	    } while( status == SR_NOT_EMPTY ) ;
	    // エラーならループを抜ける
	    if( status == SR_FAILURE ) LoopFlag = false ;
	  }
	  // ループエンド
	  if( status == SR_SUCCESS ) {
	    // 終了
	    SR->End() ;
	    // 出力データをすべて取り出して、書き出す。
	    status = SR_NOT_EMPTY ;
	    while( status == SR_NOT_EMPTY ) {
	      // 出力データ取得
	      status = SR->GetOutputData( OutBufSize, OUTBuffer, result ) ;
              if( status == SR_NOT_EMPTY ) {
                // データ書き出し
                if( OutputFile.WriteData( OutBufSize, OUTBuffer ) != OutBufSize ) {
                  // 書き出しエラー
                  fprintf( stderr, "Output data export has failed.\n" ) ;
                  status = SR_FAILURE ;
                  break ;
                }
              }
	    }
	  }
	  // ファイルクローズ処理
	  OutputFile.CloseFile() ;
	}
	InputFile.CloseFile() ;
      }
    }
    delete SR ;
  }
  delete Config ;
#ifdef _WIN32
  // Clean up Winsock
  if(WSACleanup() == SOCKET_ERROR) {
    fprintf( stderr, "Winsock cleanup has failed.\n");
  }
#endif
  exit( 0 );
}

// 割り込み
void sigint( int dummy )
{
  // ループフラグリセット
  LoopFlag = false ;
}
