/*-----------------------------------------------------------------------------
 NICT ASR Engine Configure Class Implementation
-------------------------------------------------------------------------------
 Copyright (C) 2012 - 2016
   National Institute of Information and Communications Technology.
   All rights reserved.
-----------------------------------------------------------------------------*/

#include "NICTASREngineConfigure.hpp"
#include "NICTSpeechRexDefine.h"
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

using namespace std;

// コンストラクタ
NICTASREngineConfigure::NICTASREngineConfigure()
{
  inputFd   = "stdin" ;
  outputFd  = "stdout" ;
  TimeStamp = false ;
  UseMemory = false ;
  ModuleRoutingTable.clear();
  convertFeatureOrder.clear();

  ListPosition = 0 ;
}

// デストラクタ
NICTASREngineConfigure::~NICTASREngineConfigure()
{
}

int NICTASREngineConfigure::ModuleName2ModuleNo(std::string name)
{
  // モジュール名をモジュールIDに変換する
  // return >=0 : module no.
  // return <0  : error

  if( !name.compare(MODULE_NICTMMSE) ) {
    return ID_MODULE_NICTMMSE ;
  }
  else if( !name.compare(MODULE_NICTMFCC) ) {
      return ID_MODULE_NICTMFCC ;
    }
    else if( !name.compare(MODULE_NICTCMS) ) {
      return ID_MODULE_NICTCMS ;
    }
    else if( !name.compare(MODULE_NICTVAD) ) {
      return ID_MODULE_NICTVAD ;
    }
    fprintf( stderr, "There is an module specification error[%s].\n",name.c_str() ) ;
    return -1;
  }


  // 設定ファイル読み込み処理
  bool NICTASREngineConfigure::ReadIniFile( const char *IniFileName, std::vector<std::string> ArgFileList )
  {
    string module_lists="";
    // 指定ファイルをオープンする
    ifstream iniFile( IniFileName ) ;

    if( !iniFile.is_open() ) {
      fprintf( stderr, "The settings file could not be opened.\n" ) ;
      return false ;
    }
    // 設定ファイルより必要な情報を読み込む
    char buf[1001];
    string inputFormat, inputOrder ;
    string outputFormat, outputOrder ;
    while( !iniFile.eof() ) {
      iniFile.getline( buf, 1000 ) ;
      if( buf[0] == '#' || buf[0] == ' ' || buf[0] == 0x00 ) continue ;
      // 項目名チェック
      if( !strncmp( buf, ITEM_INPUTFORMAT, strlen(ITEM_INPUTFORMAT) ) ) {
	inputFormat = &buf[strlen(ITEM_INPUTFORMAT)] ;
      }
      else if( !strncmp( buf, ITEM_INPUTBYTEORDER, strlen(ITEM_INPUTBYTEORDER) ) ) {
	inputOrder = &buf[strlen(ITEM_INPUTBYTEORDER)] ;
      }
      else if( !strncmp( buf, ITEM_OUTPUTFORMAT, strlen(ITEM_OUTPUTFORMAT) ) ) {
	outputFormat = &buf[strlen(ITEM_OUTPUTFORMAT)] ;
      }
      else if( !strncmp( buf, ITEM_OUTPUTBYTEORDER, strlen(ITEM_OUTPUTBYTEORDER) ) ) {
	outputOrder = &buf[strlen(ITEM_OUTPUTBYTEORDER)] ;
      }
      else if( !strncmp( buf, ITEM_INPUTFD, strlen(ITEM_INPUTFD) ) ) {
	inputFd = &buf[strlen(ITEM_INPUTFD)] ;
      }
      else if( !strncmp( buf, ITEM_OUTPUTFD, strlen(ITEM_OUTPUTFD) ) ) {
	outputFd = &buf[strlen(ITEM_OUTPUTFD)] ;
      }
      else if( !strncmp( buf, ITEM_SIGNALPROCESSINGCONFIGFILE, strlen(ITEM_SIGNALPROCESSINGCONFIGFILE) ) ) {
	SignalConfig = &buf[strlen(ITEM_SIGNALPROCESSINGCONFIGFILE)] ;
      }
      else if( !strncmp( buf, ITEM_TIMESTAMP, strlen(ITEM_TIMESTAMP) ) ) {
	if( !strcmp( &buf[strlen(ITEM_TIMESTAMP)], "ON" ) ) TimeStamp = true ;
      }
      else if( !strncmp( buf, ITEM_USEMEMORY, strlen(ITEM_USEMEMORY) ) ) {
	if( !strcmp( &buf[strlen(ITEM_USEMEMORY)], "ON" ) ) UseMemory = true ;
      }
      else if( !strncmp( buf, ITEM_CONVERTFEATUREORDER, strlen(ITEM_CONVERTFEATUREORDER) ) ) {
	// 特徴ベクトルのindexを並べ替える数列を読み込む -> convertFeatureOrder
	char *buf2=(char*)malloc(strlen(buf)-strlen(ITEM_CONVERTFEATUREORDER)+1);
	if (buf2==NULL) return false; // error(no memory)
	{
	  char *c=buf+strlen(ITEM_CONVERTFEATUREORDER);
	  strcpy(buf2,c);
	}
	convertFeatureOrder.clear();
	char *c=strtok(buf2,",");
	while (c!=NULL) {
	  convertFeatureOrder.push_back(atoi(c));
	  c=strtok(NULL,",");
	}
	free(buf2);
      }
      else if( !strncmp( buf, ITEM_MODULEROUTINGTABLE, strlen(ITEM_MODULEROUTINGTABLE) ) ) {
	// 特徴量計算モジュールの接続テーブルを読み込む -> ModuleRoutingTable
	char *buf2=(char*)malloc(strlen(buf)-strlen(ITEM_MODULEROUTINGTABLE)+1);
	if (buf2==NULL) return false; // error(no memory)
	{
	  char *c=buf+strlen(ITEM_MODULEROUTINGTABLE);
	  strcpy(buf2,c);
	}
	ModuleRoutingTable.clear();
	char *c=strtok(buf2,",");
	while (c!=NULL) {
	  int no=ModuleName2ModuleNo(string(c));
	  if (no>=0) {
	    ModuleRoutingTable.push_back((unsigned char)no);
	  } else {
	    fprintf(stderr,"FATAL[NICTASR]: module name(%s) is not valid.\n",c);
	    return false;
	  }
	  if (module_lists=="") {
	    module_lists=string(c);
	  } else {
	    module_lists+="->"+string(c);
	  }
	  c=strtok(NULL,",");
	}
	free(buf2);
      }
    }
    // 設定ファイルをクローズする。
    iniFile.close() ;

    // 入力データフォーマット
    // フォーマット名をフォーマットIDに変換する
    if( inputFormat.empty() || !inputFormat.compare(FROMAT_FRAMESYNC) ) {
      inputFormatId = ID_FORMAT_FRAMESYNC ;
    }
    else if( !inputFormat.compare(FROMAT_NOHEADER) ) {
      inputFormatId = ID_FORMAT_NOHEADER ;
    }
    else if( !inputFormat.compare(FROMAT_WAVFILE) ) {
      inputFormatId = ID_FORMAT_WAVFILE ;
    }
    else if( ( !inputFormat.compare(FROMAT_WAVLIST) ) ||
	     ( !inputFormat.compare(FROMAT_NHLIST) ) ) {
      if( !inputFormat.compare(FROMAT_WAVLIST) ) {
	inputFormatId = ID_FORMAT_WAVFILE ;
      } else {
	inputFormatId = ID_FORMAT_NOHEADER ;
      }
      if ( !GetWaveList(inputFd.c_str()) ) {
	fprintf( stderr, "There is an input file specification error.\n" ) ;
	return false ;
      }
      SetNextList();
    }
    else if( ( !inputFormat.compare(FROMAT_ARGLIST) ) ||
	     ( !inputFormat.compare(FROMAT_ARGNHLIST) ) ) {
      if( !inputFormat.compare(FROMAT_ARGLIST) ) {
	inputFormatId = ID_FORMAT_WAVFILE ;
      } else {
	inputFormatId = ID_FORMAT_NOHEADER ;
      }
      WaveFileList = ArgFileList ;
      SetNextList();
    }
    else {
      fprintf( stderr, "There is an input data format specification error.\n" ) ;
      return false ;
    }

    fprintf(stderr,"INFO[NICTASR(pid=%d)]: ModuleRoutingTable: input->%s->output\n",getpid(),module_lists.c_str());

    // 入力モジュールと入力データフォーマットの組み合わせチェック
    if( inputFormatId == ID_FORMAT_WAVFILE ) {
      if( ModuleRoutingTable.front() == ID_MODULE_NICTCMS || ModuleRoutingTable.front() == ID_MODULE_NICTVAD ) {
	fprintf( stderr, "There is an input module and input data format compatibility error.\n" ) ;
	return false ;
      }
      // 入力バイトオーダを強制的にLittleにする
      inputOrder = ENDIAN_LITTLE ;
    }

    // 入力バイトオーダ
    if( inputOrder.empty() ) {
      inputEndianId = ID_ENDIAN_BIG ;
    }
    else {
      if( !inputOrder.compare(ENDIAN_LITTLE) ) inputEndianId = ID_ENDIAN_LITTLE ;
      else if( !inputOrder.compare(ENDIAN_BIG) ) inputEndianId = ID_ENDIAN_BIG ;
      else {
	fprintf( stderr, "There is a input byte order specification error.\n" ) ;
	return false ;
      }
    }

    // フォーマット名をフォーマットIDに変換する
    if( outputFormat.empty() ) {
        outputFormatId = ID_FORMAT_FRAMESYNC ;
    }
    else if( !outputFormat.compare(FROMAT_FRAMESYNC) ) {
        outputFormatId = ID_FORMAT_FRAMESYNC ;
    }
    else if( !outputFormat.compare(FROMAT_NOHEADER) ) {
        outputFormatId = ID_FORMAT_NOHEADER ;
    }
    else {
        fprintf( stderr, "There is a output data format specification error.\n" ) ;
        return false ;
    }
    // 出力モジュールと出力データフォーマットの組み合わせチェック
    if( (outputFormatId != ID_FORMAT_FRAMESYNC) && (outputFormatId != ID_FORMAT_NOHEADER) ) {
      fprintf( stderr, "There is an output module and output data format compatibility error.\n" ) ;
      return false ;
    }
    // 出力バイトオーダ
    if( outputOrder.empty()) {
      outputEndianId = ID_ENDIAN_BIG ;
    }
    else {
      if( !outputOrder.compare(ENDIAN_LITTLE) ) outputEndianId = ID_ENDIAN_LITTLE ;
      else if( !outputOrder.compare(ENDIAN_BIG) ) outputEndianId = ID_ENDIAN_BIG ;
      else {
	fprintf( stderr, "There is an output byte order specification error.\n" ) ;
	return false ;
      }
    }
    // 入力ファイル指定
    if( inputFd.empty() ) {
      fprintf( stderr, "The input file is not specified.\n" ) ;
      return false ;
    }
    if( !inputFd.compare( "stdout" ) || !inputFd.compare( "stderr" ) ) {
      fprintf( stderr, "There is an input file specification error.\n" ) ;
      return false ;
    }
    // 出力ファイル指定
    if( outputFd.empty() ) {
      fprintf( stderr, "The output file is not specified.\n" ) ;
      return false ;
    }
    if( !outputFd.compare( "stdin" ) || !outputFd.compare( "stderr" ) ) {
      fprintf( stderr, "There is an output file specification error.\n" ) ;
      return false ;
    }
    // 設定ファイル指定のチェック
    if( SignalConfig.empty() ) {
      fprintf( stderr, "The file for acoustic analysis settings is not specified.\n" ) ;
      return false ;
    }
    return true ;
  }

  // 音声ファイルリストの読み込み
  bool NICTASREngineConfigure::GetWaveList( const char *ListFile )
  {
    ListPosition = 0 ;
    ifstream WLFile( ListFile ) ;

    if( !WLFile.is_open() ) {
      fprintf( stderr, "Wave list file could not be opened.\n" ) ;
      return false ;
    }

    char buf[2049];
    while( !WLFile.eof() ) {
      WLFile.getline( buf, 2048 ) ;
      if( buf[0] == '#' || buf[0] == ' ' || buf[0] == 0x00 ) continue ;
      WaveFileList.push_back(buf);
    }

    WLFile.close() ;

    if ( WaveFileList.empty() ) {
      fprintf( stderr, "Wave list file is empty.\n" ) ;
      return false ;
    }

    return true ;
  }

  // 次の音声ファイルをinputFdに設定する
  bool NICTASREngineConfigure::SetNextList()
  {
    if ( ListPosition >= (int)WaveFileList.size() ) {
      inputFd = "";
      return false ;
    }

    inputFd = WaveFileList[ListPosition];
    ListPosition++ ;

    return true ;
  }
