/*-----------------------------------------------------------------------------
 NICT ASR Engine Data File Class Implementation
-------------------------------------------------------------------------------
 Copyright (C) 2012 - 2016
   National Institute of Information and Communications Technology.
   All rights reserved.
-----------------------------------------------------------------------------*/

#include "NICTASREngineDataFile.hpp"
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

using namespace std;

// コンストラクタ
NICTASREngineDataFile::NICTASREngineDataFile()
{
  Fd = -1 ;
  childFd = -1 ;
  // マシンのバイトオーダを調べる
  int a = 1 ;
  int b = ntohl( a ) ;
  MachineEndian = (a==b) ? ID_ENDIAN_BIG : ID_ENDIAN_LITTLE ;
  // 入出力バッファ
  IOBuffer = NULL ;
  // 初期化
  PortNumber = -1 ;
}

// デストラクタ
NICTASREngineDataFile::~NICTASREngineDataFile()
{
  // ファイルクローズ
  CloseFile() ;
  // バッファ解放
  if( IOBuffer ) free( IOBuffer );
}

void NICTASREngineDataFile::SkipWavHeader() {
  char buf[36] ;
  ReadData( 36, buf ) ;

  if (*(int *)(buf + 16) == 16) {
    ReadData( 8, buf ) ; // 8 = 44 - 36;
  } else {
    int rest_size = 8 + 2 + *(short *)(buf + 36);
    char *tmp = new char [rest_size];
    ReadData( rest_size, tmp ) ;
    delete [] tmp;
  }
}

// ファイルオープン処理
bool NICTASREngineDataFile::OpenFile( bool mode, const char *filename, unsigned char format, int size1, int size2, unsigned char order )
{
  // 指定値設定
  Mode        = mode ;
  FileName    = filename ;
  FormatID    = format ;
  BytePerSize = size1 ;
  DataSize    = size2 ;
  DataEndian  = order ;

  // 特別なファイルか調べる
  if( !strcmp( filename, "stdin" ) ) {
    if( mode == true ) {
      fprintf( stderr, "There is an output file specification error.\n" ) ;
      return false ;
    }
    Fd = 0 ;

    // WAVファイルの場合、ヘッダー領域を読み飛ばす処理を行う
    if( format == ID_FORMAT_WAVFILE ) {
      SkipWavHeader();
    }
  }
  else if( !strcmp( filename, "stdout" ) ) {
    if( mode == false ) {
      fprintf( stderr, "There is an input file specification error.\n" ) ;
      return false ;
    }
    Fd = 1 ;
#ifdef WIN32
    StdoutMode = _setmode(_fileno(stdout), _O_U16TEXT) ;
#endif
  }
  else if( !strcmp( filename, "stderr" ) ) {
    fprintf( stderr, "Stderr could not be assigned to the input/output file(s) \n" ) ;
    return false ;
  }
  else if( !strncmp( filename, "socket(", 7 ) ) {
    // ソケット
    // host名とポート番号をパースする
    string tmp = filename ;
    int pos1 = (int)tmp.find(":") ;
    int pos2 = (int)tmp.find(")") ;
    if( pos2 != (int)tmp.npos ) {
      if( pos1 != (int)tmp.npos ) {
        HostName = tmp.substr(7,pos1-7) ;
        PortNumber = atoi(tmp.substr(pos1+1, pos2-pos1).c_str());
      }
      else {
        HostName.clear() ;
        PortNumber = atoi(tmp.substr(7, pos2).c_str());
      }
    }
    else {
      fprintf( stderr, "There is a socket specification error.\n" ) ;
      return false ;
    }
    // ソケットをオープンする
    int option = 1;
    struct sockaddr_in addr;
    struct hostent     *host ;

    memset( (char *)&addr, 0, sizeof(addr) ) ;
    addr.sin_family      = AF_INET ;
    addr.sin_port        = htons( PortNumber ) ;
    addr.sin_addr.s_addr = INADDR_ANY ;
    // ソケットテーブル
    FD_ZERO( &SockTBL );
    // ホスト名の有無でサーバ/クライアントを判断する
    if( HostName.empty() ) {
      // サーバソケット
      Fd = (int)socket( AF_INET, SOCK_STREAM, 0 ) ;
      if( Fd < 0 ) {
        fprintf( stderr, "The socket could not be created.\n" ) ;
        return false ;
      }
      FD_SET( Fd, &SockTBL );
      // ソケットオプション
      setsockopt( Fd, SOL_SOCKET, SO_REUSEADDR, (const char*)&option, sizeof(int) ) ;
      // bind
      if( bind( Fd, (struct sockaddr*)&addr, sizeof(addr) ) == -1 ) {
        fprintf( stderr, "The socket could not be created.\n" ) ;
        return false ;
      }
      // listen
      if( listen( Fd, SOMAXCONN ) == -1 ) {
        fprintf( stderr, "The socket could not be created.\n" ) ;
        return false ;
      }
      // 30秒間接続を待つ
      fprintf( stderr, "Waiting for connection.\n" ) ;
      struct timeval timeout;
      timeout.tv_sec  = 0;
      timeout.tv_usec = 100000;
      int count  = 300 ;
      fd_set ActiveTBL ;
      while( 1 ) {
        ActiveTBL = SockTBL ;
        if( select( FD_SETSIZE, &ActiveTBL, NULL, NULL, &timeout ) > 0 ) {
          if( FD_ISSET( Fd, &ActiveTBL ) ) {
            sockaddr_in newAddr ;
            socklen_t len = sizeof(newAddr) ;
            childFd = accept( Fd, (sockaddr*)&newAddr, &len ) ;
            if( childFd < 0 ) {
              fprintf( stderr, "Could not connect to the socket.\n" ) ;
              return false ;
            }
            // 新しいソケットのみをテーブルに設定する
            FD_ZERO( &SockTBL );
            FD_SET( childFd, &SockTBL ) ;
            //
            fprintf( stderr, "Connection established.\n" ) ;
            break ;
          }
        }
#ifndef WIN32
        usleep(100000) ;
#endif
        count-- ;
      }
      if( count == 0 )  {
        // 接続エラー(タイムアウト)
        fprintf( stderr, "Could not establish a connection within the specified length of time.\n" ) ;
        return false ;
      }
    }
    else {
      // クライアントソケット
      host = gethostbyname( HostName.c_str() ) ;
      if( host == NULL ) {
        fprintf( stderr, "The host name is incorrect.\n" ) ;
        return false ;
      }
      memmove( (char*)&addr.sin_addr, host->h_addr, host->h_length ) ;
      // ソケット生成
      Fd = (int)socket( host->h_addrtype, SOCK_STREAM, 0 ) ;
      if( Fd < 0 ) {
        fprintf( stderr, "The socket could not be created.\n" ) ;
        return false ;
      }
      FD_SET( Fd, &SockTBL );
      // ソケットオプション
      setsockopt( Fd, SOL_SOCKET, SO_REUSEADDR, (const char*)&option, sizeof(int) ) ;
      // 接続
      if( connect( Fd, (struct sockaddr*)&addr, sizeof(addr)) < 0 ) {
        fprintf( stderr, "Could not connect to the socket.\n" ) ;
        return false ;
      }
    }
  }
  else {
    // 通常のファイルと見なす
    if( Mode ) {
      // 出力ファイル
#ifdef WIN32
      // FRAMESYNC及びNOHEADERはバイナリ―でオープンする
      if( (format == ID_FORMAT_FRAMESYNC) || (format == ID_FORMAT_NOHEADER) ) {
        _sopen_s( &Fd, filename, O_WRONLY | O_CREAT | O_TRUNC | O_BINARY,_SH_DENYRW,  _S_IREAD | _S_IWRITE );
      }
      else {
        _sopen_s( &Fd, filename, O_WRONLY | O_CREAT | O_TRUNC,_SH_DENYRW,  _S_IREAD | _S_IWRITE );
      }
#else
      Fd = open( filename, O_WRONLY | O_CREAT | O_TRUNC, (mode_t)0644 );
#endif
      if( Fd == -1 ) {
        fprintf( stderr, "The output file could not be opened.\n" ) ;
        return false ;
      }
    }
    else {
      // 入力ファイル
#ifdef WIN32
      // テキストファイルはないのでバイナリでオープンする
      _sopen_s( &Fd, filename, O_RDONLY | O_BINARY, _SH_DENYRW, _S_IREAD );
#else
      Fd = open( filename, O_RDONLY );
#endif
      if( Fd == -1 ) {
        fprintf( stderr, "The input file could not be opened.\n" ) ;
        return false ;
      }
      // WAVファイルの場合、ヘッダー領域を読み飛ばす処理を行う
      if( format == ID_FORMAT_WAVFILE ) {
        SkipWavHeader();
      }
    }
  }
  // 入出力用バッファを作成する。
  if( format == ID_FORMAT_FRAMESYNC ) BufefrSize = size1 * size2 + 4 ;
  else if( format == ID_FORMAT_NOHEADER || format == ID_FORMAT_WAVFILE ) BufefrSize = size1 * size2 ;
  else BufefrSize = 0 ; // 文字列データ
  if( BufefrSize ) {
    // IOBufferは、大きめにしておく
    IOBuffer = (char*)malloc( BufefrSize+10 ) ;
    if( IOBuffer == NULL ) {
      fprintf( stderr, "The input/output buffer could not be created.\n" ) ;
      return false ;
    }
  }
  return true ;
}

// ファイルクローズ処理
void NICTASREngineDataFile::CloseFile()
{
#ifdef WIN32
  if( Fd == -1 || Fd == 0 ) return ;
  if( Fd == 1 ) {
    _setmode(_fileno(stdout), StdoutMode ) ;
    return ;
  }
  //　ファイルがソケットかどうかをPortNumberで判断する
  if( PortNumber == -1 ) {
    // ファイル
    _close( Fd ) ;
  }
  else {
    // ソケット
    closesocket( Fd ) ;
    if( childFd != -1 ) closesocket( childFd ) ;
  }
#else
  if( Fd == -1 || Fd == 0 || Fd == 1 ) return ;
  close( Fd ) ;
  if( childFd != -1 ) close( childFd ) ;
#endif
  Fd = -1 ;
  childFd = -1 ;

  if( IOBuffer ) {
    free(IOBuffer);
    IOBuffer = NULL;
  }
}

// データ読み込み処理
int NICTASREngineDataFile::ReadData( int size, char *buf )
{
  int ret ;
  int pos = 0 ;
  int lsize = size ;

  memset( buf, 0, size ) ;
  while( lsize > 0 ) {
    // コアの受信処理を呼び出す
    ret = ReadDataCore( lsize, &buf[pos] ) ;
    if( ret < 0 ) return ret ;
    if( ret < lsize ) {
#ifdef WIN32
      Sleep(1) ;
#else
      usleep(1000) ;
#endif
    }
    lsize -= ret ;
    pos += ret ;
  }
  // Enian変換
  ConvertEndian( size, buf ) ;

  return size ;
}

// コアのデータ読み込み処理
int NICTASREngineDataFile::ReadDataCore( int size, char *buf )
{
  int    ret ;
  struct timeval timeout;

#ifdef WIN32
  if( PortNumber == -1 ) {
    ret = _read( Fd, buf, size ) ;
    if( ret == 0 ) return -1 ;
  }
  else {
    // タイムアウト設定
    timeout.tv_sec  = 0;
    timeout.tv_usec = 10000;
    // 10ミリ秒間受信待ちを行う
    ret = 0 ;
    fd_set ActiveTBL ;
    ActiveTBL = SockTBL ;
    if( select( FD_SETSIZE, &ActiveTBL, NULL, NULL, &timeout ) > 0 ) {
      if( FD_ISSET( Fd, &ActiveTBL ) ) {
        ret = recv( Fd, buf, size, 0 ) ;
      }
      else {
        ret = recv( childFd, buf, size, 0 ) ;
      }
      // ソケット切断？
      if( ret <= 0 ) return -1 ;
    }
    if( ret == 0 ) return ret ;
  }
#else
  if( PortNumber == -1 ) {
    ret = read( Fd, buf, size ) ;
    if( ret == 0 ) return -1 ;
  }
  else {
    // タイムアウト設定
    timeout.tv_sec  = 0;
    timeout.tv_usec = 10000;
    // 10ミリ秒間受信待ちを行う
    ret = 0 ;
    fd_set ActiveTBL ;
    ActiveTBL = SockTBL ;
    if( select( FD_SETSIZE, &ActiveTBL, NULL, NULL, &timeout ) > 0 ) {
      if( FD_ISSET( Fd, &ActiveTBL ) ) {
        ret = read( Fd, buf, size ) ;
      }
      else {
        ret = read( childFd, buf, size ) ;
      }
      // ソケット切断？
      if( ret <= 0 ) return -1 ;
    }

    if( ret == 0 ) return ret ;
  }
#endif
  return ret ;
}

// データ書き込み処理

int NICTASREngineDataFile::WriteData( int size, char *buf )
{
  int ret ;
  int pos = 0 ;
  int lsize = size ;

  // Enian変換
  ConvertEndian( size, buf ) ;

  while( lsize > 0 ) {
    // コアの送信処理を呼び出す
    ret = WriteDataCore( lsize, &buf[pos] ) ;
    if( ret < 0 ) return ret ;
    if( ret < lsize ) {
#ifdef WIN32
      Sleep(1) ;
#else
      usleep(1000) ;
#endif
    }
    lsize -= ret ;
    pos += ret ;
  }


  return size ;	
}


int NICTASREngineDataFile::WriteDataCore( int size, char *buf )
{
  int ret ;
  struct timeval timeout;

  // データ出力
#ifdef WIN32
  if( PortNumber == -1 ) {
    if( Fd == 1 ) {
      // UTF8をUTF16に変換する
      wstring utf16 ;
      UTF8ToUTF16( size, buf, utf16 ) ;
      wcout << utf16 << endl ;
      ret = size ;
    }
    else {
      ret = _write( Fd, buf, size ) ;
    }
  }
  else {
    // タイムアウト設定
    timeout.tv_sec  = 0;
    timeout.tv_usec = 10000;
    // 10ミリ秒間送信待ちを行う
    ret = 0 ;
    fd_set ActiveTBL ;
    ActiveTBL = SockTBL ;
    if( select( FD_SETSIZE, NULL, &ActiveTBL, NULL, &timeout ) > 0 ) {
      if( FD_ISSET( Fd, &ActiveTBL ) ) {
        // クライアントソケット
        ret = send( Fd, buf, size, 0 ) ;
      }
      else {
        // サーバソケット
        ret = send( childFd, buf, size, 0 ) ;
      }
      // ソケット切断？
      if( ret <= 0 ) return -1 ;
    }
    if( ret == 0 ) return ret ;
  }
#else
  if( PortNumber == -1 ) {
    ret = write( Fd, buf, size ) ;
  }
  else {
    // タイムアウト設定
    timeout.tv_sec  = 0;
    timeout.tv_usec = 10000;
    // 10ミリ秒間送信待ちを行う
    ret = 0 ;
    fd_set ActiveTBL ;
    ActiveTBL = SockTBL ;
    if( select( FD_SETSIZE, NULL, &ActiveTBL, NULL, &timeout ) > 0 ) {
      if( FD_ISSET( Fd, &ActiveTBL ) ) {
        // クライアントソケット
        ret = write( Fd, buf, size ) ;
      }
      else {
        // サーバソケット
        ret = write( childFd, buf, size ) ;
      }
      // ソケット切断？
      if( ret <= 0 ) return -1 ;
    }
    if( ret == 0 ) return ret ;

  }
#endif
  return ret;
}

// Endian変換処理
// データのバイトサイズは、2/4/8のみをサポート
void NICTASREngineDataFile::ConvertEndian( int size, char *buf )
{
  // Endian変換が必要か調べる
  if( DataEndian == MachineEndian ) return ;

  int     index ;
  int     *data4 ;
  short   *data2 ;

  // データフォーマットをチェックする
  if( FormatID == ID_FORMAT_FRAMESYNC ) {
    // ヘッダーは、先頭の4バイト
    data4 = (int*)&(buf[0]) ;
    *data4 = htonl( *data4 ) ;
    index = 4 ;
  }
  else index = 0 ;

  switch( BytePerSize ) {
    case 2:
      for( int i = index ; i < size ; i+=2 ) {
        data2 = (short*)&(buf[i]) ;
        *data2 = htons( *data2 ) ;
      }
      break ;
    case 4:
      for( int i = index ; i < size ; i+=4 ) {
        data4 = (int*)&(buf[i]) ;
        *data4 = htonl( *data4 ) ;
      }
      break ;
    case 8:
      for( int i = index ; i < size ; i+=8 ) {
        data4 = (int*)&(buf[i]) ;
        *data4 = htonl( *data4 ) ;
        data4 = (int*)&(buf[i+4]) ;
        *data4 = htonl( *data4 ) ;
      }
      break ;
    default:
      break ;
  }
}

// UTF8をUTF16に変換する
void NICTASREngineDataFile::UTF8ToUTF16( int size, char *buf, wstring& utf16 )
{
  utf16.clear() ;
  utf16.reserve(size) ;
  for( int i = 0; i < size ; ++i ) {
    unsigned char ch0 = buf[i];
    if( (ch0 & 0x80) == 0x00 ) {
      utf16.push_back(((ch0 & 0x7f)));
    }
    else if( (ch0 & 0xe0) == 0xc0 ) {
      unsigned char ch1 = buf[++i];
      utf16.push_back(((ch0 & 0x3f) << 6)|((ch1 & 0x3f)));
    } else {
      unsigned char ch1 = buf[++i];
      unsigned char ch2 = buf[++i];
      utf16.push_back(((ch0 & 0x0f)<<12)|((ch1 & 0x3f)<<6)|((ch2 & 0x3f)));
    }
  }
}
