/*-----------------------------------------------------------------------------
 NICTASREngine Application Header
-------------------------------------------------------------------------------
 Copyright (C) 2012 - 2016
   National Institute of Information and Communications Technology.
   All rights reserved.
-----------------------------------------------------------------------------*/

#ifndef _NICTASRENGINE_HPP_
#define _NICTASRENGINE_HPP_

#include <stdio.h>
#include <signal.h>
#ifdef _WIN32
#include    <winsock2.h>
#endif
#include "NICTASREngineConfigure.hpp"
#include "NICTASREngineDataFile.hpp"
#include "NICTSpeechRex.hpp"
#include "SpeechRexDefine.h"
#include "NICTSpeechRexDefine.h"

void sigint(int dummy);

int main_routine(NICTASREngineConfigure *Config, NICTSpeechRex *SR, NICTASREngineDataFile *InputFile, NICTASREngineDataFile *OutputFile );

#endif
