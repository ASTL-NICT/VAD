/*-----------------------------------------------------------------------------
 NICT ASR Engine Data File Class
-------------------------------------------------------------------------------
 Copyright (C) 2012 - 2016
   National Institute of Information and Communications Technology.
   All rights reserved.
-----------------------------------------------------------------------------*/

#ifndef _NICTASRENGINEDATAFILE_HPP_
#define _NICTASRENGINEDATAFILE_HPP_

#include <cstdio>
#include <string>
#include <iostream>
#ifdef WIN32
#include <io.h>
#include <winsock2.h>
#include <time.h>
#include <WS2tcpip.h>
#else
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/time.h>
#endif
#include <sys/stat.h>
#include <fcntl.h>
#include "NICTSpeechRexDefine.h"

// NICTASREngine用のデータファイルを取り扱うクラス
class NICTASREngineDataFile {

private:
    std::string     FileName ;              // ファイル名
    std::string     HostName ;              // ホスト名
    int             PortNumber ;            // ポート番号
    int             Fd ;                    // ファイルディスクリプタ。-1の場合は、エラー又は未オープン
    int             BytePerSize ;           // 1データ当たりのバイトサイズ(2/4/8)
    int             DataSize ;              // 1回に入出力するデータサイズ
    bool            Mode ;                  // 入力(false)/出力(true)
    unsigned char   FormatID ;              // ID_FORMAT_FRAMESYNC/ID_FORMAT_NOHEADER/ID_FORMAT_WAVFILE
    unsigned char   DataEndian ;            // ID_ENDIAN_LITTLE/ID_ENDIAN_BIG
    unsigned char   MachineEndian ;	        // ID_ENDIAN_LITTLE/ID_ENDIAN_BIG
    int             BufefrSize ;            // バッファサイズ
    char            *IOBuffer ;             // 入出力バッファ
    fd_set          SockTBL ;               // ソケットテーブル

#ifdef DEBUG_704
    FILE	        *fpLog_I ;
    FILE	        *fpLog_O ;
#endif
#ifdef WIN32
    SOCKET          childFd ;               // サーバソケットの場合
#else
    int		        childFd ;
#endif
    int             StdoutMode ;            // stdoutへの出力の場合、モードを保存する
public:
    NICTASREngineDataFile() ;
    virtual ~NICTASREngineDataFile() ;

    void SkipWavHeader();
    bool OpenFile( bool mode, const char *fdname, unsigned char format, int size1, int size2, unsigned char order ) ;
    void CloseFile() ;
    int ReadData( int size, char *buf ) ;
    int WriteData( int size, char *buf ) ;
    char *GetIOBuffer() { return IOBuffer; } ;
    int GetIOBufferSize() { return BufefrSize ; } ;
private:
    int ReadDataCore( int size, char *buf ) ;
    int WriteDataCore( int size, char *buf ) ;
    void ConvertEndian( int size, char *buf ) ;
    void UTF8ToUTF16( int size, char *buf, std::wstring &utf16 ) ;
};
#endif
