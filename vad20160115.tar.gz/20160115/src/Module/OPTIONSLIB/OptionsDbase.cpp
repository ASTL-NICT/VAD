﻿/*------------------------------------------------------------------------------
// Options DataBase access class
//------------------------------------------------------------------------------
// Copyright (C) 2011 - 2016
//   National Institute of Information and Communications Technology.
//   All rights reserved.
//----------------------------------------------------------------------------*/

#include <stdlib.h>
#include <string.h>
#include "NICToptions.h"
extern "C" {
#include "NICTutil.h"
}


// コンストラクタ
OptionsDbase::OptionsDbase()
{
	topDBase = NULL ;
	nowDBase = NULL ;
	count_parseId = 0 ;
}

// デストラクタ
OptionsDbase::~OptionsDbase()
{
	DestroyDB() ;
}

// DBを廃棄する
void OptionsDbase::DestroyDB()
{
    NICToptionsList  *ptr, *next ;

    ptr = topDBase ;
    while( ptr ) {
        if( ptr->groupname ) free( ptr->groupname ) ;
        if( ptr->originaladdr ) free( ptr->originaladdr ) ;
        FreeArgument( ptr->options ) ;
        /* List自身 */
        next = (NICToptionsList*)ptr->next ;
        free( ptr ) ;
        ptr = next ;
    }
    topDBase = NULL ;
    nowDBase = NULL ;
}

void OptionsDbase::FreeArgument( NICTargument *arg )
{
    NICTargument     *next ;

    while( arg ) {
        if( arg->name ) free( arg->name ) ;
        if( arg->value ) free( arg->value ) ;
        if( arg->defvalue ) free( arg->defvalue ) ;
        next = (NICTargument*)arg->next ;
        free(arg) ;
        arg = next ;
    }
}

// データ保存または読みだしのための、データのメモリーエリアの確保。
// 使用後は開放してやる必要がある。
char *OptionsDbase::strSaveArea( const char * string )
{
    char    *ptr = NULL ;

    if ( string != NULL ) {
        if ((ptr = (char *)NICT_CALLOC( strlen( string ) +1, sizeof( char ))) == NULL) {
            fprintf( stderr, "OptionsDbase::strSaveArea():\n" ) ;
        } else {
            strcpy( ptr, string );
        }
    }
    return( ptr ) ;
}

// 新しいオプションデータの保存用エリアの確保関数
int OptionsDbase::createNewOption( const char *optionname )
{
	NICTargument   *newarea;
	char          *name_ptr;

	if ((name_ptr = strSaveArea( optionname )) == NULL) {
		return( OPT_FAILURE );
	}

	if ((newarea = (NICTargument*)calloc( 1, sizeof(NICTargument ))) == NULL) {
		fprintf( stderr, "OptionsDbase::createNewOption() : memory allocate error.\n" ) ;
		return( OPT_FAILURE );
	}
	newarea->name = name_ptr;
	if ( nowDBase->options != NULL ) {
		newarea->next = nowDBase->options;
	}
	nowDBase->nowoption = nowDBase->options = newarea ;
	return( OPT_SUCCESS );
}

int OptionsDbase::createNewParse( void )
{
	NICToptionsList	*newarea;

	if ((newarea = (NICToptionsList*)calloc( 1, sizeof(NICToptionsList ))) == NULL) {
		fprintf( stderr, "OptionsDbase::createNewParse() : memory allocate error.\n" ) ;
		return( 0 );  /*  ParseId > 0 , 0 == OPT_FAILURE  */
	}
	newarea->parseId = (++count_parseId) ;
	if ( topDBase != NULL ) {
		newarea->next = topDBase;
	}
	nowDBase = topDBase = newarea ;
	return( newarea->parseId );
}

// 各種データ項目のデータ保存関数
int OptionsDbase::setOrigAddr( char *originaldata )
{
	nowDBase->originaladdr = originaldata ;
	return( OPT_SUCCESS );
}

int OptionsDbase::setGroupName( const char *datastring )
{
	char	*str_ptr = NULL ;

	if ( datastring ) {
		if ( !(str_ptr = strSaveArea( datastring )) ) {
			return( OPT_FAILURE );
		}
	}
	if ( nowDBase->groupname != NULL ) {
		free( nowDBase->groupname ) ;
	}
	nowDBase->groupname = str_ptr ;
	return( OPT_SUCCESS );
}

int OptionsDbase::setDefValue( const char *datastring )
{
	char	*str_ptr = NULL ;

	if ( datastring ) {
		if ( !(str_ptr = strSaveArea( datastring )) ) {
			return( OPT_FAILURE );
		}
	}
	if ( nowDBase->nowoption->defvalue != NULL ) {
		free( nowDBase->nowoption->defvalue ) ;
	}
	nowDBase->nowoption->defvalue = str_ptr ;
	nowDBase->nowoption->alreadyread = OPT_READYDEFAULT ;
	return( OPT_SUCCESS );
}

int OptionsDbase::setValue( const char *datastring )
{
	char	*str_ptr = NULL ;

	if ( datastring ) {
		if ( !(str_ptr = strSaveArea( datastring )) ) {
			return( OPT_FAILURE );
		}
	}
	if ( nowDBase->nowoption->value != NULL ) {
		free( nowDBase->nowoption->value ) ;
	}
	nowDBase->nowoption->value = str_ptr ;
	nowDBase->nowoption->alreadyread = OPT_READYREAD ;
	return( OPT_SUCCESS );
}

// 各種データ項目の読み出し関数
int OptionsDbase::alreadyread( void )
{
	return( nowDBase->nowoption->alreadyread );
}

char *OptionsDbase::getOrigAddr( void )
{
	return( nowDBase->originaladdr );
}

int OptionsDbase::getGroupName( char **valuebox, int gettype )
{
	if ( gettype == GEToptCONST ) {
		*valuebox = nowDBase->groupname ;
	} else {
		if ( nowDBase->groupname != NULL ) {
			*valuebox = strSaveArea( nowDBase->groupname ) ;
			if ( *valuebox == NULL ) {
				return( OPT_FAILURE );
			}
		} else {
			*valuebox = nowDBase->groupname ;
		}
	}
	return( OPT_SUCCESS );
}

int OptionsDbase::getDefValue( char **valuebox, int gettype )
{
	if ( gettype == GEToptCONST ) {
		*valuebox = nowDBase->nowoption->defvalue ;
	} else {
		if ( nowDBase->nowoption->defvalue != NULL ) {
			*valuebox = strSaveArea( nowDBase->nowoption->defvalue ) ;
			if ( *valuebox == NULL ) {
				return( OPT_FAILURE );
			}
		} else {
			*valuebox = nowDBase->nowoption->defvalue ;
		}
	}
	return( OPT_SUCCESS );
}

int OptionsDbase::getValue( char **valuebox, int gettype )
{
	if ( gettype == GEToptCONST ) {
		*valuebox = nowDBase->nowoption->value ;
	} else {
		if ( nowDBase->nowoption->value != NULL ) {
			*valuebox = strSaveArea( nowDBase->nowoption->value ) ;
			if ( *valuebox == NULL ) {
				return( OPT_FAILURE );
			}
		} else {
			*valuebox = nowDBase->nowoption->value ;
		}
	}
	nowDBase->nowoption->alreadyread = OPT_ALREADYREAD ;
	return( OPT_SUCCESS );
}

int OptionsDbase::getName( char **valuebox, int gettype )
{
	if ( gettype == GEToptCONST ) {
		*valuebox = nowDBase->nowoption->name ;
	} else {
		if ( nowDBase->nowoption->name != NULL ) {
			*valuebox = strSaveArea( nowDBase->nowoption->name ) ;
			if ( *valuebox == NULL ) {
				return( OPT_FAILURE );
			}
		} else {
			*valuebox = nowDBase->nowoption->name ;
		}
	}
	return( OPT_SUCCESS );
}

// 現在、read,write,の対象となるnowDBaseの設定をする関数
// parseIdによる設定
int OptionsDbase::setStackParseId( int parseId )
{
	NICToptionsList  *justlist=NULL;

	// オプションのparseIdによるデータのサーチ
	if ( nowDBase != NULL && nowDBase->parseId == parseId ) {
		justlist = nowDBase ;
	} else {
		if ( topDBase != NULL ) {
			justlist = topDBase ;
			while ( justlist->parseId != parseId ) {
				if ( justlist->next != NULL ) {
					justlist = (NICToptionsList*)justlist->next ;
				} else {
					justlist = NULL ;
					break;
				}
			}
		}
	}
	if ( justlist == NULL ) {
		fprintf( stderr, "OptionsDbase::setStackParseId() : I don't know about this option's ID. optionsId=%d\n", parseId ) ;
		return( OPT_FAILURE );
	}
	nowDBase = justlist ;
	return( OPT_SUCCESS );
}

// parseIdとオプション名による設定
int OptionsDbase::setStackOptData( int parseId, const char *optionname )
{
	NICTargument	*justoption=NULL;

	// parseIdで選んだデータより、指定のオプションの項目を探す。
	if ( setStackParseId( parseId ) ) {
		if ( nowDBase->options != NULL ) {
			justoption = nowDBase->options ;
			while ( justoption != NULL ) {
				if ( justoption->name != NULL &&
					strcasecmp( optionname, justoption->name ) == 0 ) {
					break ;
				}
				justoption = (NICTargument*)justoption->next ;
			}
		}
	}
	if ( justoption == NULL ) {
		return( OPT_FAILURE );
	}
	nowDBase->nowoption = justoption ;
	return( OPT_SUCCESS );
}

// オプションデータリストの処理対象になるnowDBase.nowoptionの初期化
int OptionsDbase::reSetStackOptData( void )
{
	if ( nowDBase == NULL || nowDBase->options == NULL ) {
		fprintf( stderr, "OptionsDbase::reSetStackOptData() : can't find options data base.\n" ) ;
		return( OPT_FAILURE );
	}
	nowDBase->nowoption = nowDBase->options ;
	return( OPT_SUCCESS );
}

// オプションデータリストの処理対象になるnowDBase.nowoptionを次のデータの物に進める。
int OptionsDbase::pushStackOptData( void )
{
	if ( nowDBase == NULL || nowDBase->nowoption == NULL ) {
		fprintf( stderr, "OptionsDbase::pushStackOptData() : can't find options data base.\n" ) ;
		return( OPT_FAILURE );
	}
	nowDBase->nowoption = (NICTargument*)nowDBase->nowoption->next ;
	if ( nowDBase->nowoption == NULL ) {
		return( OPT_FAILURE );
	}
	return( OPT_SUCCESS );
}
