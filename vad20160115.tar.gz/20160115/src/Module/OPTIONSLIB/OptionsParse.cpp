﻿/*------------------------------------------------------------------------------
// Options data parser class
//------------------------------------------------------------------------------
// Copyright (C) 2011 - 2016
//   National Institute of Information and Communications Technology.
//   All rights reserved.
//----------------------------------------------------------------------------*/

#include <stdio.h>
#include "NICToptions.h"
extern "C" {
#include "NICTutil.h"
#include "NICToptions_option_names.h"
}


// コンストラクタ
OptionsParse::OptionsParse()
{
	streamBuff.orig  = NULL ;
	streamBuff.base  = NULL ;
	streamBuff.end   = NULL ;
	streamBuff.now   = NULL ;
	streamBuff.eoffg = 0 ;

	prev_char		 = 0 ;
	env_str[0]       = '\0';
	env_p            = NULL ;
	from             = 0 ;
	end_of_line      = 1 ;
}

// デストラクタ
OptionsParse::~OptionsParse()
{
}

// 指定のオプションの設定値の読み出しを行なったかどうかのチェック。
int OptionsParse::CheckReadAlready( int optionsPaseId, const char *optionName )
{
    int     sts ;

	/* search the given string on the options */
	if ( Dbase.setStackOptData( optionsPaseId, optionName ) == OPT_FAILURE ) {
		return( OPT_FAILURE );	/* not found */
	}

	switch ( Dbase.alreadyread() ) {
		case OPT_ALREADYREAD :
			sts = OPT_SUCCESS ;  /* == 1 */
			break ;
		case OPT_READYREAD :
			sts = OPT_FAILURE ;  /* == 0 */
			break ;
		case OPT_READYDEFAULT :
			sts = OPT_READYDEFAULT ;  /* == -1 */
			break ;
		case OPT_NOTREADY :
		default :
			sts = OPT_FAILURE ;  /* == 0 */
	}	
	return( sts ) ;
}

// 指定のオプションセットから、Stringタイプのオプションの設定値を取り出す。
int OptionsParse::GetOptValue( int optionsPaseId, const char *optionName, char **optionValueBox )
{
	/* search the given string on the options */
	if ( Dbase.setStackOptData( optionsPaseId, optionName ) == OPT_FAILURE ) {
		return( OPT_FAILURE );	/* not found */
	}
	return( Dbase.getValue( optionValueBox, GEToptRdWt ) ) ;
}

// 指定のオプションセットから、Stringタイプのオプションのデフォルト値を取り出す。
int OptionsParse::GetOptDefValue( int optionsPaseId, const char *optionName, char **optionDefValueBox )
{
	/* search the given string on the options */
	if ( Dbase.setStackOptData( optionsPaseId, optionName ) == OPT_FAILURE ) {
		return( OPT_FAILURE );	/* not found */
	}
	return( Dbase.getDefValue( optionDefValueBox, GEToptRdWt ) ) ;
}


// 登録されたオプションの名前リストを与えられた変数に返す。
int OptionsParse::OptsNameList( int optParseId, char ***nameList )
{
	char  *name ;
	char  **nameargv ;
	int   count ;

	if ( Dbase.setStackParseId( optParseId ) == OPT_FAILURE ) {
		return( OPT_FAILURE ) ;
	}

	if ( Dbase.reSetStackOptData() == OPT_FAILURE ) {
		return( OPT_FAILURE ) ;
	}
	for ( count=2 /* first + NULL */ ;Dbase.pushStackOptData() != OPT_FAILURE ; count++ ) ;

	if ((nameargv = (char **)NICT_CALLOC( count, sizeof(char *))) == NULL) {
		return( OPT_FAILURE ) ;
	}

	count = 0 ;
	Dbase.reSetStackOptData() ;
	do {
		Dbase.getName( &name, GEToptRdWt );
		if ( name == NULL ) {
			continue ;
		}
		nameargv[ count++ ] = name ;
	} while ( Dbase.pushStackOptData() != OPT_FAILURE ) ;
	nameargv[ count ] = NULL ;

	*nameList = nameargv ;
	return( OPT_SUCCESS ) ;
}

// オプションの解析関数群
/*
   オプションの名前の前には、'-'はいらない。
   '='の前後には空白文字は入れない。
   オプション名に'='代入が無い場合は、BOOLデータとして扱う。
   ’#’より次のラインまでは、コメントとみなす。
*/
// 認証させたいオプションの設定。デフォルトオプションストリングを使って行なう。
int OptionsParse::SetDefOpts( int *optParseId, const char *optGrpName, char *defOptString )
{
	int   ret_stat ;

	if ( defOptString == NULL || *defOptString == '\0' ) {
		return( OPT_FAILURE ) ;
	}

	/*  オプションデータをストックするモジュールの準備  */
	if ( *optParseId == 0 ) {
		/*  新しいオプションセットを記憶する領域の確保  */
		if ( (*optParseId = Dbase.createNewParse()) == 0 ) {
			return( OPT_FAILURE ) ;
		}
		/*  ファイルからのオプション読み込み時の、読み込みグループ判別名のセット  */
		if ( optGrpName != NULL && *optGrpName != '\0' ) {
			if ( Dbase.setGroupName( optGrpName ) == OPT_FAILURE ) {
				return( OPT_FAILURE ) ;
			}
		}
	} else {
		if ( Dbase.setStackParseId( *optParseId ) == OPT_FAILURE ) {
			return( OPT_FAILURE ) ;
		}
	}

	/*  オプションをデータベースに登録する  */
	ret_stat = readOption( *optParseId, defOptString, STRINGsTREAM, OPTIONdefCREATE ) ;

	/*  オリジナルのデフォルトオプションのストリングのアドレスを、
      データベースに登録する。これは、optionsparse()の後である必要がある。
      何故なら、これを登録してあるかどうかで、新規登録許可をoptionSetDB()で
      チェックしている。  */
	Dbase.setOrigAddr( defOptString ) ;

	return( ret_stat ) ;
}

//	NICToptions_SetDefOpts()で設定したオプションについて、
//	指定のファイルストリームまたはコマンドラインより新しい設定値を読み込む。
//	fixOptParse()で認識したconfigFileをファイルストリームとして与える事。
int OptionsParse::Parse( FILE *optionsfile, int *optparseId, const char *optgroup, int argc, char **argv )
{
	int   ret_sts = OPT_FAILURE ;

	/*  オプションデータをストックするモジュールの準備  */
	if ( *optparseId == 0 ) {
		/*  新しいオプションセットを記憶する領域の確保  */
		if ( (*optparseId = Dbase.createNewParse()) == 0 ) {
			return( OPT_FAILURE ) ;
		}
	} else {
		if ( Dbase.setStackParseId( *optparseId ) == OPT_FAILURE ) {
			return( OPT_FAILURE ) ;
		}
	}

	/*  ファイルからのオプション読み込み時の、読み込みグループ判別名のセット  */
	if ( Dbase.setGroupName( optgroup ) == OPT_FAILURE ) {
		return( OPT_FAILURE ) ;
	}

	/*  config file よりオプションを読み込む  */
	if ( optionsfile != NULL ) {
		if ( (ret_sts |= fileParse( optionsfile, *optparseId )) == OPT_FAILURE ) {
			return( OPT_FAILURE ) ;
		}
	}

	/*  argv よりオプションを読み込む  */
	if ( argc > 0 && argv != NULL ) {
		if ( (ret_sts |= argParse( argc, argv, *optparseId )) == OPT_FAILURE ) {
			return( OPT_FAILURE ) ;
		}
	}
	return( ret_sts ) ;
}

/*
   オプションデータファイルのサンプル
---------------
# change input byte order
#       value = network or nonnetwork
InputByteOrder=,network,nonnetwork,

# sampling frequency in \"Hz\"
#	value type = integer
SamplingFrequency=16000


# Wave2Para output data parameter
#	value = "pow", "cep", "dyn", "dpow", "dcep", "ddyn"
OutputParameter=pow+cep+dyn+dpow+dcep+ddyn

# Program debug mode of display
DebugDisplay

---------------
   オプションの名前の前には、'-'はいらない。
   '='の前後には空白文字は入れない。
   オプション名に'='代入が無い場合は、BOOLデータとして扱う。
   ’#’より次のラインまでは、コメントとみなす。
*/
// オプションファイルより、有効であろう情報を読み込む。
int OptionsParse::fileParse( FILE *optionsfile, int optparseId )
{
	int	ret_stat ;

	/*  オプションの登録  */
	ret_stat = readOption( optparseId, optionsfile, FILEsTREAM, OPTIONnewCREATE ) ;

	return( ret_stat ) ;
}

// ａｒｇｖ，ａｒｇｃを解読して、オプションとしてリストに登録する。
int OptionsParse::argParse( int pargc, char **pargv, int optparseId )
{
	int		largc ;
	char	*str ;
	int     warnmask = OPT_SUCCESS ;
	int     etcmask = 0 ;
	int     ret_sts ;

	/* parsing the arguments and set each value */
	largc = -1;
	while(1) {
		/* next argument */
		largc++;
		for ( ; largc < pargc ; largc++ ) {
			if ( pargv[ largc ][0] == '-') {
				break ;
			} else if ( pargv[ largc ][0] == '=' ) {
				fprintf( stderr, "argParse() : format error. SPACES around the '='\n" ) ;
				warnmask = OPT_FAILURE ;
				continue ;
			}
		}
		if ( largc == pargc ) {
			break ;
		}

		/*  下位関数でデータ加工をするので、argv の変更を防ぐ為  */
		str = Dbase.strSaveArea( &pargv[ largc ][1] ) ;
		if ( str == NULL ) {
			return( OPT_FAILURE ) ;
		}

		/* search the given string on the defalut options */
		/*  argv 文字列を、オプションデータとして登録する */
		ret_sts = optionSetDB( optparseId, str, OPTIONnewCREATE ) ;
		if ( ret_sts == OPT_FAILURE ) {
			warnmask = ret_sts ;
		} else if ( ret_sts == OPT_EtcOptions ) {
			etcmask = ret_sts ;
		}
		free( str ) ;
	}
	return( (OPT_SUCCESS & warnmask) | etcmask ) ;
}

// 与えられた文字列を、オプションとして登録する。
int OptionsParse::optionSetDB( int optparseId, char *rdstring, int createflag )
{
	char	*optstring = rdstring ;
	char	*value ;
	char	*optgrp ;
	char	*grpend ;
	int		gnleng ;
	int		equal = (int) '=' ;
	int		grptok = (int) ':' ;


	/*  与えられた文字列を、オプショングループとオプションとデータに分割する  */
	grpend = strchr( optstring, grptok ) ;
	value = strchr( optstring, equal ) ;

	/*  これからオプションをセットする対象のデータベースをセットする  */
	if ( Dbase.setStackParseId( optparseId ) == OPT_FAILURE ) {
		fprintf( stderr, "optionSetDB() : optparseId=%d\n", optparseId ) ;
		return( OPT_FAILURE ) ;
	}

	/*  オプションデータが、現プロセスを対象にしているか,
      オプショングループネームのチェックをする。  */

	if ( grpend != NULL ) {
		if ( !(value != NULL && value < grpend) ) {
			Dbase.getGroupName( &optgrp, GEToptCONST ) ;
			gnleng = ( optgrp == NULL )? 0 : strlen( optgrp ) ;

			if ( gnleng == 0 ) {
				/*  他のプロセスの為のオプションである。  */
				return( OPT_EtcOptions ) ;
			} else if ( *(grpend +1) == '\0' ) {
				fprintf( stderr, "OptionsParse::optionSetDB() : option format error. : %s\n", optstring ) ;
				return( OPT_FAILURE ) ;
			} else if ( !strncmp( optgrp, optstring, gnleng ) ) {
				optstring = grpend +1 ;
				/*  現プロセスを対象にしているので、強制的にオプション登録する。  */
				if ( Dbase.getOrigAddr() == NULL ) {
					createflag = OPTIONnewCREATE ;

				}
			} else {
				/*  他のプロセスの為のオプションである。  */
				return( OPT_EtcOptions ) ;
			}
		}
		/*  else {} '：'を文字列句切り文字として使用している。  */
	}

	if ( value != NULL ) {
		/*  '='で挟まれた代入文であり、通常のオプションである。  */
		*value = '\0' ;
		value += 1 ;
		/*  if ( *value == '\0' )  読み込んだ文字列の終りに'='がある。
		  これは、オプション指定にＮＵＬＬを入れたものとする。*/
		if ( !strcmp( value, "\"\"" ) ) {
			/*  NULLストリングを指定  */
			value = (char *)"" ;
		}
	} else {
		/*  オプション名だけ、Ｂｏｏｌｅａｎタイプのオプション。  */
		value = NULL ;
	}

	if ( Dbase.setStackOptData( optparseId, optstring ) == OPT_SUCCESS ) {
		/*  データの登録  */
		if ( Dbase.setValue( value ) == OPT_FAILURE ) {
			return( OPT_FAILURE ) ;
		}
	} else {
		/*  新しいオプションとして登録。  */
		if ( Dbase.createNewOption( optstring ) == OPT_FAILURE ) {
			return( OPT_FAILURE ) ;
		}
		/*  データの登録  */
		if ( Dbase.setValue( value ) == OPT_FAILURE ) {
			return( OPT_FAILURE ) ;
		}
	}

	/*  デフォルトのデータの登録  */
	if ( createflag == OPTIONdefCREATE ) {
		if ( Dbase.setDefValue( value ) == OPT_FAILURE ) {
			return( OPT_FAILURE ) ;
		}
	}
	return( OPT_SUCCESS ) ;
}

// ストリームからオプションを読むための関数群
// オプションを指定のストリームより読み込みデータベースとして登録する
int OptionsParse::readOption( int optParseId, void *parseStream, int typeStream, int optCreateFlag )
{
	int	chk_stat ;
	int etcmask = 0 ;
	int warnmask = OPT_SUCCESS ;

	/*  ストリングを読み込み対象としている時の、ローカルリードポインターの初期化  */
	if ( typeStream == STRINGsTREAM ) {
		reset_MyStream() ;
	}
	while (1) {
		/*  ストリームよりひと区切りづつ文字列を読み込む  */
		chk_stat = streamParse( typeStream, parseStream, MAXLINE, optstring ) ;
		/*  読み込みステータスチェック  */
		if ( chk_stat == EndReadString ) {
			break ;
		} else if ( chk_stat == CReturnReadString ) {
			continue ;
		} else if ( chk_stat == CommentReadString ) {
			continue ;
		} else if ( chk_stat != NormalReadString ) {
			break ;
		}

		/* 読み込んだ文字列を、オプションとして処理、登録する。  */
		chk_stat = optionSetDB( optParseId, optstring, optCreateFlag ) ;
		if ( chk_stat == OPT_FAILURE ) {
			warnmask = chk_stat ;
		} else if ( chk_stat == OPT_EtcOptions ) {
			etcmask = chk_stat ;
		}
	}
	/*  ストリングを読み込み対象としている時の、ローカルリードポインターの初期化  */
	if ( typeStream == STRINGsTREAM ) {
		reset_MyStream() ;
	}
	return( ( OPT_SUCCESS & warnmask ) | etcmask ) ;
}

// 指定されたストリングの頭より、オプションとして有効な最初の文字列を指定のバッファーに書き込む。
// また、dstreamには読み込んだ文字列の次のポイントを返すので、連続して文字列を読み込みたい場合には、
// 次回呼び出しからはそのポイントを与えれば良い。
int OptionsParse::streamParse( int strtype, void * dstream, int boxsize, char * valuebox )
{
	int rdkey ;
	int cnt ;
	int retcode ;
	int allquote ;
	int halfquote ;

	/*  引数のエラーチェック  */
	if ( dstream == NULL || valuebox == NULL || boxsize == 0 ) {
		return( EndReadString ) ;
	}

	valuebox[ -- boxsize ] = '\0' ;

	/*  頭の空白をスキップ  */
	while ( (rdkey = my_getc( dstream, strtype )) != EOF ) {
		if ( !( rdkey == ' ' || rdkey == '\t' ) ) {
			break ;
		}
	}

	/*  読み込み対象のエンドに達した  */
	if ( rdkey == EOF ) {
		valuebox[0] = '\0' ;
		retcode = EndReadString ;

	/*  リターンを読み込んだ  */
	} else if ( rdkey == '\n' ) {
		valuebox[0] = rdkey ;
		valuebox[1] = '\0' ;
		retcode = CReturnReadString ;

	/*  コメント行なので次の行までスキップ  */
	} else if ( rdkey == '#' ) {
		valuebox[0] = rdkey ;
		for ( cnt=1 ; cnt < boxsize && (rdkey = my_getc( dstream, strtype )) != EOF ; cnt++ ) {
			if ( rdkey == '\n' ) {
				my_ungetc( rdkey, dstream, strtype ) ;
				break ;
			}
			valuebox[cnt] = rdkey ;
		}
		valuebox[cnt] = '\0' ;
		retcode = CommentReadString ;

	/*  通常の文字列の読み込み  */
	} else {
		allquote = halfquote = 0 ;
		valuebox[0] = rdkey ;
		cnt=1 ;
		while ( cnt < boxsize ) {
			if ( (rdkey = my_getc( dstream, strtype )) == EOF ) {
				my_ungetc( rdkey, dstream, strtype ) ;
				break ;
			}
			/*  読み込み文字別処理  */
		
			if ( !( allquote || halfquote ) && ( rdkey == '\t' ) ) {
				my_ungetc( rdkey, dstream, strtype ) ;
				break ;
			} else if ( rdkey == '\n' ) {
				if ( allquote || halfquote ) {
					continue ;
				} else {
					my_ungetc( rdkey, dstream, strtype ) ;
					break ;
				}
//Windows移植用追加 file path "\"marker 処理
#ifndef _WIN32
			} else if ( rdkey == '\\' ) {
				if ( (rdkey = my_getc( dstream, strtype )) != EOF ) {
					valuebox[cnt] = rdkey ;
				} else {
				my_ungetc( rdkey, dstream, strtype ) ;
				break ;
			}
#endif

			} else if ( !allquote && rdkey == '\'' ) {
				halfquote ^= 1 ;
				continue ;
			} else if ( !halfquote && rdkey == '"' ) {
				allquote ^= 1 ;
				continue ;
			} else {
				valuebox[cnt] = rdkey ;
			}
			cnt ++ ;
		}
		valuebox[cnt] = '\0' ;
		retcode = NormalReadString ;
	}
	return( retcode ) ;
}

// 字句解析の字句読みだし関数で、ファイルストリーム、ストリング双方での、
// インターフェイスを同じとする為のカバー関数。
void OptionsParse::reset_MyStream( void )
{
	if ( streamBuff.base ) {
		free( streamBuff.base ) ;
	}
	streamBuff.orig =
    streamBuff.base =
    streamBuff.end =
	streamBuff.now = NULL ;
	streamBuff.eoffg = 0 ;
	return ;
}

int OptionsParse::my_getc( void * stream, int type )
{
	int  key = EOF ;

	if ( type == FILEsTREAM ) {
		key = v_getc( (FILE *) stream ) ;
	} else if ( type == STRINGsTREAM ) {
		if ( streamBuff.orig != stream ) {
			streamBuff.orig = (char*)stream ;
			if ( streamBuff.base ) {
				free( streamBuff.base ) ;
			}
			streamBuff.base = streamBuff.now = Dbase.strSaveArea( (char*)stream ) ;
			streamBuff.end = streamBuff.base + strlen( streamBuff.base ) ;
			streamBuff.eoffg = 0 ;
		}
		if ( streamBuff.base ) {
			if ( streamBuff.now < streamBuff.end ) {
				key = ((int)(* streamBuff.now) & 0xff) ;
				streamBuff.now ++ ;
			} else {
				streamBuff.eoffg = 1 ;
			}
		}
	}
	return( key ) ;
}

int OptionsParse::my_ungetc( int chrct, void * stream, int type )
{
	int  key = EOF ;

	if ( type == FILEsTREAM ) {
		key = v_ungetc( chrct, (FILE *) stream ) ;
	} else if ( type == STRINGsTREAM ) {
		if ( streamBuff.orig == stream && streamBuff.base ) {
			if ( streamBuff.now > streamBuff.base ) {
				if ( !streamBuff.eoffg ) {
					streamBuff.now -- ;
					(* streamBuff.now) = chrct & 0xff ;
				}
				key = chrct ;
			}
		}
	}
	return( key ) ;
}

int	OptionsParse::v_getc( FILE * fp )
{
	char	var_str[ MAXLINE ];
	char	*var_p;
	int		ret;

	if( from == 0 ) {	/*	from stream	*/
		while( 1 ) {
			ret = getc( fp );
			if( end_of_line == 1 && ret == '#' ) {
				while( 1 ) {
					ret = getc( fp );
					if( ret == EOF || ret == '\n' ) {
						break;
					}
				}
				if( ret == EOF ) {
					end_of_line = 1;
					break;
				}
				else {
					end_of_line = 1;
				}
			}
			else {
				if( ret == '\n' || ret == EOF ) {
					end_of_line = 1;
				}
				else {
					end_of_line = 0;
				}
				break;
			}
		}
		if( ret == '$' ) {
			var_p = var_str;
			while( 1 ) {
				ret = getc( fp );
				if( !( ret >= '0' && ret <= '9' ) &&
				    !( ret >= 'A' && ret <= 'Z' ) &&
				    !( ret >= 'a' && ret <= 'z' ) &&
				    !( ret == '_' ) ) {
					/* End of environment variable,	*/
					/* i.e. a separator was found	*/
					ungetc( ret, fp );
					*var_p = '\0';
					break;
				}
				else {
					*var_p = ret;
					var_p ++;
				}
			}
			var_p = getenv( var_str );
			if( var_p == NULL ) {
				fprintf( stderr, "@optionslib ERROR: env '%s' is not set\n", var_str );
				strcpy( env_str, "" );
			}
			else {
				strcpy( env_str, getenv( var_str ) );
			}
			env_p = env_str;
			from = 1;
			ret = v_getc( fp );
		}
	}
	else {	/*	from enviroment variable	*/
		if( *env_p == '\0' ) {
			from = 0;
			ret = v_getc( fp );
		}
		else {
			ret = *env_p;
			env_p ++;
		}
	}
	return( ret );
}

int	OptionsParse::v_ungetc( int c, FILE * fp )
{
	prev_char = c;
	return( c );
}

/*
    Is there program name in program_name_list.
    return 0 : program name exist.
    return -1 : program name not exist.
*/
int OptionsParse::checkProgramName( char* psProgramName )
{
	long liCount;
	
	for ( liCount=0; liCount<OPTION_MODULE_NAMES_MAX; liCount++ ) {
		
		
//		if ( !strcasecmp( psOptionModuleNames[liCount], psProgramName ) ) {
			
#ifdef WIN32
		if ( !strcasecmp( psOptionModuleNames[liCount], psProgramName ) ) {
#else
  		if ( !strcasecmp( (char*)psOptionModuleNames[liCount], psProgramName ) ) {
#endif

    	
    	
			return 0;
		}
	}
	return -1;
}

/*
    Is there option name in option_name_list.
    return 0 : option name exist.
    return -1 : option name not exist.
*/
int OptionsParse::checkOptionName( char* psOptionName )
{
	long liCount;
		
	for ( liCount=0; liCount<OPTION_OPTION_NAMES_MAX; liCount++ ) {
		
		
		
//		if ( !strcasecmp( psOptionOptionNames[liCount], psOptionName ) ) {
	
#ifdef WIN32
		if ( !strcasecmp( psOptionOptionNames[liCount], psOptionName ) ) {
#else
		if ( !strcasecmp( (char*)psOptionOptionNames[liCount], psOptionName ) ) {
#endif

    	
		
    		return 0;
		}
	}
	return -1;
}

/*
    create config file error string.
    malloc new area, musut free area by user.
    return 0 : success
    return -1 : failure
*/
int OptionsParse::createFileErrorString( char** psError, char* psName, char* psFileName, long liLine, const char* psTarget)
{
	char* psWorkPtr;
	long liSize;

	if ( psName[0] == '\0' ) {
		liSize = strlen( ERROR_NO_OPTION ) + strlen( ERROR_FORMAT_FILE ) +
                 strlen( psTarget ) +
                 strlen( psFileName ) + LONG_MAX_WIDTH + 1;
	}
	else {
		liSize = strlen( psName ) + strlen( ERROR_FORMAT_FILE ) +
                 strlen( psTarget ) +
                 strlen( psFileName ) + LONG_MAX_WIDTH + 1;
	}
	if ( *psError == NULL ) {
		psWorkPtr = (char*)malloc( liSize );
		if ( !psWorkPtr ) {
			return( -1 );
		}
		if ( psName[0] == '\0' ) {
			sprintf( psWorkPtr, ERROR_FORMAT_FILE, "", psTarget, ERROR_NO_OPTION, psFileName, liLine );
		}
		else {
			sprintf( psWorkPtr, ERROR_FORMAT_FILE, "", psTarget, psName, psFileName, liLine );
		}
		*psError = psWorkPtr;
	}
	else {
		psWorkPtr = (char*)malloc( strlen( *psError ) + liSize );
		if ( !psWorkPtr ) {
			free( *psError );
			return( -1 );
		}
		if ( psName[0] == '\0' ) {
			sprintf( psWorkPtr, ERROR_FORMAT_FILE, *psError, psTarget, ERROR_NO_OPTION, psFileName, liLine );
		}
		else {
			sprintf( psWorkPtr, ERROR_FORMAT_FILE, *psError, psTarget, psName, psFileName, liLine );
		}
		free( *psError );
		*psError = psWorkPtr;
	}
	return 0;
}

/*
    create Argument option error string.
    malloc new area, musut free area by user.
    return 0 : success
    return -1 : failure
*/
int OptionsParse::createArgumentErrorString( char** psError, char* psName, const char* psTarget )
{
	char* psWorkPtr;
	long liSize;

	if ( psName[0] == '\0' ) {
		liSize = strlen( ERROR_NO_OPTION ) + strlen( ERROR_FORMAT_ARG ) + strlen( psTarget ) + 1;
	}
	else {
		liSize = strlen( psName ) + strlen( ERROR_FORMAT_ARG ) + strlen( psTarget ) + 1;
	}

	if ( *psError == NULL ) {
		psWorkPtr = (char*)malloc( liSize );
		if ( !psWorkPtr ) {
			return( -1 );
		}
		if ( psName[0] == '\0' ) {
			sprintf( psWorkPtr, ERROR_FORMAT_ARG, "", psTarget, ERROR_NO_OPTION );
		}
		else {
			sprintf( psWorkPtr, ERROR_FORMAT_ARG, "", psTarget, psName );
		}
		*psError = psWorkPtr;
	}
	else {
		psWorkPtr = (char*)malloc( strlen( *psError ) + liSize );
		if ( !psWorkPtr ) {
			free( *psError );
			return( -1 );
		}
		if ( psName[0] == '\0' ) {
			sprintf( psWorkPtr, ERROR_FORMAT_ARG, *psError, psTarget, ERROR_NO_OPTION );
		}
		else {
			sprintf( psWorkPtr, ERROR_FORMAT_ARG, *psError, psTarget, psName );
		}
		free( *psError );
		*psError = psWorkPtr;
	}
	return 0;
}

/*
    Check all option names and program names in config file.
*/
int OptionsParse::streamParseForCheck( void * dstream, int boxsize, char * valuebox, long * pliLineCount )
{
	int	rdkey ;
	int cnt ;
	int retcode ;
	int allquote ;
	int halfquote ;

	/*  引数のエラーチェック  */
	if ( dstream == NULL || valuebox == NULL || boxsize == 0 ) {
		return( EndReadString ) ;
	}
	valuebox[ -- boxsize ] = '\0' ;

	/*  頭の空白をスキップ  */
	//Windows移植用追加
	while ( (rdkey = getc( (FILE *)dstream )) != EOF ) {
		if ( !( rdkey == ' ' || rdkey == '\t' ) ) {
			break ;
		}
	}

	/*  読み込み対象のエンドに達した  */
	if ( rdkey == EOF ) {
		valuebox[0] = '\0' ;
		retcode = EndReadString ;

	/*  リターンを読み込んだ  */
	} else if ( rdkey == '\n' ) {
		valuebox[0] = rdkey ;
		valuebox[1] = '\0' ;
		(*pliLineCount)++;
		retcode = CReturnReadString ;

	/*  コメント行なので次の行までスキップ  */
	} else if ( rdkey == '#' ) {
		valuebox[0] = rdkey ;
		//Windows移植用追加
		for ( cnt=1 ; cnt < boxsize && (rdkey = getc( (FILE *)dstream )) != EOF ; cnt++ ) {
			if ( rdkey == '\n' ) {
				(*pliLineCount)++;
				break ;
			}
			valuebox[cnt] = rdkey ;
		}
		valuebox[cnt] = '\0' ;
		retcode = CommentReadString ;

	/*  通常の文字列の読み込み  */
	} else {
		allquote = halfquote = 0 ;
		valuebox[0] = rdkey ;
		cnt=1 ;
		while ( cnt < boxsize ) {
			//Windows移植用追加
			if ( (rdkey = getc( (FILE *)dstream )) == EOF ) {
				break ;
			}
			/*  読み込み文字別処理  */
			if ( !( allquote || halfquote ) && ( rdkey == ' ' || rdkey == '\t' ) ) {
				break ;
			} else if ( rdkey == '\n' ) {
				(*pliLineCount)++;
				if ( allquote || halfquote ) {
					continue ;
				} else {
					break ;
				}
			} else if ( rdkey == '\\' ) {
				//Windows移植用追加
				if ( (rdkey = getc( (FILE *)dstream )) != EOF ) {
					valuebox[cnt] = rdkey ;
				} else {
					break ;
				}
			} else if ( !allquote && rdkey == '\'' ) {
				halfquote ^= 1 ;
				continue ;
			} else if ( !halfquote && rdkey == '"' ) {
				allquote ^= 1 ;
				continue ;
			} else {
				valuebox[cnt] = rdkey ;
			}
			cnt ++ ;
		}
		valuebox[cnt] = '\0' ;
		retcode = NormalReadString ;
	}
	return( retcode ) ;
}

/*
    Check all option names and program names in config file.
*/
int OptionsParse::checkConfigFile( char* psConfigFileName, char** psProgramNameError, char** psOptionNameError )
{
	FILE*	pFp = NULL;
	int		iChk_stat ;
	char	sBuf[MAXLINE];
	char	sProgramName[MAXLINE];
	char	sOptionName[MAXLINE];
	char*	psWorkPtr;
	char*	psConfigFile;
	long	liLineCount = 1;
	long	liNowLineCount = 0;

	if ( !psConfigFileName || strlen( psConfigFileName ) < 1 ) {
		return 0;
	}

	/* get config file name whitout path */
	psConfigFile = psConfigFileName;

	//Windows移植用追加
#ifndef _WIN32
	psWorkPtr = strrchr( psConfigFile, (int)'/' ) ;
#else
	psWorkPtr = strrchr( psConfigFile, (int)'\\' ) ;
#endif

	if ( psWorkPtr != NULL ) {
		psConfigFile = psWorkPtr + 1;
	}

	pFp = fopen( psConfigFileName, "r" );
	if ( !pFp ) {
		return -1;
	}

	while (1) {
		/*  read stream */
		liNowLineCount = 0;
		iChk_stat = streamParseForCheck( pFp, MAXLINE, sBuf, &liNowLineCount ) ;
		/*  check status  */
		if ( iChk_stat == EndReadString ) {
			break ;
		} else if ( iChk_stat == CReturnReadString ) {
			liLineCount += liNowLineCount;
			continue ;
		} else if ( iChk_stat == CommentReadString ) {
			liLineCount += liNowLineCount;
			continue ;
		} else if ( iChk_stat != NormalReadString ) {
			fclose( pFp );
			return -1; /* read stream error */
		}

		strcpy(sProgramName, sBuf);
		strcpy(sOptionName, sBuf);
		/* get program name */
		psWorkPtr = strchr( sProgramName, (int)':' );
		if ( psWorkPtr ) {
			strcpy(sOptionName, (psWorkPtr + 1));
			*psWorkPtr = '\0';
		}
		else {
			sProgramName[0] = '\0';
		}

		/* get option name */
		psWorkPtr = strchr( sOptionName, (int)'=' );
		if ( psWorkPtr ) {
			*psWorkPtr = '\0';
		}

		/* If program name existed in stream, check program name */
		if ( sProgramName[0] != '\0' && checkProgramName( sProgramName ) < 0 ) {
			/* program name not exist in program_name_list. */
			if ( createFileErrorString( psProgramNameError, sProgramName,
									  psConfigFile, liLineCount,
									  ERROR_TARGET_PROGRAM ) < 0 ) {
				fclose( pFp );
				return -1; /* create fail */
			}
		}

		/* If option name existed in stream, check option name */
		if ( sOptionName[0] == '\0' || checkOptionName( sOptionName ) < 0 ) {
			/* option name not exist in option_name_list. */
			if ( createFileErrorString( psOptionNameError, sOptionName,
									  psConfigFile, liLineCount,
									  ERROR_TARGET_OPTION ) < 0 ) {
				fclose( pFp );
				return -1; /* create fail */
			}
		}

		liLineCount += liNowLineCount;
	}
	fclose( pFp );

	return 0;
}

/*
    Check all option names and program names in argument.
*/
int OptionsParse::checkArgument( int argc, char **argv, char** psProgramNameError, char** psOptionNameError )
{
	int		i;
	char	sProgramName[MAXLINE];
	char	sOptionName[MAXLINE];
	char*	psCurrent;
	char*	psWorkPtr;

	for ( i=1; i<argc; i++ ) {
		psCurrent = argv[i];
		if ( *psCurrent != '-' ) {
			continue;
		}
		psCurrent++;

		strcpy(sProgramName, psCurrent);
		strcpy(sOptionName, psCurrent);
		/* get program name */
		psWorkPtr = strchr( sProgramName, (int)':' );
		if ( psWorkPtr ) {
			strcpy(sOptionName, (psWorkPtr + 1));
			*psWorkPtr = '\0';
		}
		else {
			sProgramName[0] = '\0';
		}

		/* get option name */
		psWorkPtr = strchr( sOptionName, (int)'=' );
		if ( psWorkPtr ) {
			*psWorkPtr = '\0';
		}

		/* If program name existed in stream, check program name */
		if ( sProgramName[0] != '\0' && checkProgramName( sProgramName ) < 0 ) {
			/* program name not exist in program_name_list. */
			if ( createArgumentErrorString( psProgramNameError, sProgramName,
                                      ERROR_TARGET_PROGRAM ) < 0 ) {
				return -1; /* create fail */
			}
		}

		/* If option name existed in stream, check option name */
		if ( sOptionName[0] == '\0' || checkOptionName( sOptionName ) < 0 ) {
			/* option name not exist in option_name_list. */
			if ( createArgumentErrorString( psOptionNameError, sOptionName,
                                      ERROR_TARGET_OPTION ) < 0 ) {
				return -1; /* create fail */
			}
		}
	}
	return 0;
}

/*
    Check all option names and program names.
    An error message is outputted when an invalid option or an invalid program are specified.
*/
int OptionsParse::checkAllOptionNames( char* psConfigFileName, int argc, char **argv )
{
	char*	psProgramNameError = NULL;  /* Invalid program names. */
	char*	psOptionNameError = NULL;  /* Invalid option names */
	int		iRet = OPT_SUCCESS;

	if ( checkConfigFile( psConfigFileName, &psProgramNameError, &psOptionNameError ) < 0 ) {
		goto ErrorLabel;
	}

	if ( checkArgument( argc, argv, &psProgramNameError, &psOptionNameError ) < 0 ) {
		goto ErrorLabel;
	}

	/* output error message */
	if ( psProgramNameError != NULL ) {
		fprintf( stderr, "Option Wrong: Invalid program name specified as below;\n%s\n", psProgramNameError );
		free( psProgramNameError );
		iRet = OPT_FAILURE;
	}
	if ( psOptionNameError != NULL ) {
		fprintf( stderr, "Option Wrong: Invalid option name specified as below;\n%s\n", psOptionNameError );
		free( psOptionNameError );
		iRet = OPT_FAILURE;
	}
	return( iRet );

ErrorLabel:
	fprintf( stderr, "Error: Option check error.\n" );
	if ( psProgramNameError != NULL ) {
		free( psProgramNameError );
	}
	if ( psOptionNameError != NULL ) {
		free( psOptionNameError );
	}
	return OPT_FAILURE;
}

