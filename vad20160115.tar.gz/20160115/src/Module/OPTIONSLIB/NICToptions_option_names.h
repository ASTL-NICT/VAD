﻿/*------------------------------------------------------------------------------
// Include file for Options Libraly
//------------------------------------------------------------------------------
// Copyright (C) 2009 - 2016
//   National Institute of Information and Communications Technology.
//   All rights reserved.
//----------------------------------------------------------------------------*/

/*
***

    declaration of option names and module names.
    This header is used in OptionLiblary.

***
*/

#ifndef NICTLOPTIONS_OPTION_NAMES_H
#define NICTLOPTIONS_OPTION_NAMES_H

/*
    There are all module names for option check.
*/

#define OPTION_MODULE_NAMES_MAX 5
static const char* psOptionModuleNames[] = {
"NICTmmse",
"NICTmfcc",
"NICTcms",
"NICTvad",
};

/*
    There are all option names for option check.
*/

#define OPTION_OPTION_NAMES_MAX 33

static const char* psOptionOptionNames[] = {
  "amp",
  "attrate",
  "boundary",
  "CMSType",
  "CleanSpeechGMM",
  "command",
  "config",
  "connection",
  "debug",
  "delay",
  "dimension",
  "directory",
  "file",
  "file_list",
  "first",
  "freq",
  "help",
  "host",
  "InitialNoiseLength",
  "lda",
  "n",
  "optionslist",
  "paramsize",
  "paramtype",
  "position",
  "receiver",
  "sample_rate",
  "second",
  "subtract",
  "timeout",
  "vad",
  "version",
  "ZeroPadLength",
};

#endif  /*  NICTLOPTIONS_OPTION_NAMES_H  */

/*  end of NICToptions_option_names.h  */
