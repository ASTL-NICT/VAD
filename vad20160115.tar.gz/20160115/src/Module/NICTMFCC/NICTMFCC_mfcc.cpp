﻿/*-----------------------------------------------------------------------------
 NICTmfcc class
-------------------------------------------------------------------------------
 Copyright (C) 2012 - 2016
   National Institute of Information and Communications Technology.
   All rights reserved.
-----------------------------------------------------------------------------*/

#include <cmath>

#include "NICTmfcc.h"

using namespace std;

static double PI=3.14159265358979;

// MFCC 計算クラスのメンバ関数定義

// 特徴量の計算関数

void MFCC::calc_parvec(void){

  while(FBank->outnum()>0){

    // フィルタバンク係数の取得

    vector <double> fbank=FBank->out();

    // 特徴量の計算

    vector <double> parvec;

    // pow の計算

    parvec.push_back(fbank[FBankLen]);

    // c0 の計算

    double nor=sqrt(2.0/(double)(FBankLen));

    double c0=0.0;
    for(int k=1;k<=FBankLen;k++)c0+=fbank[k-1];
    c0*=nor;

    parvec.push_back(c0);

    // cep の計算

    double fac=PI/(double)(FBankLen);

    for(int i=1;i<=CepLen;i++){
      double cep=0.0;
      double x=(double)i*fac;
      for(int j=1;j<=FBankLen;j++){
	cep+=fbank[j-1]*cos(x*(j-0.5));
      }
      cep*=nor;
      parvec.push_back(cep);
    }

    Parvec.push_back(parvec);
  }

  return;
}

// コンストラクタとディストラクタ関数

MFCC::MFCC(int ceplen,int fbanklen,int zerolen,int winlen,int shiftlen,
	   int smpfreq,double lowcutoff,double highcutoff,double preemp){
  FBank=new FBANK(fbanklen,zerolen,winlen,shiftlen,smpfreq,lowcutoff,
		  highcutoff,preemp);
  FBankLen=fbanklen;
  ShiftLen=shiftlen;
  CepLen=ceplen;
}

MFCC::~MFCC(void){
  delete FBank;
}

// 音響分析条件の取得関数

int MFCC::get_ceplen(void) const{
  return(CepLen);
}

int MFCC::get_fbanklen(void) const{
  return(FBankLen);
}

int MFCC::get_winlen(void) const{
  return(FBank->get_winlen());
}

int MFCC::get_shiftlen(void) const{
  return(ShiftLen);
}

int MFCC::get_smpfreq(void) const{
  return(FBank->get_smpfreq());
}

double MFCC::get_lowcutoff(void) const{
  return(FBank->get_lowcutoff());
}

double MFCC::get_highcutoff(void) const{
  return(FBank->get_highcutoff());
}

double MFCC::get_preemp(void) const{
  return(FBank->get_preemp());
}

// 初期化関数

void MFCC::clear(void){
  FBank->clear();
  Parvec.clear();
  return;
}

// 音声波形の入力関数

void MFCC::in(const short int * wave){
	
  FBank->in(wave);
  calc_parvec();

  return;
}

void MFCC::in(const vector <short int> & wave){


  short int *framewave;
  framewave = new short int[ShiftLen];

  //short int framewave[ShiftLen];



  for(int t=0;t<ShiftLen;t++)framewave[t]=wave[t];
  in(framewave);

  delete [] framewave;

  return;
}

// 音声波形の入力終了関数

void MFCC::flush(void){
  FBank->flush();
  calc_parvec();
  return;
}

// MFCC 特徴量の取得関数

int MFCC::outnum(void) const{
  return((int)Parvec.size());
}

vector <double> MFCC::out(void){
  vector <double> ret=Parvec[0];
  Parvec.erase(Parvec.begin());
  return(ret);
}
