﻿/*------------------------------------------------------------------------------
// 音響特徴量計算プログラム NICTMFCC_main
//    for NICTASR_lib     #S-532
//------------------------------------------------------------------------------
// Copyright (C) 2012 - 2016
//   National Institute of Information and Communications Technology.
//   All rights reserved.
//----------------------------------------------------------------------------*/

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>

#include <string>
#include <vector>

#include "NICTmfcc.h"
#include "NICTdelta.h"

using namespace std;

NICTmfcc::NICTmfcc()
{
  pEvent       = NULL ;
  pOption      = NULL ;
  pcmfccOptions  = NULL ;
  options_id   = 0 ;
  pCep  		 = NULL;
  pDel 		 = NULL;
  pAcc 		 = NULL;

  EventTbl.clear() ;
}

NICTmfcc::NICTmfcc(NICTevent2 *event, NICToptions *option)
{
  pEvent       = event ;
  pOption      = option ;
  pcmfccOptions  = NULL ;
  options_id   = 0 ;
  pCep  		 = NULL;
  pDel 		 = NULL;
  pAcc 		 = NULL;
  EventTbl.clear() ;
}

NICTmfcc::~NICTmfcc()
{
  // LocalEvent領域を解放する
  if( !EventTbl.empty() ) {
    intFloatStar *ptr ;
    int size = EventTbl.size() ;
    for( int i = 0 ; i < size ; i++ ) {
      ptr = EventTbl[i] ;
      if( ptr->fs ) free( ptr->fs ) ;
      free( ptr ) ;
    }
  }
}

int NICTmfcc::Initialize( int argn, char *argv[] )
{
  int     iRetVal;
  char*   optionvaluebox = NULL;


  /* ---------- options envelop start ---------- */
	



	
  const char default_options[] = "\
    FilterBankOrder=20\n\
    FrameLength=20.0\n\
    FrameShift=10.0\n\
    ZeroPadLength=10.0\n\
    SamplingFrequency=16000\n\
    CutoffHighFrequency=8000.0\n\
    CutoffLowFrequency=0.0\n\
    Preemphasis=0.98\n\
    CepstrumOrder=12\n\
    DeltaCepstrumWindow=2\n\
    Parameter=pow+cep+dpow+dcep\n\
    ";



   	
  /*  Get Options  */
  iRetVal = pOption->ReadMain( argn, argv, &options_id, NICT_MFCC_STR,
			       default_options, OPT_PrintOptList |OPT_PrintSetOptList );

  if( iRetVal == OPT_FAILURE ) {
    fprintf( stderr, "@NICTmfcc ERROR: Invalid argument.\n" );
    return( 1 );
  }

  /****  parse options  ****/

  cmfccOptions.FilterBankOrder = 20;
  cmfccOptions.FrameLength = 20.0;
  cmfccOptions.FrameShift = 10.0;
  cmfccOptions.ZeroPadLength = 10.0;
  cmfccOptions.SamplingFrequency = 16000;
  cmfccOptions.CutoffHighFrequency = 8000.0;
  cmfccOptions.CutoffLowFrequency = 0.0;
  cmfccOptions.Preemphasis = 0.98;
  cmfccOptions.CepstrumOrder = 12;
  cmfccOptions.DeltaCepstrumWindow = 2;
  cmfccOptions.Parameter = "pow+cep+dpow+dcep";  	


  pcmfccOptions = &cmfccOptions;


  /* FilterBankOrder */
  iRetVal = pOption->GetOptValue( options_id, "FilterBankOrder", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTmfcc_init: OPTIONLIB error in FilterBankOrder\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTmfcc_init ERROR : OPTION FilterBankOrder is not setting.\n" ) ;
    return( 1 );
  }
  pcmfccOptions->FilterBankOrder = atoi(optionvaluebox);

  if( pcmfccOptions->FilterBankOrder <= 0 ) {
    fprintf( stderr,  "@NICTmfcc_init ERROR : OPTION FilterBankOrder is out of range.\n" ) ;
    return( 1 );
  }

  free( optionvaluebox );


  /* FrameLength */
  iRetVal = pOption->GetOptValue( options_id, "FrameLength", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTmfcc_init: OPTIONLIB error in FrameLength\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTmfcc_init ERROR : OPTION FrameLength is not setting.\n" ) ;
    return( 1 );
  }
  pcmfccOptions->FrameLength = atof(optionvaluebox);

  if( pcmfccOptions->FrameLength <= 0.0 ) {
    fprintf( stderr,  "@NICTmfcc_init ERROR : OPTION FrameLength is out of range.\n" ) ;
    return( 1 );
  }

  free( optionvaluebox );


  /* FrameShift */
  iRetVal = pOption->GetOptValue( options_id, "FrameShift", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTmfcc_init: OPTIONLIB error in FrameShift\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTmfcc_init ERROR : OPTION FrameShift is not setting.\n" ) ;
    return( 1 );
  }
  pcmfccOptions->FrameShift = atof(optionvaluebox);

  if( pcmfccOptions->FrameShift <= 0.0 ) {
    fprintf( stderr,  "@NICTmfcc_init ERROR : OPTION FrameShift is out of range.\n" ) ;
    return( 1 );
  }

  free( optionvaluebox );

  /* ZeroPadLength */
  iRetVal = pOption->GetOptValue( options_id, "ZeroPadLength", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTmfcc_init: OPTIONLIB error in ZeroPadLength\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTmfcc_init ERROR : OPTION ZeroPadLength is not setting.\n" ) ;
    return( 1 );
  }

  pcmfccOptions->ZeroPadLength = atof(optionvaluebox);


  if( pcmfccOptions->ZeroPadLength < 0.0 ) {
    fprintf( stderr,  "@NICTmfcc_init ERROR : OPTION ZeroPadLength is out of range.\n" ) ;
    return( 1 );
  }
  free( optionvaluebox );


  /* SamplingFrequency */
  iRetVal = pOption->GetOptValue( options_id, "SamplingFrequency", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTmfcc_init: OPTIONLIB error in SamplingFrequencyt\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTmfcc_init ERROR : OPTION SamplingFrequency is not setting.\n" ) ;
    return( 1 );
  }
  pcmfccOptions->SamplingFrequency = atoi(optionvaluebox);

  if( pcmfccOptions->SamplingFrequency <= 0 ) {
    fprintf( stderr,  "@NICTmfcc_init ERROR : OPTION SamplingFrequency is out of range.\n" ) ;
    return( 1 );
  }
  free( optionvaluebox );


  /* CutoffHighFrequency */
  iRetVal = pOption->GetOptValue( options_id, "CutoffHighFrequency", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTmfcc_init: OPTIONLIB error in CutoffHighFrequency\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTmfcc_init ERROR : OPTION CutoffHighFrequency is not setting.\n" ) ;
    return( 1 );
  }
  pcmfccOptions->CutoffHighFrequency = atof(optionvaluebox);

  if( pcmfccOptions->CutoffHighFrequency < 0.0 ) {
    fprintf( stderr,  "@NICTmfcc_init ERROR : OPTION CutoffHighFrequency is out of range.\n" ) ;
    return( 1 );
  }
  free( optionvaluebox );


  /* CutoffLowFrequency */
  iRetVal = pOption->GetOptValue( options_id, "CutoffLowFrequency", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTmfcc_init: OPTIONLIB error in CutoffLowFrequency\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTmfcc_init ERROR : OPTION CutoffLowFrequency is not setting.\n" ) ;
    return( 1 );
  }
  pcmfccOptions->CutoffLowFrequency = atof(optionvaluebox);

  if( pcmfccOptions->CutoffLowFrequency < 0.0 ) {
    fprintf( stderr,  "@NICTmfcc_init ERROR : OPTION CutoffLowFrequency is out of range.\n" ) ;
    return( 1 );
  }
  free( optionvaluebox );


  /* Preemphasis */
  iRetVal = pOption->GetOptValue( options_id, "Preemphasis", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTmfcc_init: OPTIONLIB error in Preemphasis\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTmfcc_init ERROR : OPTION Preemphasis is not setting.\n" ) ;
    return( 1 );
  }
  pcmfccOptions->Preemphasis = atof(optionvaluebox);
  free( optionvaluebox );

 	
  /* CepstrumOrder */
  iRetVal = pOption->GetOptValue( options_id, "CepstrumOrder", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTmfcc_init: OPTIONLIB error in CepstrumOrder\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTmfcc_init ERROR : OPTION CepstrumOrder is not setting.\n" ) ;
    return( 1 );
  }
  pcmfccOptions->CepstrumOrder = atoi(optionvaluebox);

  if( pcmfccOptions->CepstrumOrder <= 0 ) {
    fprintf( stderr,  "@NICTmfcc_init ERROR : OPTION CepstrumOrder is out of range.\n" ) ;
    return( 1 );
  }
  free( optionvaluebox );


  /* DeltaCepstrumWindow */
  iRetVal = pOption->GetOptValue( options_id, "DeltaCepstrumWindow", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTmfcc_init: OPTIONLIB error in DeltaCepstrumWindow\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTmfcc_init ERROR : OPTION DeltaCepstrumWindow is not setting.\n" ) ;
    return( 1 );
  }
  pcmfccOptions->DeltaCepstrumWindow = atoi(optionvaluebox);

  if( pcmfccOptions->DeltaCepstrumWindow <= 0 ) {
    fprintf( stderr,  "@NICTmfcc_init ERROR : OPTION DeltaCepstrumWindow is out of range.\n" ) ;
    return( 1 );
  }
  free( optionvaluebox );



  /* Parameter */
  iRetVal = pOption->GetOptValue( options_id, "Parameter", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTmfcc_init: OPTIONLIB error in Parameter\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTmfcc_init ERROR : OPTION Parameter is not setting.\n" ) ;
    return( 1 );
  }

  pcmfccOptions->Parameter = (string)optionvaluebox;

  char *buf;
  buf = new char[pcmfccOptions->Parameter.size()+1];

  strcpy(buf,pcmfccOptions->Parameter.c_str());

  for(char * token=strtok(buf,"+");token;token=strtok(NULL,"+")){

    string tmp = (string)token;

    if(tmp!="cep" && tmp!="dcep" && tmp!="ddcep" &&
       tmp!="c0" && tmp!="dc0" && tmp!="ddc0" &&
       tmp!="pow" && tmp!="dpow" && tmp!="ddpow" )
      fprintf( stderr,  "@NICTmfcc_init ERROR : OPTION Parameter are different\n" ) ;

    kind.push_back(tmp);
  }


   	
  free( optionvaluebox );
  delete [] buf;


  // 音響特徴量計算用オブジェクトの設定

  bool use_delta = false , use_accel = false;

  for( int n = 0 ; n < (int)kind.size() ; n++ ){
    if(kind[n] == "dcep" ||kind[n] == "dc0" ||kind[n] == "dpow" ) use_delta=true;
    if(kind[n] == "ddcep"||kind[n] == "ddc0"||kind[n] == "ddpow") use_accel=true;
  }
  if(use_accel == true) use_delta = true;

  winlen   = (int)((double)pcmfccOptions->SamplingFrequency*0.001*pcmfccOptions->FrameLength    + 0.5);
  shiftlen = (int)((double)pcmfccOptions->SamplingFrequency*0.001*pcmfccOptions->FrameShift     + 0.5);
  zerolen  = (int)((double)pcmfccOptions->SamplingFrequency*0.001*pcmfccOptions->ZeroPadLength  + 0.5);

  //#ifdef D714
  //    printf("winlen=%d\n",winlen);
  //    printf("shiftlen=%d\n",shiftlen);
  //    printf("zerolen=%d\n",zerolen);
  //#endif


  pCep = new MFCC(pcmfccOptions->CepstrumOrder,pcmfccOptions->FilterBankOrder,zerolen,winlen,shiftlen,
		  pcmfccOptions->SamplingFrequency,pcmfccOptions->CutoffLowFrequency,pcmfccOptions->CutoffHighFrequency,pcmfccOptions->Preemphasis);

  if ( use_delta )pDel = new DELTA( pcmfccOptions->CepstrumOrder + 2 , pcmfccOptions->DeltaCepstrumWindow );
  if ( use_accel )pAcc = new DELTA( pcmfccOptions->CepstrumOrder + 2 , pcmfccOptions->DeltaCepstrumWindow );


  // パケットの準備

  veclen = 0;
  for(int n = 0 ; n < (int)kind.size() ; n++){
    if( kind[n] == "cep" || kind[n] == "dcep" || kind[n] == "ddcep" ) veclen += pcmfccOptions->CepstrumOrder;
    else if(kind[n] == "c0" || kind[n] == "dc0" || kind[n] == "ddc0" || kind[n] == "pow" || kind[n] == "dpow" || kind[n] == "ddpow") veclen++;
  }

  // intFloatStarを2個作成して置く
  EventUseIndex = 0 ;
  for( int i = 0 ; i < 2 ; i++ ) {
    if( GetLocalEvent() == NULL ) return 1 ;
  }
  return 0;
}


void NICTmfcc::Terminate( int arg )
{
  if( pCep ) delete(pCep);
  if( pDel ) delete(pDel);
  if( pAcc ) delete(pAcc);
}

void NICTmfcc::Execute( int eventType, EventNICT *event )
{
  vector <float> parvec;

  intShortStar* piss = (intShortStar*)event->message_body;
  EventUseIndex = 0 ;
  switch( event->message_type ) {
  case INITIALIZE:
    break;

  case EV_KILL:
    pEvent->PutEvent( NICT_PROCESS, NORMAL_EXIT, NULL );
    break;

  case EV_ABEND:
    pEvent->PutEvent( NICT_PROCESS, ERROR_EXIT, NULL );
    break;
     	
  case EPV_DATA:
    in(piss->ss);
    while( outnum() > 0){
      parvec = out(kind);
      intFloatStar *ptr = GetLocalEvent() ;
      ptr->i = parvec.size() ;
      for(int d = 0 ; d < (int)parvec.size() ; d++) ptr->fs[d] = parvec[d] ;
      pEvent->PutEvent( NICTD_CEP, EPV_DATA, (EventNICT*)ptr);							
    }
    break;
	
  case EV_TOF:
    clear();
    pEvent->PutEvent( NICTD_CEP, EV_TOF, NULL );	
    break;
	
  case EV_EOF:
    pEvent->PutEvent( NICTD_CEP, EV_EOF, NULL );	
    break;        			
  	
  case EPV_STARTPU:
    pEvent->PutEvent( NICTD_CEP, EPV_STARTPU, NULL );	
    break;
	
  case EPV_ENDPU:
    flush();
    while(outnum() > 0){
      parvec = out(kind);
      intFloatStar *ptr = GetLocalEvent() ;
      ptr->i = parvec.size() ;
      for(int d = 0 ; d < (int)parvec.size() ; d++) ptr->fs[d] = parvec[d] ;
      pEvent->PutEvent( NICTD_CEP, EPV_DATA, (EventNICT*)ptr);							
    }			
    pEvent->PutEvent( NICTD_CEP, EPV_ENDPU, NULL );	
    break;

  case EV_ABORT:    /* cancel of speech */
    pEvent->PutEvent( NICTD_CEP, EV_ABORT, NULL );
    break;
	
  default:
    break;
  }
}	


/// private sub

// 初期化関数

void NICTmfcc::clear(void){

  pCep->clear();

  if( pDel != NULL ) pDel->clear();
  if( pAcc != NULL ) pAcc->clear();

  CepBuf.clear();
  DelBuf.clear();
  AccBuf.clear();

  return;
}

// 音声波形の入力関数

void NICTmfcc::in(const short int * wave){
	
  pCep->in(wave);

  while( pCep->outnum()!=0 ){

    vector <double> parvec = pCep->out();
    CepBuf.push_back(parvec);

    if(pDel!=NULL) pDel->in(parvec);
  }

  if(pDel != NULL) {
    while( pDel->outnum()!=0){
      vector <double> parvec = pDel->out();
      DelBuf.push_back(parvec);
      if( pAcc!=NULL ) pAcc->in(parvec);
    }
  }

  if( pAcc != NULL ){
    while( pAcc->outnum()!=0 ){
      vector <double> parvec = pAcc->out();
      AccBuf.push_back(parvec);
    }
  }

  return;
}

// 音声波形の入力終了関数

void NICTmfcc::flush(void){

  pCep->flush();

  while( pCep->outnum() != 0 ){
    vector <double> parvec = pCep->out();
    CepBuf.push_back(parvec);
    if( pDel != NULL ) pDel->in(parvec);
  }

  if( pDel != NULL ){
    pDel->flush();
    while( pDel->outnum() != 0 ){
      vector <double> parvec = pDel->out();
      DelBuf.push_back(parvec);
      if( pAcc!=NULL ) pAcc->in(parvec);
    }
  }

  if( pAcc != NULL){
    pAcc->flush();
    while( pAcc->outnum() != 0){
      vector <double> parvec = pAcc->out();
      AccBuf.push_back(parvec);
    }
  }

  return;
}

// 音響特徴量の出力関数

int NICTmfcc::outnum(void){

  int num = (int)CepBuf.size();

  if( pDel != NULL ) if((int)DelBuf.size()<num) num = (int)DelBuf.size();
  if( pAcc != NULL ) if((int)AccBuf.size()<num) num = (int)AccBuf.size();

  return( num );
}


vector<float> NICTmfcc::out(const vector <string> & kind){

  int ceplen = (int)CepBuf[0].size()-2;
  vector <float> parvec;

  for(int n=0 ; n < (int)kind.size() ; n++){
    if(kind[n]=="cep"  ){
      for(int d=0 ; d<ceplen ; d++) parvec.push_back((float)CepBuf[0][d+2]);
    }else if(kind[n] == "dcep" ){
      for(int d=0 ; d<ceplen ; d++) parvec.push_back((float)DelBuf[0][d+2]);
    }else if(kind[n] == "ddcep"){
      for(int d=0	; d<ceplen ; d++) parvec.push_back((float)AccBuf[0][d+2]);
    }else if(kind[n] == "c0"   ){
      parvec.push_back((float)CepBuf[0][1]);
    }else if(kind[n] == "dc0"  ){
      parvec.push_back((float)DelBuf[0][1]);
    }else if(kind[n] == "ddc0" ){
      parvec.push_back((float)AccBuf[0][1]);
    }else if(kind[n] == "pow"  ){
      parvec.push_back((float)CepBuf[0][0]);
    }else if(kind[n] == "dpow" ){
      parvec.push_back((float)DelBuf[0][0]);
    }else if(kind[n] == "ddpow"){
      parvec.push_back((float)AccBuf[0][0]);
    }
  }

  CepBuf.erase( CepBuf.begin() );

  if( pDel != NULL ) DelBuf.erase(DelBuf.begin());
  if( pAcc != NULL ) AccBuf.erase(AccBuf.begin());

  return(parvec);
}

// データタイプ・個数取得処理
void NICTmfcc::GetDataParam( int *in_size1, int *in_size2, int *out_size1, int *out_size2)
{

  *in_size1 = DEF_SHORT;
  *in_size2 = shiftlen ;

  *out_size1 = DEF_FLOAT;
  *out_size2 = veclen;

  return;
}

// intFloatStar型の領域を確保して、そのポインタを返す。
// 既存領域がある場合は生成しない。
intFloatStar* NICTmfcc::GetLocalEvent()
{
  intFloatStar* ptr ;

  if( EventUseIndex < (int)EventTbl.size() ) {
    ptr = EventTbl[EventUseIndex] ;
  }
  else {
    ptr = (intFloatStar*)malloc(sizeof(intFloatStar)) ;
    if( ptr == NULL ) {
      fprintf( stderr, "NICTmfcc_execute: Cannot alloc memory for local_data\n" );
      return NULL ;
    }
    ptr->i  = veclen ;
    ptr->fs = (float*)malloc( sizeof(float) * veclen ) ;
    if( ptr->fs == NULL ) {
      fprintf( stderr, "NICTmfcc_execute: Cannot alloc memory for local_data.fs\n" );
      free( ptr ) ;
      return NULL ;
    }
    EventTbl.push_back( ptr ) ;
  }
  EventUseIndex++ ;

  return ptr ;
}
