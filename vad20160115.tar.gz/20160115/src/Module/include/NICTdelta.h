﻿/*-----------------------------------------------------------------------------
 DELTA class
-------------------------------------------------------------------------------
 Copyright (C) 2012 - 2016
   National Institute of Information and Communications Technology.
   All rights reserved.
-----------------------------------------------------------------------------*/

#ifndef DELTA_HH

#define DELTA_HH

#include<vector>

using namespace std;

// 時間微分特徴量計算クラス

class DELTA{
private:
  int                          VecLen;        // ベクトル長
  int                          DeltaWinLen;   // 時間微分窓幅

  double                    ** ParvecBuf;     // 時間微分計算用バッファ
  int                          ParvecNum;     // データ数
  double                       Denom;         // 分母定数

  vector <vector <double> >    DeltaBuf;      // 時間微分特徴量

  // 時間微分特徴量の計算関数
  void calc_delta(void);

public:
  // コンストラクタとディストラクタ関数
   DELTA(int veclen,int deltawinlen);
  ~DELTA(void);

  // 計算条件の取得関数
  int get_veclen     (void) const;
  int get_deltawinlen(void) const;

  // 初期化関数
  void clear(void);

  // 特徴ベクトルの入力関数
  void in(const vector <double> & parvec);

  // 特徴ベクトルの入力終了関数
  void flush(void);

  // 時間微分特徴量の取得関数
  int outnum(void) const;
  vector <double> out(void);

};

#endif
