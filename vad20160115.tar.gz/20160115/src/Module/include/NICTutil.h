/*------------------------------------------------------------------------------
// include file for Utility Library function.
//------------------------------------------------------------------------------
// Copyright (C) 2009 - 2016
//   National Institute of Information and Communications Technology.
//   All rights reserved.
//----------------------------------------------------------------------------*/

# ifndef NICTUTIL_H
# define NICTUTIL_H

#include <stdio.h>        /* for NICT_ERROR printing, and NICTutil_fopen */
#include <stdlib.h>       /* for malloc, realloc */
#include <string.h>       /* for memcpy (OSF1) */

//#include "NICToptions.h"  /* Ben: %TODO% split this out */

/* this is needed because it might not be defined, e.g. in compiling SIGNALLIB */
#ifdef UTILLIB_VERSION
static const char NICTutilLibraryVersion[] = UTILLIB_VERSION ; /* HS: defined in EVENTLIB/makefile */
#endif

/* ---------------------------------------------------------------------- */
/* Some useful data structures */
struct intDoubleStar { int i; double *ds; };
struct intIntStar    { int i; int *is; };
struct intShortStar  { int i; short *ss; };
struct intFloatStar  { int i; float *fs; };

/* a=fopen(b,c) -> NICTutil_fopen(b,c,&a) */
int NICTutil_fopen (char *name, char *mode, FILE **);
int NICTutil_bcopy( const char *src, char *dest, int nBytes ); /* bcopy() */
int NICTutil_memmove( char *dest, const char *src, int nBytes ); /*memmove*/

/* -------- debug routines - obvious from the name what it does ---------- */
void NICTutil_dp_DoubleStarStar( char *message, int y, int x, double **pointer);
void NICTutil_dp_DoubleStar( char *message, int x, double *pointer );
void NICTutil_printEnum(int, char *);  /* NICTutil_misc.c: print an enum value */
void NICTutil_printapointer(FILE *fp, void *p);    /* system-independently... */
void NICTutil_misc_print_event_queue(char*,int,int[],int[],void*[],int,int);

/* -------- more debug routines ----------- */
void NICTevent_print_star(int reset);      /* WriteFrameSync.c, show activity */

/* Here's an easy-to-use debug printing macro.  It's the closest
 * I can get to C++'s cout for any object.
 * Usage example:  NICT_P( int, i )
 * Result on stderr: NICT_P NICTsignal_cep2dcep.c 55 int i = 67
 * This requires NICTutil_print_anything to work
 */
#define NICT_P(a,b) NICTutil_print_anything( __FILE__, __LINE__, (#a), (#b), &(b) )

void NICTutil_print_anything( char *filename, int lineno, char *type
                                                   , char *message, void *value );

/* -------- error handling. ----------- */

#define NICT_RETURN(m) { NICT_ERROR(1,m); return 1; }

/* Usage: if(f(x)) NICT_RETURN("f failed")
 * (Ben thinks out loud here:
 * - Assumes that it returns an int, and nonzero means an error
 * - Only a string is allowed.
 * - Why not use a global flag like NICTutil_error_is_set?
 *   because when you test it you need to escape from the
 *   procedure immediately.  What do you return?  What type?
 *   It's got to be consistent: has to be an int.
 *   So why not use that int to mean an error?
 * - I have an idea: it returns a string which is the error.
 *   But then, I'd have to push the string on the error stack
 *   after every procedure call.  Ugly, and similar in a way
 *   to what I'm doing here anyway.  Don't put all those strings
 *   on the stack; I think it's risky.
 */

#define NICT_TRAP(a) { int I = (int)(a); if(I){ NICT_ERROR(1,#a); return (I); }}

/* Even easier, using a compiler trick that works on all supported compilers:
 *
 * Usage:   NICT_TRAP( iFunction( arg1, arg2 ) );
 *
 * Behavior: if iFunction returns nonzero, then return nonzero from here.
 * Also, put into the error stack the string "iFunction( arg1, arg2 )"
 * Assumptions: I return 0 for success or nonzero int for failure;
 *              and iFunction does the same.
 *
 * Danger: #a (below) transforms (a) into a string.  It works with gcc -ansi,
 * but is this standard?
 *
 * Danger: Do not use this with NICToption_ functions which return 0 for failure.
 * (unless NICTASR/src/include/NICToption.h has been fixed to set SUCCESS to 0)
 */
#define NICT_VTRAP(a) {                                       \
   int I = (int)(a);                                         \
   if( I ) {                                                 \
     NICT_ERROR(1,#a);                                        \
     NICTevent_send_event( NICT_PROCESS, ERROR_EXIT, NULL );   \
     return;                                                 \
   }                                                         \
 }

/* Usage is same as NICT_TRAP but NICT_VTRAP is for use when
 * I do not return an int, as in NICTepd_exec()
 * and other NICT*_exec().
 */


#define NICT_VRETURN(a) {                                   \
   NICT_ERROR(1,#a);                                        \
   NICTevent_send_event( NICT_PROCESS, ERROR_EXIT, NULL );   \
   return;                                                 \
}

/* Usage is same as NICT_RETURN but within *_exec procedures
 */


/* ------------------------------------- Error Handler ----------------- */
/*
 * Usage
 *  Example: a file can't be opened.  Do this:
 *   if (fp==NULL) {
 *     NICT_ERROR_S(1,"Cant open file", filename);  // _S means String,
 *     return NULL;                                // 1 is the error "level"
 *   }
 *   If you need to report a number instead of a string, do this:
 *   if (a < 0) NICT_ERROR_D(1,"a is negative! a = ", a);   // _D means double; we have also an _I for integer
 *                                                // (but float or int is OK)
 *
 *   If you need to report only a fixed message and no arguments:
 *   NICT_ERROR(1,"This case indicates a problem in the input");
 *
 * To print out the stack, use NICT_ERROR_P()
 *   Where 1 is the level.  This will do the following:
 *     - on stderr it will print a line like this:
 *      NICT_ERROR"main.c", line 30: a is negative! a = -5.00
 *    - call getchar()         (this is useful in gdb)
 *    - exit
 *
 *   NICT_ERROR_CP(1);  // check for errors; if found, print them out.
 *                     // (CP stands for Check-and-Print)
 *
 * One can print out errors with a more free format this way:
 * if (error_condition) {
 *    sprintf(NICT_ERROR_STRING(),
 *      "string %s int %d != float %f", s, i, x);
 *    NICT_ERROR(1,NICT_ERROR_STRING());
 *    }
 * The above is safer than allocating a string on the stack.
 *
 *
 * Q1: Why not allow multiple arguments like
 *     E(1,"a is %d and b is %f and c is %f\n", a, b, c)  // note that %lf is a nono
 * Q2: Why do you need separate NICT_ERROR_D and NICT_ERROR_S?  Why not
 *     E(1,"a is %d\n", a)
 *
 * A1: Because of the implementation, which is as follows:
 *     In NICTutil.h, I have a line like this:
 *     #define E(x,y,z) e(__LINE__,__FILE__,x,y,(double)z)
 *     and in utilNICT.c, I define the e() procedure whose prototype is
 *     e(int line, char *file, int level, char *message, double value)
 *     The E macro can not take a variable number of arguments.  That's
 *     the reason.  Why do I use a macro?  To get __LINE__ and __FILE__
 *     in the error message properly.  These are useful for debugging.
 *
 * A2: Good question.  If I allow strings as well as ints and doubles
 *     for the last argument, then what shall I use as the prototype
 *     for e()? [see A1]  You might say I should just have the caller
 *     pass a pointer; I have no trouble with that but then
 *
 * Please remember this: when the Error Handler is called, something is
 * wrong with the software.  The stack may have been overwritten, or
 * a pointer may be running wild.  So this portion of the code must be
 * very safe: no dynamic allocation of arrays, no variable arguments.
 * The stack and heap may be unreliable.
 */

void NICTutil_error_S_proc( int, char *, int, char *, char *);  /* NICTutil_error.c */
void NICTutil_error_D_proc( int, char *, int, char *, double ); /* NICTutil_error.c */
void NICTutil_error_I_proc( int, char *, int, char *, int );    /* NICTutil_error.c */
void NICTutil_error_P_proc(void); 		                       /* NICTutil_error.c */
int NICTutil_error_check(void);		                       /* NICTutil_error.c */
char *NICTutil_error_string_proc(void);                         /* NICTutil_error.c */
char *NICTutil_error_print_to_string(void);                     /* NICTutil_error.c */

#define NICT_ERROR_S(l,a,b) NICTutil_error_S_proc(__LINE__,__FILE__,(l),(a),(char *)(b))
#define NICT_ERROR_D(l,a,b) NICTutil_error_D_proc(__LINE__,__FILE__,(l),(a),(double)(b))
#define NICT_ERROR_I(l,a,b) NICTutil_error_I_proc(__LINE__,__FILE__,(l),(a),(int)(b))
#define NICT_ERROR(l,a)     NICTutil_error_S_proc(__LINE__,__FILE__,(l),(a), "")
#define NICT_ERROR_P()      NICTutil_error_P_proc()
#define NICT_ERROR_CHECK()  NICTutil_error_check()
#define NICT_ERROR_CP()     {if(NICT_ERROR_CHECK()){NICT_ERROR_P();}}
#define NICT_ERROR_STRING() (NICTutil_error_string_proc()) /* returns a char* for scratch */

/* ---------------------------------------------------------------------- */

#include <stdio.h>        /* for NICT_ERROR printing, and NICTutil_fopen */
#include <stdlib.h>       /* for malloc, realloc */
#include <string.h>       /* for memcpy (OSF1) */


/* ---------------------------------------------------------------------- */

/* Usage is similar to calloc(3), but check for errors
   and get File&Line# info from where it was called.
   To get that, we need a macro to call a subroutine.
   */
#define NICT_CALLOC(a,b) NICTutil_calloc((a),(b))
void * NICTutil_calloc ( int nitems, int size );

/* More useful is this: newStructure = NICT_ALLOC( 1, struct someStruct )
   replaces: newStructure = (someStruct *) calloc( 1, sizeof(struct someStruct));
 */
#define NICT_ALLOC(c,d) ((d *)NICT_CALLOC((c), sizeof(d)))
#define NICT_SALLOC(c)  (NICT_CALLOC((c), sizeof(char)))

/* Let's do the same for realloc and free */
#define NICT_REALLOC(a,b) NICTutil_realloc((a),(b))
void *  NICTutil_realloc( void *, int size );
#define NICT_FREE(a)    NICTutil_free((a))
void    NICTutil_free( void * );

/* Same as the above, but for 2D arrays */
void ** NICTutil_calloc2d( int n, int m, int elementSize );
void    NICTutil_free2d( void ** pointer );

/* ---------------------------------------------------------------------- */
/* This essentially implements a FIFO (stream, pipe, double-ended buffer)
   which can hold doubles.  The purpose is to synchronize the
   input stream reads with the frame-synchronous process.

   Usage example:

   double vector[] = {1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0};
   struct vos *s;
   NICTutil_fifoInit(5, &s); // allocate 5 words of memory; uninitialized.
   NICTutil_fifoAppendBuffer( s, buffer, 4 );  // contents are 1,2,3,4
   NICTutil_fifoTakeBuffer( s, buffer, 3 );    // contents of buffer are 1,2,3
                                        // but only 4 remains in the FIFO
   NICTutil_fifoHowMany( s, &i );              // i==1 (only one value, 4)

   Note: NICTutil_fifoAppendBuffer() will realloc if the FIFO grows, but not
                              if it shrinks.
   */


struct vos {
  double *buffer;    /* The "overflow" is stored here */
  int   allocated;  /* In units of doubles, not bytes */
  int   used;       /* # of doubles in the buffer */
};

/* like "new". initialAllocation are in units of doubles, not bytes! */
int NICTutil_fifoInit(int initialAllocation, struct vos **);

/* All of these are in NICTutil_fifo.c */
int  NICTutil_fifoAppendBuffer( struct vos *vos, double *buffer, int howMany);
int  NICTutil_fifoClear( struct vos *vos );

/* buffer must be large enough to accept howMany elements */
int  NICTutil_fifoTakeBuffer( struct vos *vos, double *buffer, int howMany);
/* How many doubles are in use now? */
int  NICTutil_fifoHowMany( struct vos *vos, int *howMany );

#ifndef M_PI
#define M_PI        3.14159265358979323846      /* pi */
#endif

typedef	unsigned char	ulaw;

enum NICT_TYPE {       /* used in NICTevent_event.c */
  enum_float  = 1,
  enum_int    = 2,
  enum_double = 3,
  enum_short  = 4,
  enum_char   = 5,
  enum_long   = 6,
  enum_ulaw   = 7
};

/*	for	NICTutil_io.c	*/

char	*NICTutil_sub_string( char *, char *, int);
int	NICTutil_strnormcmp( char *, char *);
char	*NICTutil_get_full_path( char *, char *);
char	*NICTutil_get_all_files( char *, char *, void **);
int	NICTutil_freadx( char	*, int	, int	, FILE	*);
int	NICTutil_freadx2( char*, int, int, FILE* ) ;
int	NICTutil_fwritex( char	*, int	, int	, FILE	*);
int	NICTutil_create_dir( char	*);
int NICTutil_ConvertFloatLittleEndian ( void *val) ;
int NICTutil_ConvertIntLittleEndian ( void *val) ;
int NICTutil_ConvertShortLittleEndian ( void *val) ;
int NICTutil_ConvertDoubleLittleEndian ( void *val) ;

#define option_type_to_enum( o, e ) { \
                        if( strcmp( o, "float" ) == 0 ) { \
                                e = enum_float; \
                        } \
                        else if( strcmp( o, "int" ) == 0 ) { \
                                e = enum_int; \
                        } \
                        else if( strcmp( o, "double" ) == 0 ) { \
                                e = enum_double; \
                        } \
                        else if( strcmp( o, "short" ) == 0 ) { \
                                e = enum_short; \
                        } \
                        else if( strcmp( o, "char" ) == 0 ) { \
                                e = enum_char; \
                        } \
                        else if( strcmp( o, "long" ) == 0 ) { \
                                e = enum_long; \
                        } \
                        else if( strcmp( o, "ulaw" ) == 0 ) { \
                                e = enum_ulaw; \
                        } \
                        else { \
                                return( -1 ); \
                        } \
                }




#ifdef WIN32
#include "NICTwin.h"
#else
#ifdef	strcasecmp
#undef	strcasecmp
#endif
#define	strcasecmp( A, B )	NICTstrcasecmp( A, B )

#ifdef	strncasecmp
#undef	strncasecmp
#endif
#define	strncasecmp( A, B, C )	NICTstrncasecmp( A, B, C )
#endif



extern	int	NICTstrcasecmp( const char	*, const char	*);
extern	int	NICTstrncasecmp( const char	*, const char	*, int	n);

# endif       /* UTIL_H */
/* EOF */
