/*------------------------------------------------------------------------------
// include file for Coding for stream function.
//------------------------------------------------------------------------------
// Copyright (C) 2009 - 2016
//   National Institute of Information and Communications Technology.
//   All rights reserved.
//----------------------------------------------------------------------------*/

#ifndef _IOCODING_H_
#define _IOCODING_H_

#define BUFSIZE     3000

/* マクロ定義 */
//#define CODING 1
#ifdef CODING
#include "Coding.h"
#define ENCODEDATA(BUF,SIZE)    EncodeData(BUF,SIZE)
#define DECODEDATA(BUF,SIZE)    DecodeData(BUF,SIZE)
#else
#define ENCODEDATA(BUF,SIZE)
#define DECODEDATA(BUF,SIZE)
#endif

#endif
