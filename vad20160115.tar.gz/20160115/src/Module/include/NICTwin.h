﻿/*------------------------------------------------------------------------------
// NICTwin.h
//------------------------------------------------------------------------------
// Copyright (C) 2009 - 2016
//   National Institute of Information and Communications Technology.
//   All rights reserved.
//----------------------------------------------------------------------------*/
#ifndef ___NICTWin_
#define ___NICTWin_


//Windows移植用追加
//#ifdef _WINDOWS
#ifdef _WIN32
#include <io.h>
#include <direct.h>

#define STDIN_FILENO      0         /* Standard input. */
#define STDOUT_FILENO     1         /* Standard output. */
#define STDERR_FILENO     2         /* Standard error output. */

#ifndef _CONSOLE
#ifdef _WSTDERR
#undef	stderr
extern FILE *stderr;
#endif
#endif

#define popen(char1,char2) (_popen(char1,char2))
#define pclose(fp) (_pclose(fp))

#ifndef __cplusplus
#define close(fp) (_close(fp))
#endif

#define mkdir(dir,mode) (_mkdir(dir))

#define strcasecmp(char1,char2) (_stricmp(char1,char2))
#define strncasecmp(char1,char2,count) (_strnicmp(char1,char2,count))

//Windows移植用追加 VC.Net対応　VC6の場合次の2行を解除してください
//#define write(fp,buf,count) (_write(fp,buf,count))
//#define read(fp,buf,count) (_read(fp,buf,count))
#define sleep(msec) (Sleep(msec))

#define index(string,c) (strchr(string,c))
#define rindex(string,c) (strrchr(string,c))

#define getcwd(buffer,maxlen) (_getcwd(buffer,maxlen))


/* dummy */
#define sbrk(x) x

/* Symbolic constants for the access() function */
/* These must match the values found in <sys/file.h> */
#ifndef R_OK
#define R_OK 4
#define W_OK 2
#define X_OK 1
#define F_OK 0
#endif

// Windows 移植用追加 2009/06/09
#define NICT_COMPILED_DEFINED

#define	NICTASR_VERSION	"Ver1.0.0(Win32)"

#define NICTRESULT_VERSION  NICTASR_VERSION
#define NICTLATTICE_VERSION  NICTASR_VERSION
#define CEP2PARA_VERSION  NICTASR_VERSION
#define NICTREXTOOLS_VERSION  NICTASR_VERSION
#define EPD_VERSION  NICTASR_VERSION
#define EVENTLIB_VERSION  NICTASR_VERSION
#define RPCLIB_VERSION  NICTASR_VERSION
#define NICTSENDANS_VERSION  NICTASR_VERSION
#define NICTMAINGEN_VERSION  NICTASR_VERSION
#define MAINGENPY_VERSION  NICTASR_VERSION
#define NICTVITERBI_VERSION  NICTASR_VERSION
#define SSSLIB_VERSION NICTASR_VERSION
#define NICTDICTOOLS_VERSION NICTASR_VERSION
#define NICTFILTER_VERSION NICTASR_VERSION
#define NICTSENDSLF_VERSION NICTASR_VERSION
#define NICTINPUT_VERSION NICTASR_VERSION
#define NICTSRCONV_VERSION NICTASR_VERSION
#endif

#endif /* ___NICTWin_ */

/* EOF */
