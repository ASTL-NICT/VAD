﻿/*------------------------------------------------------------------------------
//
//------------------------------------------------------------------------------
// Copyright (C) 2011 - 2016
//   National Institute of Information and Communications Technology.
//   All rights reserved.
//----------------------------------------------------------------------------*/

#ifndef _NICTOPTIONS_H_
#define _NICTOPTIONS_H_

#include <stdio.h>
#include <ctype.h>
#include <time.h>
#include <string>
#include "OptionsParse.h"

//#define OPT_NICT_ERROR_LEVEL    1

#define OPT_PrintHelp           2
#define OPT_PrintDefWarn        4
#define OPT_PrintSetOptList     8
#define OPT_PrintOptList        16

/*  オプション設定の為のその他の定義  */
#define OPT_1                   "1"
#define OPT_0                   "0"
#define OPT_ON                  "on"
#define OPT_OFF                 "off"
#define OPT_TRUE                "true"
#define OPT_FALSE               "false"
#define OPT_EOF                 "eof"
#define OPT_STDIN               "stdin"
#define OPT_STDOUT              "stdout"
#define OPT_STDERR              "stderr"

//#define oPTIONSlISTdEFAULT      1
//#define oPTIONSlISTnOW          2
#define YesSTD                  1
#define NoSTD                   0

//#define FIXoptERRORlevel        OPT_NICT_ERROR_LEVEL
//#define ERROR_STACK_NUMB        OPT_NICT_ERROR_LEVEL       /*  エラースタックモジュールの為に  */

/*  固定オプションの処理の為のデータの定義  */
#define FIXoptOptionsList       "optionsList"
#define FIXoptConfig            "config"
#define FIXoptHelp              "help"
#define FIXoptVersion           "Version"
#define FIXoptDEFvalue          "path/fileName"
#define FIXoptDEFbool           "off"

#define NUMBER_OptionsList      0
#define NUMBER_ConfigFile       1

typedef struct _fix_options_data {
  int           optionflag ;
  const char          *name ;
  const char          *defvalue ;
} fixOptinsData ;

class NICToptions : public OptionsParse {
private:
    int             nowOptParseId ;
    int             iOptionCheckFlg;
    int				fixcount;
	fixOptinsData   fixoptions[4] ;

public:
    NICToptions() ;
    virtual ~NICToptions() ;

    int  ReadMainWithOptionNameCheck( int argc, char **argv, int *parseIdBox, const char *opt_grp, const char *cdo, int msgSw ) ;
    int  ReadMain( int argc, char **argv, int *parseIdBox, const char *opt_grp, const char *cdo, int msgSw ) ;
    int  optGetBool( int optionsPaseId, const char *optionName, int *optionValueBox );
    int  optGetInt( int optionsPaseId, const char *optionName, int *optionValueBox );
    int  optGetDouble( int optionsPaseId, const char *optionName, double *optionValueBox );
    int  optIsMember( int optionsPaseId, const char *optionName, char *checkMember, const char *punctuation );

private:
    int  fixOptParse( int *fixParseId, const char *grpName, int argc, char **argv );
    int  fixOptPrUsage( FILE *usage_stream, int fixParseId, char *progname ) ;
    int  fixGetOptFile( int fixParseId, char **filenamebox ) ;
    int  fixGetConfFile( int fixParseId, char **filenamebox ) ;
    int  optPrOptsList( FILE *opStream, int optParseId, const char *grpName, char *progName ) ;
    int  optPrWarnUseDef( FILE *opStream, int optParseId, const char *grpName, const char *progName ) ;
    char *timeStamp( void ) ;

    int  local_strcmp( const char *str_left, const char *str_right );
    char *local_strtok( char * org_str, const char * delim, char ** next_point );
    int  strFindCombine( char *string, const char *combine_string, const char *tokensep );
    int  MemberChkMember( char *comb1, const char *punctleft, char *comb2, const char *punctright );
};
#endif
