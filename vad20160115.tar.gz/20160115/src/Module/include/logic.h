﻿/*-----------------------------------------------------------------------------
 VAD logic classes
-------------------------------------------------------------------------------
 Copyright (C) 2012 - 2016
   National Institute of Information and Communications Technology.
   All rights reserved.
-----------------------------------------------------------------------------*/

#ifndef LOGIC_H

#define LOGIC_H

#include <string>
#include <vector>

using namespace std;

// 連続判定クラス

class CONT{
private:
  int           Len;
  vector <bool> CalBuffer;
  vector <bool> OutBuffer;

public:
  // コンストラクタ関数
  CONT(int len);

  // 初期化関数
  void reset(void);

  // 入力関数
  void input(bool flag);
  void input(const vector <bool> & flagseq);

  // 出力関数
  vector <bool> output(void);

  // 出力フレーム数の取得関数
  int size(void) const;

  // 終了関数
  vector <bool> flush(void);

};

// ギャップ補完クラス

class GAP{
private:
  //int           GapLen;     // ギャップ長
  //int           Count;      // カウンタ
  vector <bool> OutBuffer;  // 出力用バッファ

public:
	int           GapLen;     // ギャップ長
	int           Count;      // カウンタ
  // コンストラクタ関数
  GAP(int gaplen);

  // 初期化関数
  void reset(void);

  // 入力関数
  void input(bool flag);
  void input(const vector <bool> & flagseq);

  // 出力関数
  vector <bool> output(void);

  // 出力フレーム数の取得関数
  int size(void) const;

  // 終了処理
  //vector <bool> flush(void);
  vector <bool> flush2(void);

};

// 発話長クラス

class DUR{
private:
  int           Duration;   // 最小継続時間
//  int           Count;      // カウンタ
  vector <bool> OutBuffer;  // 出力用バッファ

public:
  int           Count;      // カウンタ
  // コンストラクタ関数
  DUR(int duration);

  // 初期化関数
  void reset(void);

  // 入力関数
  void input(bool flag);
  void input(const vector <bool> & flagseq);

  // 出力関数
  vector <bool> output(void);

  // 出力フレーム数の取得関数
  int size(void) const;

  // 終了関数
  vector <bool> flush(void);

};

// 開始繰り上げクラス

class START{
private:
  int           StartLen;   // 拡張幅
//  vector <bool> CalBuffer;  // 計算用バッファ
  vector <bool> OutBuffer;  // 出力用バッファ

public:

  vector <bool> CalBuffer;  // 計算用バッファ
  // コンストラクタ関数
  START(int startlen);

  // 初期化関数
  void reset(void);

  // 入力関数
  void input(bool flag);
  void input(const vector <bool> & flagseq);

  // 出力関数
  vector <bool> output(void);

  // 出力フレーム数の取得関数
  int size(void) const;

  // 終了関数
  vector <bool> flush(void);

};

// 終了引き延しクラス

class END{
private:
  int           EndLen;     // 拡張幅
 // int           Count;      // カウンタ
  vector <bool> OutBuffer;  // 出力用バッファ

public:
  int           Count;      // カウンタ
  // コンストラクタ関数
  END(int endlen);

  // 初期化関数
  void reset(void);

  // 入力関数
  void input(bool flag);
  void input(const vector <bool> & flagseq);

  // 出力関数
  vector <bool> output(void);

  // 出力フレーム数の取得関数
  int size(void) const;

  // 終了関数
  vector <bool> flush(void);

};

#endif
