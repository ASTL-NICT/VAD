﻿/*-----------------------------------------------------------------------------
 addlog function
-------------------------------------------------------------------------------
 Copyright (C) 2012 - 2016
   National Institute of Information and Communications Technology.
   All rights reserved.
-----------------------------------------------------------------------------*/

#ifndef ADDLOG_H

#define ADDLOG_H

const double LOG_ZERO=-1.0e+6;     // 対数零

// 対数和の計算関数
double addlog(double x,double y);

#endif
