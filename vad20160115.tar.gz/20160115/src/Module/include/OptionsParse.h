﻿/*------------------------------------------------------------------------------
//
//------------------------------------------------------------------------------
// Copyright (C) 2011 - 2016
//   National Institute of Information and Communications Technology.
//   All rights reserved.
//----------------------------------------------------------------------------*/

#ifndef _OPTIONSPARSE_H_
#define _OPTIONSPARSE_H_

#include <stdio.h>
#include <ctype.h>
#include <time.h>
#include <string>
#include "OptionsDbase.h"

#define MAXLINE                 10000

/*  optionSetDB() で、ニューオプション作成フラグ  */
#define OPTIONnotCREATE          0
#define OPTIONnewCREATE          1
#define OPTIONdefCREATE          2

/*  streamParse() での文字列読み込み状態を表す関数返り値  */
#define EndReadString            0
#define CReturnReadString        1
#define CommentReadString        2
#define NormalReadString         3

/*  my_getc() my_ungetc()、字句解析対象タイプフラグ  */
#define STRINGsTREAM             0
#define FILEsTREAM               1

#define ERROR_FORMAT_FILE "%s  Invalid %s name: %s (%s:%ld)\n"
#define ERROR_FORMAT_ARG "%s  Invalid %s name: %s (argument)\n"
#define ERROR_NO_OPTION "no option name."
#define ERROR_TARGET_OPTION "option"
#define ERROR_TARGET_PROGRAM "program"
#define LONG_MAX_WIDTH 12


typedef struct mystream {
  char          * orig ;
  char          * base ;
  char          * end ;
  char          * now ;
  int           eoffg ;
} MyStream ;

class OptionsParse {
private:

    OptionsDbase    Dbase ;
	char			optstring[MAXLINE] ;
	MyStream		streamBuff ;

	int				prev_char ;
	char			env_str[ MAXLINE ];
	char			*env_p ;
	int				from ;
	int				end_of_line ;


public:
    OptionsParse() ;
    virtual ~OptionsParse() ;

    int  CheckReadAlready( int optionsPaseId, const char *optionName );
    int  GetOptValue( int optionsPaseId, const char *optionName, char **optionValueBox );
    int  GetOptDefValue( int optionsPaseId, const char *optionName, char **optionDefValueBox );
    int  OptsNameList( int optParseId, char ***nameList );
    int  SetDefOpts( int *optParseId, const char *optGrpName, char *defOptString );
    int  Parse( FILE *optionsfile, int *optparseId, const char *optgroup, int argc, char **argv );
    int  checkAllOptionNames( char* psConfigFileName, int argc, char **argv );
private:
    int  fileParse( FILE *optionsfile, int optparseId );
    int  argParse( int pargc, char **pargv, int optparseId );
    int  optionSetDB( int optparseId, char *rdstring, int createflag );
    int  readOption( int optParseId, void *parseStream, int typeStream, int optCreateFlag );
    int  streamParse( int strtype, void * dstream, int boxsize, char * valuebox );
    void reset_MyStream( void );
    int  my_getc( void * stream, int type ) ;
    int  my_ungetc( int chrct, void * stream, int type );
    int  v_getc( FILE * fp );
    int  v_ungetc( int c, FILE * fp );
    int  checkProgramName( char* psProgramName );
    int  checkOptionName( char* psOptionName );
    int  createFileErrorString( char** psError, char* psName, char* psFileName, long liLine, const char* psTarget);
    int  createArgumentErrorString( char** psError, char* psName, const char* psTarget ) ;
    int  streamParseForCheck( void * dstream, int boxsize, char * valuebox, long * pliLineCount );
    int  checkConfigFile( char* psConfigFileName, char** psProgramNameError, char** psOptionNameError );
    int  checkArgument( int argc, char **argv, char** psProgramNameError, char** psOptionNameError );
};
#endif
