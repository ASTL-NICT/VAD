﻿/*-----------------------------------------------------------------------------
 KIND + KIND_CONV class
-------------------------------------------------------------------------------
 Copyright (C) 2012 - 2016
   National Institute of Information and Communications Technology.
   All rights reserved.
-----------------------------------------------------------------------------*/

#ifndef KIND_HH

#define KIND_HH

#include<string>
#include<vector>

using namespace std;

// 特徴量構成クラス

class KIND : private vector <string>{
private:
  int             CepLen;   // ケプストラム次元数
  int             VecLen;   // 特徴量次元数

public:
  // コンストラクタ関数
  KIND(int ceplen);
  KIND(int ceplen,const string & comp);
  KIND(int ceplen,const vector <string> & comps);

  // ケプストラム次元数の取得関数
  int get_ceplen(void) const;

  // 特徴量次元数の取得関数
  int get_veclen(void) const;

  // 特徴量構成の取得関数
  const string & operator [] (int n) const;

  // 特徴量の有無判定関数
  bool has(const string & comp);
  bool has(const KIND & kind);

  // 初期化関数
  void clear(void);

  // 特徴量数の取得関数
  int size(void) const;

  // 特徴量の追加関数
  bool add(const string & comp);
  bool add(const vector <string> & comps);
};

// 特徴量構成変換クラス

class KIND_CONV{
private:
  KIND         * IKind;  // 入力特徴量の構成
  KIND         * OKind;  // 出力特徴量の構成
  vector <int>   IOMap;  // 入出力特徴量の間の変換情報

public:
  // コンストラクタとディストラクタ関数
   KIND_CONV(const KIND & ikind,const KIND & okind);
  ~KIND_CONV(void);

  // 特徴量構成の変換関数
  vector <double> conv(const vector <double> & parvec) const;
};

#endif
