/*------------------------------------------------------------------------------
// SSSQueue define
//------------------------------------------------------------------------------
// Copyright (C) 2011 - 2016
//   National Institute of Information and Communications Technology.
//   All rights reserved.
//----------------------------------------------------------------------------*/

#ifndef _SSSQUEUEDEFINE_H_
#define _SSSQUEUEDEFINE_H_

/* queue processing for rpc events */
typedef struct SSSQueue {
    char *string ;
    struct SSSQueue *next ;
} SSSQUEUE;

typedef struct SSSQueueP {
    SSSQUEUE *top ;
    SSSQUEUE **topp ;
} SSSQUEUEP;

void SSSInitQueue ( SSSQUEUEP * ) ;
char *SSSPopQueue ( SSSQUEUEP * ) ;
void SSSPushQueue ( SSSQUEUEP *, char * ) ;

#endif
