/*------------------------------------------------------------------------------
// FIFO buffer class
//------------------------------------------------------------------------------
// Copyright (C) 2011 - 2016
//   National Institute of Information and Communications Technology.
//   All rights reserved.
//----------------------------------------------------------------------------*/

#ifndef _FIFOBUFFER_H_
#define _FIFOBUFFER_H_

#include <stdio.h>
extern "C" {
#include "NICTutil.h"
}

class FifoBuffer {
private:
	vos	*pBuffer ;
public:
    FifoBuffer() ;
    virtual ~FifoBuffer() ;

    int Initialize( int initialAllocation ) ;
    int Clear() ;
    int Append( double *buffer, int howMany ) ;
    int Take( double *destination, int howMany) ;
    int HowMany() ;
};

#endif

