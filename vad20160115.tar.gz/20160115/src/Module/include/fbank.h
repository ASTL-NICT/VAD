﻿/*-----------------------------------------------------------------------------
 FBANK class
-------------------------------------------------------------------------------
 Copyright (C) 2012 - 2016
   National Institute of Information and Communications Technology.
   All rights reserved.
-----------------------------------------------------------------------------*/

#ifndef FBANK_HH

#define FBANK_HH

#include<vector>

using namespace std;

// フィルタバンク分析クラス

class FBANK{
private:

  int                            VecLen;      // ベクトル長
  int                            WinLen;      // 分析窓長
  int                            ShiftLen;    // フレームシフト幅
  int                            FFTLen;      // FFT 長

  int                            SmpFreq;     // サンプリング周波数
  double                         LowCutoff;   // ローカットオフ周波数
  double                         HighCutoff;  // ハイカットオフ周波数
  double                         PreEmp;      // プリエンファシス係数

  double                       * HamWin;      // ハミング窓係数
  int                            KLo;         // フィルタバンク係数計算用定数
  int                            KHi;         // ...
  int                          * LoChan;      // ...
  double                       * LoWt;        // ...

  short int                    * WaveBuf;     // 分析用音声波形バッファ
  int                            WaveLen;     // バッファサイズ
  int                            WaveNum;     // データ数
  int                            ZeroLen;     // 零埋め長

  int                            LeftNum;     // 残りフレーム数
  vector <vector <double> >      FBank;       // フィルタバンク係数

public:
  // コンストラクタとディストラクタ関数
   FBANK(int veclen,int zerolen,int winlen,int shiftlen,int smpfreq,
	 double lowcutoff,double highcutoff,double preemp);
  ~FBANK(void);

  // 音響分析条件取得関数
  int    get_veclen    (void) const;
  int    get_winlen    (void) const;
  int    get_shiftlen  (void) const;
  int    get_smpfreq   (void) const;
  double get_lowcutoff (void) const;
  double get_highcutoff(void) const;
  double get_preemp    (void) const;

  // 初期化関数
  void clear(void);

  // 音声波形の入力関数
  void in(const short int          * wave);
  void in(const vector <short int> & wave);

  // 音声波形の入力終了関数
  void flush(void);

  // フィルタバンク係数の取得関数 (FBank[VecLen]は対数パワー)
  int outnum(void) const;
  vector <double> out(void);
  const vector <vector <double> > & get_fbank(void) const;

};

#endif
