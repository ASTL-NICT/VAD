﻿/*------------------------------------------------------------------------------
// MMSE 法による雑音抑圧プログラム NICTMMSE_main
//    for NICTASR_lib     #S-532
//------------------------------------------------------------------------------
// Copyright (C) 2012 - 2016
//   National Institute of Information and Communications Technology.
//   All rights reserved.
//----------------------------------------------------------------------------*/


#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>

#include "NICTmmse.h"

using namespace std;


NICTmmse::NICTmmse()
{
  pEvent       = NULL ;
  pOption      = NULL ;
  sMMSE        = NULL ;
  pcmmseOptions  = NULL ;
  options_id   = 0 ;

  EventTbl.clear() ;
}

NICTmmse::NICTmmse(NICTevent2 *event, NICToptions *option)
{
  pEvent       = event ;
  pOption      = option ;
  sMMSE        = NULL ;
  pcmmseOptions  = NULL ;
  options_id   = 0 ;

  EventTbl.clear() ;
}

NICTmmse::~NICTmmse()
{
  // LocalEvent領域を解放する
  if( !EventTbl.empty() ) {
    intShortStar *ptr ;
    int size = EventTbl.size() ;
    for( int i = 0 ; i < size ; i++ ) {
      ptr = EventTbl[i] ;
      if( ptr->ss ) free( ptr->ss ) ;
      free( ptr ) ;
    }
  }
}

int NICTmmse::Initialize( int argn, char *argv[] )
{
  int     iRetVal;
  char*   optionvaluebox = NULL;

  /* ---------- options envelop start ---------- */

  const char default_options[] = "\
    FilterBankOrder=24\n\
    FrameLength=20.0\n\
    FrameShift=10.0\n\
    SamplingFrequency=16000\n\
    CutoffHighFrequency=8000.0\n\
    CutoffLowFrequency=0.0\n\
    Preemphasis=0.98\n\
    CleanSpeechGMM=\n\
    InitialNoiseLength=100.0\n\
    ";


  /*  Get Options  */
  iRetVal = pOption->ReadMain( argn, argv, &options_id, NICT_MMSE_STR,
			       default_options, OPT_PrintOptList |OPT_PrintSetOptList );

  if( iRetVal == OPT_FAILURE ) {
    fprintf( stderr, "@NICTmmse ERROR: Invalid argument.\n" );
    return( 1 );
  }

  /****  parse options  ****/

  cmmseOptions.FilterBankOrder = 24;
  cmmseOptions.FrameLength = 20.0;
  cmmseOptions.FrameShift = 10.0;
  cmmseOptions.SamplingFrequency = 16000;
  cmmseOptions.highcutoff = 8000.0;
  cmmseOptions.lowcutoff = 0.0;
  cmmseOptions.Preemphasis = 0.98;
  cmmseOptions.CleanSpeechGMM = "";
  cmmseOptions.InitialNoiseLength = 100.0;

  pcmmseOptions = &cmmseOptions;


  /* FilterBankOrder */

  	
  iRetVal = pOption->GetOptValue( options_id, "FilterBankOrder", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTmmse_init: OPTIONLIB error in FilterBankOrder\n" );
    return( 1 );
  }

  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTmmse_init ERROR : OPTION FilterBankOrder is not setting.\n" ) ;
    return( 1 );
  }

  pcmmseOptions->FilterBankOrder = atoi(optionvaluebox);
       	
  if( pcmmseOptions->FilterBankOrder <= 0 ) {
    fprintf( stderr,  "@NICTmmse_init ERROR : OPTION FilterBankOrder is out of range.\n" ) ;
    return( 1 );
  }

  free( optionvaluebox );


  /* FrameLength */
  iRetVal = pOption->GetOptValue( options_id, "FrameLength", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTmmse_init: OPTIONLIB error in FrameLength\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTmmse_init ERROR : OPTION FrameLength is not setting.\n" ) ;
    return( 1 );
  }
  pcmmseOptions->FrameLength = atof(optionvaluebox);

  if( pcmmseOptions->FrameLength <= 0.0 ) {
    fprintf( stderr,  "@NICTmmse_init ERROR : OPTION FrameLength is out of range.\n" ) ;
    return( 1 );
  }

  free( optionvaluebox );


  /* FrameShift */
  iRetVal = pOption->GetOptValue( options_id, "FrameShift", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTmmse_init: OPTIONLIB error in FrameShift\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTmmse_init ERROR : OPTION FrameShift is not setting.\n" ) ;
    return( 1 );
  }
  pcmmseOptions->FrameShift = atof(optionvaluebox);

  if( pcmmseOptions->FrameShift <= 0.0 ) {
    fprintf( stderr,  "@NICTmmse_init ERROR : OPTION FrameShift is out of range.\n" ) ;
    return( 1 );
  }

  free( optionvaluebox );


  /* SamplingFrequency */
  iRetVal = pOption->GetOptValue( options_id, "SamplingFrequency", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTmmse_init: OPTIONLIB error in SamplingFrequencyt\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTmmse_init ERROR : OPTION SamplingFrequency is not setting.\n" ) ;
    return( 1 );
  }
  pcmmseOptions->SamplingFrequency = atoi(optionvaluebox);

  if( pcmmseOptions->SamplingFrequency <= 0 ) {
    fprintf( stderr,  "@NICTmmse_init ERROR : OPTION SamplingFrequency is out of range.\n" ) ;
    return( 1 );
  }
  free( optionvaluebox );


  /* CutoffHighFrequency */
  iRetVal = pOption->GetOptValue( options_id, "CutoffHighFrequency", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTmmse_init: OPTIONLIB error in CutoffHighFrequency\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTmmse_init ERROR : OPTION CutoffHighFrequency is not setting.\n" ) ;
    return( 1 );
  }
  pcmmseOptions->highcutoff = atof(optionvaluebox);

  if( pcmmseOptions->highcutoff < 0.0 ) {
    fprintf( stderr,  "@NICTmmse_init ERROR : OPTION CutoffHighFrequency is out of range.\n" ) ;
    return( 1 );
  }

  free( optionvaluebox );


  /* CutoffLowFrequency */
  iRetVal = pOption->GetOptValue( options_id, "CutoffLowFrequency", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTmmse_init: OPTIONLIB error in CutoffLowFrequency\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTmmse_init ERROR : OPTION CutoffLowFrequency is not setting.\n" ) ;
    return( 1 );
  }
  pcmmseOptions->lowcutoff = atof(optionvaluebox);

  if( pcmmseOptions->lowcutoff < 0.0 ) {
    fprintf( stderr,  "@NICTmmse_init ERROR : OPTION CutoffLowFrequency is out or range.\n" ) ;
    return( 1 );
  }
  free( optionvaluebox );


  /* Preemphasis */
  iRetVal = pOption->GetOptValue( options_id, "Preemphasis", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTmmse_init: OPTIONLIB error in Preemphasis\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTmmse_init ERROR : OPTION Preemphasis is not setting.\n" ) ;
    return( 1 );
  }
  pcmmseOptions->Preemphasis = atof(optionvaluebox);
  free( optionvaluebox );

  /* CleanSpeechGMM */
  iRetVal = pOption->GetOptValue( options_id, "CleanSpeechGMM", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTmmse_init: OPTIONLIB error in CleanSpeechGMM\n" );
    return( 1 );
  }

  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTmmse_init ERROR : OPTION CleanSpeechGMM is not setting.\n" ) ;
    return( 1 );
  }

  FILE* pfCleanSpeechGMM = fopen ( optionvaluebox, "r") ;
  if ( pfCleanSpeechGMM == NULL ) {
    fprintf( stderr, "@NICTmmse ERROR :OPTION CleanSpeechGMM can not open %s\n", optionvaluebox);
    return 1 ;
  }
  fclose( pfCleanSpeechGMM );



  pcmmseOptions->CleanSpeechGMM = (string)optionvaluebox;


  free( optionvaluebox );
        	
  /* InitialNoiseLength */
  iRetVal = pOption->GetOptValue( options_id, "InitialNoiseLength", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTmmse_init: OPTIONLIB error in InitialNoiseLength\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTmmse_init ERROR : OPTION InitialNoiseLength is not setting.\n" ) ;
    return( 1 );
  }
  pcmmseOptions->InitialNoiseLength = atoi(optionvaluebox);

  if( pcmmseOptions->InitialNoiseLength <= 0.0 ) {
    fprintf( stderr,  "@NICTmmse_init ERROR : OPTION InitialNoiseLength is out of range.\n" ) ;
    return( 1 );
  }

  free( optionvaluebox );


  // MMSE の準備

  winlen  =(int)((double)pcmmseOptions->SamplingFrequency*0.001*pcmmseOptions->FrameLength+0.5);
  shiftlen=(int)((double)pcmmseOptions->SamplingFrequency*0.001*pcmmseOptions->FrameShift+0.5);
  initnum =(int)((double)pcmmseOptions->SamplingFrequency*0.001*pcmmseOptions->InitialNoiseLength+0.5)/shiftlen;

  sMMSE = new MMSE(pcmmseOptions->FilterBankOrder,winlen,shiftlen,pcmmseOptions->SamplingFrequency,pcmmseOptions->lowcutoff,
		   pcmmseOptions->highcutoff,pcmmseOptions->Preemphasis,initnum,pcmmseOptions->CleanSpeechGMM);

  // intShortStarを10個作成して置く
  EventUseIndex = 0 ;
  for( int i = 0 ; i < 10 ; i++ ) {
    if( GetLocalEvent() == NULL ) return 1 ;
  }

  return 0;
}


void NICTmmse::Terminate( int arg )
{
  if ( sMMSE ) delete (MMSE*)sMMSE ;
}


void NICTmmse::Execute( int eventType, EventNICT *event )
{
  vector <short int> ret;

  intShortStar *piss = (intShortStar*)event->message_body;
  EventUseIndex = 0 ;
  switch( event->message_type ) {
  case INITIALIZE:
    break;

  case EV_KILL:
    pEvent->PutEvent( NICT_PROCESS, NORMAL_EXIT, NULL );
    break;

  case EV_ABEND:
    pEvent->PutEvent( NICT_PROCESS, ERROR_EXIT, NULL );
    break;
     	
  case EPV_DATA:
    ((MMSE*)sMMSE)->in(piss->ss);
    while(((MMSE*)sMMSE)->outnum() > 0){
      ret = ((MMSE*)sMMSE)->out();
      intShortStar *ptr = GetLocalEvent() ;
      for(int t=0 ; t < shiftlen ; t++ ) ptr->ss[t] = ret[t] ;
      pEvent->PutEvent( NICTD_MARKED_WAVE, EPV_DATA, (EventNICT*)ptr );
    }
    break;
	
  case EV_TOF:
    ((MMSE*)sMMSE)->clear();
    pEvent->PutEvent( NICTD_MARKED_WAVE, EV_TOF, NULL );	
    break;
	
  case EV_EOF:    	
    pEvent->PutEvent( NICTD_MARKED_WAVE, EV_EOF, NULL );	
    break;        			
  	
  case EPV_STARTPU:
    pEvent->PutEvent( NICTD_MARKED_WAVE, EPV_STARTPU, NULL );	
    break;
	
  case EPV_ENDPU:
    ((MMSE*)sMMSE)->flush();
    while(((MMSE*)sMMSE)->outnum() > 0){
      ret = ((MMSE*)sMMSE)->out();
      intShortStar *ptr = GetLocalEvent() ;
      for(int t=0 ; t < shiftlen ; t++ ) ptr->ss[t] = ret[t] ; 	
      pEvent->PutEvent( NICTD_MARKED_WAVE, EPV_DATA, (EventNICT*)ptr );

    }
    pEvent->PutEvent( NICTD_MARKED_WAVE, EPV_ENDPU, NULL );	
    break;

  case EV_ABORT:    /* cancel of speech */
    pEvent->PutEvent( NICTD_MARKED_WAVE, EV_ABORT, NULL );
    break;
	
  default:
    break;
  }
  return;
}	

// データタイプ・個数取得処理
void NICTmmse::GetDataParam( int *in_size1, int *in_size2, int *out_size1, int *out_size2)
{

  *in_size1 = DEF_SHORT;
  *in_size2 = shiftlen ;

  *out_size1 = DEF_SHORT;
  *out_size2 = shiftlen;

  return;
}

// intShortStar型の領域を確保して、そのポインタを返す。
// 既存領域がある場合は生成しない。
intShortStar* NICTmmse::GetLocalEvent()
{
  intShortStar* ptr ;

  if( EventUseIndex < (int)EventTbl.size() ) {
    ptr = EventTbl[EventUseIndex] ;
  }
  else {
    ptr = (intShortStar*)malloc(sizeof(intShortStar)) ;
    if( ptr == NULL ) {
      fprintf( stderr, "NICTmmse_execute: Cannot alloc memory for local_data\n" );
      return NULL ;
    }
    ptr->i  = shiftlen ;
    ptr->ss = (short int*)malloc( sizeof(short int) * shiftlen ) ;
    if( ptr->ss == NULL ) {
      fprintf( stderr, "NICTmmse_execute: Cannot alloc memory for local_data.ss\n" );
      free( ptr ) ;
      return NULL ;
    }
    EventTbl.push_back( ptr ) ;
  }
  EventUseIndex++ ;

  return ptr ;
}
