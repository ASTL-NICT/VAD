﻿/*-----------------------------------------------------------------------------
 NICTmmse class
-------------------------------------------------------------------------------
 Copyright (C) 2012 - 2016
   National Institute of Information and Communications Technology.
   All rights reserved.
-----------------------------------------------------------------------------*/

#include <cmath>
#include <iostream>
#include <limits.h>

#include "addlog.h"
#include "NICTmmse.h"

const double TPI=6.28318530717959;

// 線形とメル間の変換関数

static float linear2mel(float linfreq){
  return((float)(2595.0*log10(1.0+linfreq/700.0)));
}

static float mel2linear(float melfreq){
  return((float)(700.0*(pow(10.0,melfreq/2595.0)-1.0)));
}

// MMSE クラスのメンバ関数定義

// インパルス応答の計算関数

void MMSE::calc_impulse(const vector <double> & parvec){

  // 事後確率の計算



  //double prob[MixNum],allprob=LOG_ZERO;
  double *prob;
  prob = new double[MixNum];

  double allprob=LOG_ZERO;



  for(int m=0;m<MixNum;m++){
    prob[m]=NoisyGMM->calc_prob(m,parvec);
    allprob=addlog(allprob,prob[m]);
  }
  for(int m=0;m<MixNum;m++)prob[m]=exp(prob[m]-allprob);

  // ミスマッチ係数の計算


  double *misfact;
  misfact = new double[VecLen];
  //double misfact[VecLen];



  for(int d=0;d<VecLen;d++)misfact[d]=0.0;
  for(int m=0;m<MixNum;m++){
    const double * clean_mean=CleanGMM->get_mean(m);
    const double * noisy_mean=NoisyGMM->get_mean(m);
    for(int d=0;d<VecLen;d++)
      misfact[d]+=prob[m]*(noisy_mean[d]-clean_mean[d]);
  }

  // ウィーナフィルタの計算


  double *wfilter;
  wfilter = new double[1 + VecLen + 1];
  //double wfilter[1+VecLen+1];



  for(int d=0;d<VecLen;d++)wfilter[d+1]=exp(-misfact[d]);
  wfilter[0]=wfilter[1];
  wfilter[VecLen+1]=wfilter[VecLen];

  // インパルス応答の計算

  double * impulse=new double [FilLen];
  for(int t=FilLenHalf-1;t<FilLen;t++)impulse[t]=0.0;
  for(int t=0;t<=FilLenHalf;t++)for(int u=0;u<=FilLenHalf;u++)
    impulse[FilLenHalf+t]+=wfilter[u]*IDCT[t][u];
  for(int t=1;t<=FilLenHalf;t++)
    impulse[FilLenHalf-t]=impulse[FilLenHalf+t];
  for(int t=0;t<FilLen;t++)impulse[t]*=HanWin[t];
  Impulse.push_back(impulse);


  delete [] prob;
  delete [] misfact;
  delete [] wfilter;


  return;
}

// ウィーナフィルタの適用関数

void MMSE::apply_wiener(const short int * framewave){

  // 畳み込み用音声波形バッファの設定

  if(ConvNum==ConvLen){
    for(int t=ShiftLen;t<ConvLen;t++)ConvBuf[t-ShiftLen]=ConvBuf[t];
    ConvNum-=ShiftLen;
  }
  for(int t=0;t<ShiftLen;t++)ConvBuf[t+ConvNum]=framewave[t];
  ConvNum+=ShiftLen;

  // ウィーナフィルタの適用

  if(ConvNum==ConvLen){
    const double * impulse=Impulse[0];
    Impulse.erase(Impulse.begin());
    vector <short int> enh;
    for(int t=0;t<ShiftLen;t++){
      double val=0.0;
      for(int u=0;u<FilLen;u++){
	val+=ConvBuf[t+u]*impulse[FilLen-1-u];
      }
      if(0.0<=val)val+=0.5;
      else val-=0.5;
      if(val>=(double)SHRT_MAX){
	enh.push_back(SHRT_MAX);
      }else if(val<=(double)SHRT_MIN){
	enh.push_back(SHRT_MIN);
      }else{
	enh.push_back((int)val);
      }
    }
    delete [] impulse;
    EnhWave.push_back(enh);
  }

  return;
}

// コンストラクタとディストラクタ関数

MMSE::MMSE(int veclen,int winlen,int shiftlen,int smpfreq,double lowcutoff,
	   double highcutoff,double preemp,int initnum,
	   const string & gmmfilename){

  // クリーン音声 GMM の読み込み

  CleanGMM=new GMM(gmmfilename);

  // フィルタバンク分析の設定

  FBank=new FBANK(veclen,(winlen-shiftlen)/2,winlen,shiftlen,smpfreq,
			  lowcutoff,highcutoff,preemp);
  if(FBank->get_veclen()!=veclen)
    throw (char *)"ERR: フィルタバンク数と GMM の次元数が一致しません.";

  // 音響分析条件の設定
  VecLen    =veclen;
  MixNum    =CleanGMM->get_mixnum();
  WinLen    =winlen;
  ShiftLen  =shiftlen;

  NoisyGMM  =NULL;
  InitNum   =initnum;

  FilLen    =(VecLen+1)*2+1;
  FilLenHalf=VecLen+1;

  // フィルタバンク係数の中心周波数の設定

  double mellow = linear2mel( (float)lowcutoff);
  double melhigh=linear2mel((float)highcutoff);
  double meldiff=melhigh-mellow;
  CenFreq=new double [FilLenHalf+1];
  CenFreq[0]=0.0;
  for(int t=1;t<FilLenHalf;t++)
    CenFreq[t]=mel2linear((float)(((double)t/(double)FilLenHalf)*meldiff+mellow));
  CenFreq[FilLenHalf]=(double)(smpfreq/2);


  // メル変換された IDCT の重み係数の設定

  DelFreq=new double [FilLenHalf+1];
  DelFreq[0]=(CenFreq[1]-CenFreq[0])/(double)smpfreq;
  for(int t=1;t<FilLenHalf;t++)DelFreq[t]=(CenFreq[t+1]-CenFreq[t-1])/smpfreq;
  DelFreq[FilLenHalf]=
    (CenFreq[FilLenHalf]-CenFreq[FilLenHalf-1])/(double)smpfreq;

  // 逆 DCT 行列の設定

  IDCT=new double * [FilLenHalf+1];
  for(int t=0;t<=FilLenHalf;t++)IDCT[t]=new double [FilLenHalf+1];
  for(int t=0;t<=FilLenHalf;t++)for(int u=0;u<=FilLenHalf;u++)
    IDCT[t][u]=DelFreq[u]*cos(TPI*(double)t*CenFreq[u]/(double)smpfreq);

  // ハニング窓係数の設定

  HanWin=new double [FilLen];
  for(int t=0;t<FilLen;t++)
    HanWin[t]=0.5-0.5*cos((TPI*((double)t+0.5))/(double)FilLen);

  // 畳み込み用音声波形バッファの領域の設定

  ConvLen=FilLenHalf+ShiftLen;
  if(FilLenHalf<ShiftLen)ConvLen+=ShiftLen;
  else{
    if(FilLenHalf%ShiftLen==0){
      ConvLen+=(FilLenHalf/ShiftLen)*ShiftLen;
    }else{
      ConvLen+=(FilLenHalf/ShiftLen+1)*ShiftLen;
    }
  }

  ConvBuf=new short int [ConvLen];
  for(int t=0;t<ConvLen;t++)ConvBuf[t]=0;
  ConvNum=FilLenHalf;

}

MMSE::~MMSE(void){
  delete CleanGMM;
  if(NoisyGMM!=NULL)delete NoisyGMM;
  delete FBank;
  for(int n=0;n<(int)FrameWave.size();n++)delete [] FrameWave[n];
  delete [] CenFreq;
  delete [] DelFreq;
  for(int t=0;t<FilLenHalf+1;t++)delete [] IDCT[t];
  delete [] IDCT;
  delete [] HanWin;
  delete [] ConvBuf;
  for(int t=0;t<(int)Impulse.size();t++)delete [] Impulse[t];
}

// 雑音抑圧条件の取得関数

int MMSE::get_veclen(void) const{
  return(VecLen);
}

int MMSE::get_mixnum(void) const{
  return(MixNum);
}

int MMSE::get_winlen(void) const{
  return(WinLen);
}

int MMSE::get_shiftlen(void) const{
  return(ShiftLen);
}

int MMSE::get_smpfreq(void) const{
  return(FBank->get_smpfreq());
}

double MMSE::get_lowcutoff(void) const{
  return(FBank->get_lowcutoff());
}

double MMSE::get_highcutoff(void) const{
  return(FBank->get_highcutoff());
}

double MMSE::get_preemp(void) const{
  return(FBank->get_preemp());
}

int MMSE::get_initnum(void) const{
  return(InitNum);
}

// 初期化関数

void MMSE::clear(void){
  if(NoisyGMM!=NULL)delete NoisyGMM;
  NoisyGMM=NULL;
  FBank->clear();
  for(int n=0;n<(int)FrameWave.size();n++)delete [] FrameWave[n];
  FrameWave.clear();
  for(int t=0;t<ConvLen;t++)ConvBuf[t]=0;
  ConvNum=FilLenHalf;
  for(int t=0;t<(int)Impulse.size();t++)delete [] Impulse[t];
  Impulse.clear();
  EnhWave.clear();
  return;
}

// 雑音の設定関数

void MMSE::set_noise(const vector <double> & noise){
  if(NoisyGMM!=NULL)delete NoisyGMM;
  NoisyGMM=new GMM(VecLen,MixNum);
  for(int m=0;m<MixNum;m++){
    double         clean_bweight =CleanGMM->get_bweight (m);
    const double * clean_mean    =CleanGMM->get_mean    (m);
    const double * clean_variance=CleanGMM->get_variance(m);

	

	double *noisy_mean;
	noisy_mean = new double[VecLen];
	//double noisy_mean[VecLen];

	

    for(int d=0;d<VecLen;d++)noisy_mean[d]=addlog(clean_mean[d],noise[d]);
    NoisyGMM->set_bweight (m,clean_bweight );
    NoisyGMM->set_mean    (m,noisy_mean    );
    NoisyGMM->set_variance(m,clean_variance);

	delete [] noisy_mean;
  }
  return;
}

// 音声波形の入力関数

void MMSE::in(const short int * wave){

  // フィルタバンク係数の計算

  FBank->in(wave);
  short int * framewave=new short int [ShiftLen];
  for(int t=0;t<ShiftLen;t++)framewave[t]=wave[t];
  FrameWave.push_back(framewave);

  // 初期雑音の推定

  if(NoisyGMM==NULL){
	
    if(FBank->outnum()<InitNum)return;

    if(FBank->outnum()==InitNum){
      const vector <vector <double> > & param=FBank->get_fbank();
      vector <double> noise(VecLen,0.0);
      for(int n=0;n<(int)param.size();n++)
	for(int d=0;d<VecLen;d++)noise[d]+=param[n][d];
      for(int d=0;d<VecLen;d++)noise[d]/=(double)param.size();
      set_noise(noise);
    }
  }

  // 雑音の抑圧

  while(FBank->outnum()>0&&FrameWave.size()>0){

    // フィルタバンク係数と音声波形の取得

    vector <double>   parvec   =FBank->out();
    const short int * framewave=FrameWave[0];
    FrameWave.erase(FrameWave.begin());

    // インパルス応答の計算

    calc_impulse(parvec);

    // ウィーナフィルタの適用

    apply_wiener(framewave);
    delete [] framewave;

  }

  return;
}

void MMSE::in(const vector <short int> & wave){


  //short int tmp[ShiftLen];
  short int *tmp;
  tmp = new short int[ShiftLen];

  //short int tmp[ShiftLen];


  for(int t=0;t<ShiftLen;t++)tmp[t]=wave[t];
  in(tmp);

  delete [] tmp;

  return;
}

// 音声波形の入力終了関数

void MMSE::flush(void){

  // 零埋め処理

  for(int n=0;n<(ConvLen-FilLenHalf)/ShiftLen-1;n++){
    short int * framewave=new short int [ShiftLen];
    for(int t=0;t<ShiftLen;t++)framewave[t]=0;
    FBank->in(framewave);
    FrameWave.push_back(framewave);
  }
  FBank->flush();

  // 初期雑音の推定

  if(NoisyGMM==NULL){
	
	
    if(FBank->outnum()==0)return;
    vector <double> noise(VecLen,0.0);
    const vector <vector <double> > & param=FBank->get_fbank();
    for(int t=0;t<(int)param.size();t++)for(int d=0;d<VecLen;d++)
      noise[d]+=param[t][d];
    for(int d=0;d<VecLen;d++)noise[d]/=(double)param.size();
    set_noise(noise);
  }

  // 雑音の抑圧

  while(FBank->outnum()>0&&FrameWave.size()>0){

    // フィルタバンク係数と音声波形の取得

    vector <double>   parvec   =FBank->out();
    const short int * framewave=FrameWave[0];
    FrameWave.erase(FrameWave.begin());

    // インパルス応答の計算

    calc_impulse(parvec);

    // ウィーナフィルタの適用

    apply_wiener(framewave);
    delete [] framewave;

  }

  return;
}

// 雑音抑圧された音声波形の取得関数

int MMSE::outnum(void) const{
	
	return((int)EnhWave.size());
}

vector <short int> MMSE::out(void){
  vector <short int> ret=EnhWave[0];
  EnhWave.erase(EnhWave.begin());
  return(ret);
}
