/*------------------------------------------------------------------------------
// Utility function Library.
//------------------------------------------------------------------------------
// Copyright (C) 2009 - 2016
//   National Institute of Information and Communications Technology.
//   All rights reserved.
//----------------------------------------------------------------------------*/

#include "NICTutil.h"

#include <string.h>


int NICTstrcasecmp(
		const char	*a,
		const char	*b
	)
{
	char	x;
	char	y;

	while( 1 ) {
		x = *a;
		y = *b;
		if( x >= 'a' && x <= 'z' ) {
			x -= 'a' - 'A';
		}
		if( y >= 'a' && y <= 'z' ) {
			y -= 'a' - 'A';
		}
		if( x != y ) {
			return( -1 );
		}
		if( x == '\0' ) {
			return( 0 );
		}
		a ++;
		b ++;
	}
}

int NICTstrncasecmp(
		const char	*a,
		const char	*b,
		int	n
	)
{
	char	x;
	char	y;

	while( 1 ) {
		if( n == 0 ) {
			return( 0 );
		}
		x = *a;
		y = *b;
		if( x >= 'a' && x <= 'z' ) {
			x -= 'a' - 'A';
		}
		if( y >= 'a' && y <= 'z' ) {
			y -= 'a' - 'A';
		}
		if( x != y ) {
			return( -1 );
		}
		a ++;
		b ++;
		n --;
	}
}

/* EOF */
