/*------------------------------------------------------------------------------
// FIFO buffer class
//------------------------------------------------------------------------------
// Copyright (C) 2011 - 2016
//   National Institute of Information and Communications Technology.
//   All rights reserved.
//----------------------------------------------------------------------------*/

#include "FifoBuffer.h"

// �R���X�g���N�^
FifoBuffer::FifoBuffer()
{
	pBuffer = NULL ;
}

// �f�X�g���N�^
FifoBuffer::~FifoBuffer()
{
	if( pBuffer ) {
		if( pBuffer->buffer ) NICTutil_free( pBuffer->buffer ) ;
		NICTutil_free( pBuffer ) ;
	}
}

// ������
int FifoBuffer::Initialize( int initialAllocation )
{
    if( initialAllocation <= 0 ) {
		fprintf( stderr, "initialAllocation <= 0\n" ) ;
		return 1 ;
	}
    pBuffer = NICT_ALLOC (1, struct vos);
    if (pBuffer == NULL) {
        fprintf( stderr, "NICTutil_fifoInit\n" );
        return 1;
    }
    pBuffer->buffer = NICT_ALLOC (initialAllocation, double);
    if (pBuffer->buffer == NULL) {
        fprintf( stderr, "pBuffer->buffer alloc failed\n" );
        return 1;
    }
    pBuffer->allocated = initialAllocation;
    pBuffer->used = 0;

	return 0;
}

int FifoBuffer::Clear()
{
    if( pBuffer == NULL ) {
		fprintf( stderr, "FifoBuffer::Clear: pBuffer is NULL!\n" );
		return 1 ;
	}
    pBuffer->used = 0;

    return 0;
}

int FifoBuffer::Append( double *buffer, int howMany )
{
    if(pBuffer == NULL) {
		fprintf( stderr, "FifoBuffer::Append: pBuffer is NULL!\n" );
		return 1 ;
	}
    if(pBuffer->buffer == NULL) {
		fprintf( stderr, "FifoBuffer::Append: pBuffer->buffer == NULL\n" );
		return 1 ;
	}
    if (howMany == 0) {
        /* This may be common, so it's worth checking.
         * But it shouldn't be an error.
        */
        return 0;
    }
    if(pBuffer->used + howMany > pBuffer->allocated) {  /* Need to realloc? */
        /* Yes, we must realloc */
        pBuffer->buffer = (double*)NICT_REALLOC(pBuffer->buffer, (pBuffer->used + howMany) * sizeof(double));
        if(pBuffer->buffer == NULL) {
            fprintf( stderr, "FifoBuffer::Append: could not realloc pBuffer->buffer\n" );
            return 1;
        }
        pBuffer->allocated = pBuffer->used + howMany;
        memcpy (pBuffer->buffer + pBuffer->used, buffer, howMany * sizeof(double));
        pBuffer->used = pBuffer->used + howMany;
    } else {
        /* No, we need not realloc; just memcpy */
        memcpy (pBuffer->buffer + pBuffer->used, buffer, howMany * sizeof(double));
        pBuffer->used = pBuffer->used + howMany;
    }
    return 0;
}

/* This copies the requested contents from the HEAD OF v->buffer
   to the "buffer" argument.  It is the responsibility of the caller
   to ensure that buffer can receive howMany points.  Note that we
   have elected not to shrink the buffer size down.
   */
int FifoBuffer::Take( double *destination, int howMany)
{
    /* check args, do the copy, shift contents, reduce "used", and return. */
    if( howMany > pBuffer->used ) {
        fprintf( stderr, "pBuffer->used = %d  <  howMany = %d\n", pBuffer->used, howMany );
		return 1;
    }
    /* destination and v->buffer do not overlap so memcpy is OK */
    memcpy(destination, pBuffer->buffer, howMany * sizeof(double));

    pBuffer->used -= howMany;
    memmove( (void*) pBuffer->buffer, (const void*) (pBuffer->buffer + howMany), sizeof(double) * (pBuffer->used) );

    return 0;
}

/* Just tell me how many I can have: return the howMany element */
int FifoBuffer::HowMany()
{
    if( pBuffer == NULL ) {
		fprintf( stderr, "FifoBuffer::HowMany: pBuffer is NULL\n" );
        return -1 ;
    }
    return pBuffer->used;
}

/* EOF */
