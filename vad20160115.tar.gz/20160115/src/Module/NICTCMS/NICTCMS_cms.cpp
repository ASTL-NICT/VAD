﻿/*-----------------------------------------------------------------------------
 NICTcms class
-------------------------------------------------------------------------------
 Copyright (C) 2012 - 2016
   National Institute of Information and Communications Technology.
   All rights reserved.
-----------------------------------------------------------------------------*/

#include "NICTcms.h"

using namespace std;

CMS_AVERAGE::CMS_AVERAGE(int ceplen,const vector <string> & kind,int averageFrames){
  CepLen=ceplen;
  Kind=kind;
  for(int n=0;n<(int)Kind.size();n++){
          if(Kind[n]=="cep"){
      for(int d=0;d<CepLen;d++)CMFlag.push_back(true);
    }else if(Kind[n]=="c0"){
      CMFlag.push_back(true);
    }else if(Kind[n]=="dcep"||Kind[n]=="ddcep"){
      for(int d=0;d<CepLen;d++)CMFlag.push_back(false);
    }else if(                Kind[n]=="dc0" ||Kind[n]=="ddc0" ||
	     Kind[n]=="pow"||Kind[n]=="dpow"||Kind[n]=="ddpow"){
      CMFlag.push_back(false);
    }
  }
  VecLen=(int)CMFlag.size();
  Count=0;
  AverageFrames=averageFrames;
  this->tof();
}

// 発話開始終了関数

void CMS_AVERAGE::tof(void){
  for (int i=0;i<VecLen;i++) mean.push_back(0.0);
  TmpParvec.clear();
  OutParvec.clear();
  Count=0;
  return;
}

void CMS_AVERAGE::eof(void){
  return;
}

// 特徴ベクトルの入力関数

void CMS_AVERAGE::in(const vector <double> & parvec){
  vector <double> out;

  // 平均vectorを引く
  for(int d=0;d<VecLen;d++){
    if(CMFlag[d]==false)out.push_back(parvec[d]);
    else out.push_back(parvec[d]-mean[d]);
  }

  OutParvec.push_back(out);

  if (AverageFrames<=0) { // 過去の全てのframeの特徴量から平均vectorを計算する
    for(int d=0;d<VecLen;d++){
      mean[d]=(mean[d]*(double)Count+parvec[d])/((double)(Count+1));
    }
  } else { // 過去AverageFrames個の特徴量から平均vectorを計算する
    while (TmpParvec.size()>=(unsigned int)AverageFrames) {
      TmpParvec.erase(TmpParvec.begin());
    }
    TmpParvec.push_back(parvec);

    for(int d=0;d<VecLen;d++) mean[d]=0;
    for (unsigned int i=0;i<TmpParvec.size();i++) {
      for(int d=0;d<VecLen;d++) {
	mean[d]=mean[d]+TmpParvec[i][d];
      }
    }
    for(int d=0;d<VecLen;d++) {
      mean[d]=mean[d]/(double)TmpParvec.size();
    }
  }

  //  fprintf(stderr,"%d %d\n",TmpParvec.size(),AverageFrames);

  Count++;
  return;
}

// 特徴ベクトルの取得関数

int CMS_AVERAGE::outnum(void) const{
  return((int)OutParvec.size());
}

vector <double> CMS_AVERAGE::out(void){
  vector <double> ret=OutParvec[0];
  OutParvec.erase(OutParvec.begin());
  return(ret);
}










/////////////////////////////////////////////////////////////





// online CMS クラスのメンバ関数定義

// コンストラクタ関数

CMS_ONLINE::CMS_ONLINE(int ceplen,const vector <string> & kind,
		       const vector <double> & initcepmean,int delay){
  CepLen=ceplen;
  Kind=kind;
  for(int n=0;n<(int)Kind.size();n++){
          if(Kind[n]=="cep"){
      for(int d=0;d<CepLen;d++)CMFlag.push_back(true);
    }else if(Kind[n]=="c0"){
      CMFlag.push_back(true);
    }else if(Kind[n]=="dcep"||Kind[n]=="ddcep"){
      for(int d=0;d<CepLen;d++)CMFlag.push_back(false);
    }else if(                Kind[n]=="dc0" ||Kind[n]=="ddc0" ||
	     Kind[n]=="pow"||Kind[n]=="dpow"||Kind[n]=="ddpow"){
      CMFlag.push_back(false);
    }
  }
  VecLen=(int)CMFlag.size();
  for(int d=0;d<VecLen;d++)InitCepMean.push_back(initcepmean[d]);
  Delay=delay;
  Count=0;
  CepMean=InitCepMean;
}

// 補正条件の取得関数

int CMS_ONLINE::get_ceplen(void) const{
  return(CepLen);
}

const vector <string> & CMS_ONLINE::get_kind(void) const{
  return(Kind);
}

int CMS_ONLINE::get_veclen(void) const{
  return(VecLen);
}

const vector <double> & CMS_ONLINE::get_initcepmean(void) const{
  return(InitCepMean);
}

int CMS_ONLINE::get_delay(void) const{
  return(Delay);
}

// 発話開始終了関数

void CMS_ONLINE::tof(void){
  Count=0;
  CepMean=InitCepMean;
  return;
}

void CMS_ONLINE::eof(void){
  return;
}

// 特徴ベクトルの入力関数

void CMS_ONLINE::in(const vector <double> & parvec){
  vector <double> out;
  for(int d=0;d<VecLen;d++){
    if(CMFlag[d]==false)out.push_back(parvec[d]);
    else{
      CepMean[d]=
	((double)(Delay+Count)/(double)(Delay+Count+1))*CepMean[d]+
	parvec[d]/(double)(Delay+Count+1);
      out.push_back(parvec[d]-CepMean[d]);
    }
  }
  OutParvec.push_back(out);
  Count++;
  return;
}

// 特徴ベクトルの取得関数

int CMS_ONLINE::outnum(void) const{
  return((int)OutParvec.size());
}

vector <double> CMS_ONLINE::out(void){
  vector <double> ret=OutParvec[0];
  OutParvec.erase(OutParvec.begin());
  return(ret);
}

// 1pass CMS クラスのメンバ関数定義

// コンストラクタ関数

CMS_1PASS::CMS_1PASS(int ceplen,const vector <string> & kind,double attrate){
  CepLen=ceplen;
  Kind=kind;
  for(int n=0;n<(int)Kind.size();n++){
          if(Kind[n]=="cep"){
      for(int d=0;d<CepLen;d++)CMFlag.push_back(true);
    }else if(Kind[n]=="c0"){
      CMFlag.push_back(true);
    }else if(Kind[n]=="dcep"||Kind[n]=="ddcep"){
      for(int d=0;d<CepLen;d++)CMFlag.push_back(false);
    }else if(                Kind[n]=="dc0" ||Kind[n]=="ddc0" ||
	     Kind[n]=="pow"||Kind[n]=="dpow"||Kind[n]=="ddpow"){
      CMFlag.push_back(false);
    }
  }
  VecLen=(int)CMFlag.size();
  AttRate=attrate;
  InitFlag=true;
  CepMean.resize(VecLen,0.0);
}

// 補正条件の取得関数

int CMS_1PASS::get_ceplen(void) const{
  return(CepLen);
}

const vector <string> & CMS_1PASS::get_kind(void) const{
  return(Kind);
}

int CMS_1PASS::get_veclen(void) const{
  return(VecLen);
}

double CMS_1PASS::get_attrate(void) const{
  return(AttRate);
}

// 発話開始終了関数

void CMS_1PASS::tof(void){
  TmpParvec.clear();
  OutParvec.clear();
  return;
}

void CMS_1PASS::eof(void){
  // 現在の発話の平均ケプストラムの計算

	
	double *cepmean;
	cepmean = new double[VecLen];
  //double cepmean[VecLen];



  for(int d=0;d<VecLen;d++)cepmean[d]=0.0;
  for(int t=0;t<(int)TmpParvec.size();t++){
    for(int d=0;d<VecLen;d++){
      if(CMFlag[d]==false)continue;
      cepmean[d]+=TmpParvec[t][d];
    }
  }
  for(int d=0;d<VecLen;d++){
    if(CMFlag[d]==false)continue;
    cepmean[d]/=(double)TmpParvec.size();
  }
  if(InitFlag==true){
    // チャネル特性の補正
    for(int t=0;t<(int)TmpParvec.size();t++){
      vector <double> parvec;
      for(int d=0;d<VecLen;d++){
	if(CMFlag[d]==false)parvec.push_back(TmpParvec[t][d]);
	else parvec.push_back(TmpParvec[t][d]-cepmean[d]);
      }
      OutParvec.push_back(parvec);
    }
    // 次の発話に対する平均ケプストラムの設定
    for(int d=0;d<VecLen;d++)CepMean[d]=cepmean[d];
    // 第一発話フラグの更新
    InitFlag=false;
  }else{
    // 次の発話に対する平均ケプストラムの計算
    for(int d=0;d<VecLen;d++)
      CepMean[d]=CepMean[d]*(1.0-AttRate)+cepmean[d]*AttRate;
  }

  delete [] cepmean;
  return;
}

// 特徴ベクトルの入力関数

void CMS_1PASS::in(const vector <double> & parvec){
  TmpParvec.push_back(parvec);
  if(InitFlag==false){
    vector <double> out;
    for(int d=0;d<VecLen;d++){
      if(CMFlag[d]==false)out.push_back(parvec[d]);
      else out.push_back(parvec[d]-CepMean[d]);
    }
    OutParvec.push_back(out);
  }
  return;
}

// 特徴ベクトルの取得関数

int CMS_1PASS::outnum(void) const{
  return((int)OutParvec.size());
}

vector <double> CMS_1PASS::out(void){
  vector <double> ret=OutParvec[0];
  OutParvec.erase(OutParvec.begin());
  return(ret);
}

// 2pass CMS クラスのメンバ関数定義

// コンストラクタ関数

CMS_2PASS::CMS_2PASS(int ceplen,const vector <string> & kind){
  CepLen=ceplen;
  Kind=kind;
  for(int n=0;n<(int)Kind.size();n++){
          if(Kind[n]=="cep"){
      for(int d=0;d<CepLen;d++)CMFlag.push_back(true);
    }else if(Kind[n]=="c0"){
      CMFlag.push_back(true);
    }else if(Kind[n]=="dcep"||Kind[n]=="ddcep"){
      for(int d=0;d<CepLen;d++)CMFlag.push_back(false);
    }else if(                Kind[n]=="dc0" ||Kind[n]=="ddc0" ||
	     Kind[n]=="pow"||Kind[n]=="dpow"||Kind[n]=="ddpow"){
      CMFlag.push_back(false);
    }
  }
  VecLen=(int)CMFlag.size();
}

// 補正条件の取得関数

int CMS_2PASS::get_ceplen(void) const{
  return(CepLen);
}

const vector <string> & CMS_2PASS::get_kind(void) const{
  return(Kind);
}

int CMS_2PASS::get_veclen(void) const{
  return(VecLen);
}

// 発話開始終了関数

void CMS_2PASS::tof(void){
  TmpParvec.clear();
  OutParvec.clear();
  return;
}

void CMS_2PASS::eof(void){
  // 平均ケプストラムの計算



	double *cepmean;
  cepmean = new double[VecLen];
  //double cepmean[VecLen];



  for(int d=0;d<VecLen;d++)cepmean[d]=0.0;
  for(int t=0;t<(int)TmpParvec.size();t++){
    for(int d=0;d<VecLen;d++){
      if(CMFlag[d]==false)continue;
      cepmean[d]+=TmpParvec[t][d];
    }
  }
  for(int d=0;d<VecLen;d++){
    if(CMFlag[d]==false)continue;
    cepmean[d]/=(double)TmpParvec.size();
  }
  // 特性補正処理
  for(int t=0;t<(int)TmpParvec.size();t++){
    vector <double> parvec;
    for(int d=0;d<VecLen;d++){
      if(CMFlag[d]==false)parvec.push_back(TmpParvec[t][d]);
      else parvec.push_back(TmpParvec[t][d]-cepmean[d]);
    }
    OutParvec.push_back(parvec);
  }

  delete [] cepmean;
  return;
}

// 特徴ベクトルの入力関数

void CMS_2PASS::in(const vector <double> & parvec){
  TmpParvec.push_back(parvec);
  return;
}

// 特徴ベクトルの取得関数

int CMS_2PASS::outnum(void) const{
  return((int)OutParvec.size());
}

vector <double> CMS_2PASS::out(void){
  vector <double> ret=OutParvec[0];
  OutParvec.erase(OutParvec.begin());
  return(ret);
}
