﻿/*------------------------------------------------------------------------------
// TimeStamp Class Implementation
//------------------------------------------------------------------------------
// Copyright (C) 2012 - 2016
//   National Institute of Information and Communications Technology.
//   All rights reserved.
//----------------------------------------------------------------------------*/

#include "TimeStamp.h"
#include "EventDefine.h"

// コンストラクタ
TimeStamp::TimeStamp()
{
    FirstInputTime = -1 ;
    LastInputTime  = -1 ;
    FirstOutputTime = -1 ;
    LastOutputTime  = -1 ;
    DataSize  = 0 ;
}

// デストラクタ
TimeStamp::~TimeStamp()
{
}

// データ入力時間設定
void TimeStamp::SetInputTime()
{
    // 入力データ個数をカウントする
    DataSize++ ;
    // 設定済？
    if( FirstInputTime == -1 ) {
        // 先頭データの入力時間
        FirstInputTime = clock() ;
    }
    else {
        // 最終データの入力時間
        LastInputTime = clock() ;
    }
}

// データ出力時間設定
void TimeStamp::SetOutputTime()
{
    // 結果出力時間
    FirstOutputTime = LastOutputTime = clock() ;
    // タイムスタンプ出力
    PrintTimeStamp() ;
}

// データ出力時間設定(バイナリデータ)
void TimeStamp::SetOutputTime(int type)
{
    if( type == EPV_DATA ) {
        if( FirstOutputTime == -1 ) {
            // 先頭データの出力時間
            FirstOutputTime = clock() ;
        }
        else {
            // 最終データの出力時間
            LastOutputTime = clock() ;
        }
    }
    else if( type == EV_EOF ) {
        // タイムスタンプ出力
        PrintTimeStamp() ;
    }
}

// タイムスタンプ出力
void TimeStamp::PrintTimeStamp()
{
    // 出力(秒)
    double firstIn  = 0.0 ;
    double firstOut = (double)(FirstOutputTime - FirstInputTime)/CLOCKS_PER_SEC ;
    double lastIn   = (double)(LastInputTime - FirstInputTime)/CLOCKS_PER_SEC ;
    double lastOut  = (double)(LastOutputTime - FirstInputTime)/CLOCKS_PER_SEC ;
    double diffTime = (double)(LastOutputTime - LastInputTime)/CLOCKS_PER_SEC ;
    double rtf      = lastOut * 1000.0 / FRAME_BASE_TIME / (double)DataSize ;
    fprintf( stderr, "TIMESTAMP FirstInputTime=%f LastInputTime=%f FirstOutputTime=%f LastOutputTime=%f DiffTime=%f\n", firstIn, lastIn, firstOut, lastOut, diffTime ) ;
    fprintf( stderr, "RTF = %f\n", rtf ) ;
    fflush( stderr ) ;
    // リセット
    FirstInputTime = -1 ;
    LastInputTime  = -1 ;
    FirstOutputTime = -1 ;
    LastOutputTime  = -1 ;
    DataSize  = 0 ;
}
