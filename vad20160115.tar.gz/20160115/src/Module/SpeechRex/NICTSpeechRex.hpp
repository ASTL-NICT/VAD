﻿/*------------------------------------------------------------------------------
// NICT Speech Rex Class Header
//------------------------------------------------------------------------------
// Copyright (C) 2012 - 2016
// National Institute of Information and Communications Technology.
// All rights reserved.
//----------------------------------------------------------------------------*/

#ifndef _NICTSPEECHREX_HPP_
#define _NICTSPEECHREX_HPP_

#include <cstdio>
#include <string>
#include <sstream>
#include <vector>
#include <list>
#include <set>
#include <iostream>
#include <fstream>
#include <algorithm>

#include "NICTevent2.h"
#include "NICToptions.h"
#include "NICTmmse.h"
#include "NICTmfcc.h"
#include "NICTcms.h"
#include "NICTvad.h"

#include "TimeStamp.h"

class NICTSpeechRex
{
private:
  NICTevent2              *pEvent;
  NICToptions	          *pOption ;
  NICTmmse                *pMMSE;
  NICTmfcc                *pMFCC;
  NICTcms                 *pCMS;
  NICTvad                 *pVAD;
  void                    *pEng;

  TimeStamp               TIMESTAMP ;

  bool                    iniFlag;
  bool                    TimeStampFlag ;
  bool                    UseMemoryFlag ;
  unsigned char           inputFormatID ;
  unsigned char           outputFormatID ;
  int                     DataType ;
  void                    *inputData;

  int                     inputDataTypeID ;   // 入力データの型ID
  int                     inputDataSize ;     // 入力データのフレーム当たりのデータ数
  int                     outputDataTypeID ;  // 出力データの型ID
  int                     outputDataSize ;    // 出力データのフレーム当たりのデータ数
  int                     FE_param_size;      // FEから最終的に出力される特徴量のvector size

  float	                  *paramData ;        // 25次元のみ
  int                     UtteranceNumber ;   // 発話数

  // 出力データ格納リスト
  std::list<std::pair<int, void*> >   outEvent ;
  std::list<std::string>              outString ;
public:
  NICTSpeechRex();
  virtual ~NICTSpeechRex();

  // 初期化
  int Initialize( std::vector<unsigned char> ModuleRoutingTable,
		  unsigned char inputFormat,
		  unsigned char outputFormat,
		  std::string SignalConfig,
		  std::string FilterConfig,
		  bool TimeFlag,
		  bool UseMemory,
                  std::vector<int> _convertFeatureOrder);

  // moduleIDのin/outのdataID/sizeをgetする
  int GetDataParam(unsigned char moduleID,int *dt,int *idtID,int *ids,int *odtID,int *ods);

  // 処理開始
  int Start();
  // 入力データ設定メソッド
  int SetInputData( int size, char *data ) ;
  // 出力データ取得メソッド
  int GetOutputData( int size, char *data, std::string& result ) ;
  // 終了
  int End() ;
  // 中断
  int Cancel();
  // 入力データサイズ取得
  int GetInputSize( int& size1, int& size2 ) ;
  // 出力データサイズ取得
  int GetOutputSize( int& size1, int& size2 ) ;
private:
  int Execute( int key, unsigned char *data ) ;
  void PushEventData( int key, unsigned char *data ) ;
  void* ConvertEventData( int key, unsigned char *data ) ;
  float* ConvertFeatureData( void *event ) ;
  std::vector <int> convertFeatureOrder;
  std::string IntToString(int number);

  void PushOutputData( EventNICT *event, std::string res ) ;
  void *ensure_buffer(void *targetBuffer);

  int EPVToFrameSync( int epv ) ;
  int FrameSyncToEPV( int mark ) ;

  void ReadConfigFile( const char *fileName ) ;
  void CacheReset() ;
  void UseMemory() ;
  void PrintUtteranceNumber() ;
};
;
#endif
