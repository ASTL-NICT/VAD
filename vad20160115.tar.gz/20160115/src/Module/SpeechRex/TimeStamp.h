﻿/*------------------------------------------------------------------------------
// TimeStamp Class Header
//------------------------------------------------------------------------------
// Copyright (C) 2012 - 2016
//   National Institute of Information and Communications Technology.
//   All rights reserved.
//----------------------------------------------------------------------------*/

#ifndef _TIMESTAMP_H_
#define _TIMESTAMP_H_

#include <stdio.h>
#include <time.h>

#define FRAME_BASE_TIME 10  // １フレームの時間

class TimeStamp {
private:
    clock_t FirstInputTime ;    // 先頭データの入力時間
    clock_t LastInputTime ;     // 最終データの入力時間
    clock_t FirstOutputTime ;   // 先頭データの出力時間
    clock_t LastOutputTime ;    // 最終データの出力時間
    long    DataSize ;

public:
    // コンストラクタ
    TimeStamp() ;
    // デストラクタ
    ~TimeStamp() ;

    void SetInputTime() ;
    void SetOutputTime() ;
    void SetOutputTime( int type ) ;
private:
    void PrintTimeStamp() ;
} ;
#endif
