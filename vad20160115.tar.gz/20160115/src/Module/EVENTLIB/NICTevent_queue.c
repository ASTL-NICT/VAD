﻿/*------------------------------------------------------------------------------
// Queue operation function
//------------------------------------------------------------------------------
// Copyright (C) 2009 - 2016
//   National Institute of Information and Communications Technology.
//   All rights reserved.
//----------------------------------------------------------------------------*/

/*
   queue implemented as a linked list

   contents is a char *
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "EventDefine.h"
#include "SSSQueueDefine.h"

void SSSInitQueue( SSSQUEUEP *q)
{
  char *string ;

  /* free remaining queue */
  while ((string = SSSPopQueue( q )))  free(string) ;

  q->top = NULL ;
  q->topp = & ( q->top );
}


void SSSPushQueue( SSSQUEUEP *q, char *string)
{
  SSSQUEUE *psNew;

  /* don't do anything if there is no contents */
  if ( string == NULL ) return ;

  psNew = (SSSQUEUE *) malloc(sizeof(SSSQUEUE));
  psNew->string=(char *) malloc(strlen(string)+1);
  strcpy(psNew->string, string) ;
  psNew->next = NULL ;

  *(q->topp) = psNew ;
  q->topp = & ( psNew->next ) ;
}


char *SSSPopQueue( SSSQUEUEP *q)
{
  SSSQUEUE *old ;
  char *ret ;

  /* nothing more to pop */
  if ( q->top == NULL ) return ( NULL ) ;

  /* get contents and free structure */
  ret = q->top->string;
  old = q->top;
  q->top = q->top->next ;
  if( q->top == NULL ) {
    q->topp = & (q->top);
  }
  free( old ) ;

  /* user has responsibility to free the returned string */
  return ( ret ) ;
}
/* EOF */
