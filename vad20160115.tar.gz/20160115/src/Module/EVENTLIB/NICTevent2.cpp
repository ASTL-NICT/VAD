﻿/*------------------------------------------------------------------------------
// Event handling Modules
//------------------------------------------------------------------------------
// Copyright (C) 2009 - 2016
//   National Institute of Information and Communications Technology.
//   All rights reserved.
//----------------------------------------------------------------------------*/

#include <stdio.h>
#include <iostream>
#include "NICTevent2.h"

// このクラスは、メモリ入出力用イベントライブラリです。
NICTevent2::NICTevent2()
{
}

NICTevent2::~NICTevent2()
{
}

// イベントキューを初期化する
int NICTevent2::Initialize()
{
  self_event_in = 0;
  self_event_in_tmp = 0;

  return 0;
}

void NICTevent2::Terminate()
{
}

// キューよりイベントを取り出す
int NICTevent2::GetEvent(EventNICT **event)
{
  int	receiver;
  int	exit_msg_flg;

  //
  exit_msg_flg = NOT_EXIT ;
  /*  copy tmp queue  */
  while( 1 ) {
    if( self_event_in_tmp == 0 ) {
      break;
    }
    if( self_event_in == SELF_EVENT_QUEUE_SIZE ) {
      fprintf( stderr, "@I/Ocontrol ERROR : Event Queue Overflow.\n" );
      exit_msg_flg = ERROR_EXIT;
      break;
    }
    self_event_in_tmp --;
    self_event_body_queue[ self_event_in ] = self_event_body_queue_tmp[ self_event_in_tmp ];
    self_event_type_queue[ self_event_in ] = self_event_type_queue_tmp[ self_event_in_tmp ];
    self_event_receiver_queue[ self_event_in ] = self_event_receiver_queue_tmp[ self_event_in_tmp ];
    self_event_in ++;
  }
  if( self_event_in == 0 ) {
    /* make sure that circular buffer has been completely processed */
    if( exit_msg_flg != NOT_EXIT ) {
      local_e.message_type = (EPV)exit_msg_flg;
      *event = &local_e;
      return NICT_PROCESS ;
    }
    else {
      return SELF_EVENT_EMPTY ;
    }
  }
  self_event_in --;
  local_e.message_body = ( self_event_body_queue[ self_event_in ] );
  local_e.message_type = (EPV)self_event_type_queue[ self_event_in ];
  receiver = self_event_receiver_queue[ self_event_in ];
  *event = &local_e;              /* Make sure not to remove this line, honey! */

  return receiver ;
}

// イベントデータをキューに設定する
int NICTevent2::PutEvent(int receiver, int type, EventNICT *event)
{
  if( receiver == NICT_NULLDEV ){
    return NOT_EXIT;
  }
  if( receiver == NICT_PROCESS && type == NORMAL_EXIT ) {
    return NORMAL_EXIT;
  }
  else if( receiver == NICT_PROCESS && type == ERROR_EXIT ) {
    return ERROR_EXIT;
  }
  else {
    if( self_event_in_tmp == SELF_EVENT_QUEUE_SIZE ) {
      fprintf( stderr, "@I/Ocontrol ERROR : Event Stack Overflow.\n" );
      return ERROR_EXIT;
    }
    else {
      self_event_receiver_queue_tmp[ self_event_in_tmp ] =receiver;
      self_event_type_queue_tmp[ self_event_in_tmp ] = type;
      self_event_body_queue_tmp[ self_event_in_tmp ] = event;
      self_event_in_tmp ++;
    }
  }

  //	std::cout << "self_event_in_tmp ++ =  " << self_event_in_tmp ++ <<  std::endl;
  return NOT_EXIT;
}
