﻿/*-----------------------------------------------------------------------------
 FBANK class
-------------------------------------------------------------------------------
 Copyright (C) 2012 - 2016
   National Institute of Information and Communications Technology.
   All rights reserved.
-----------------------------------------------------------------------------*/

#include<cmath>

#include "fbank.h"

const double  PI=3.14159265358979;
const double TPI=6.28318530717959;

// メル周波数の計算関数

static double mel(int k,double fres){
  return((double)(1127.0*log(1.0+((double)k-1.0)*fres)));
}

// 実数値用高速フーリエ変換関数

static void fft(double * s, int n, bool inv){

  for(int ii=1,j=1;ii<=n/2;ii++){
    int i=2*ii-1;
    if(j>i){
      double xre=s[j];
      double xri=s[j+1];
      s[j]=s[i];
      s[j+1]=s[i+1];
      s[i]=xre;
      s[i+1]=xri;
    }
    int m=n/2;
    while(m>=2&&j>m){
      j-=m;
      m/=2;
    }
    j+=m;
  }

  for(int limit=2;limit<n;){
    int inc=2*limit;
    double theta=TPI/(double)limit;
    if(inv)theta=-theta;
    double x=sin(0.5*theta);
    double wpr=-2.0*x*x;
    double wpi=sin(theta);
    double wr=1.0;
    double wi=0.0;
    for(int ii=1;ii<=limit/2;ii++){
      int m=2*ii-1;
      for(int jj=0;jj<=(n-m)/inc;jj++){
	int i=m+jj*inc;
	int j=i+limit;
	double xre=wr*s[j]  -wi*s[j+1];
	double xri=wr*s[j+1]+wi*s[j];
	s[j]  =s[i]  -xre;
	s[j+1]=s[i+1]-xri;
	s[i]  =s[i]  +xre;
	s[i+1]=s[i+1]+xri;
      }
      double wx=wr;
      wr=wr*wpr-wi*wpi+wr;
      wi=wi*wpr+wx*wpi+wi;
    }
    limit=inc;
  }

  if(inv)for(int i=1;i<=n;i++)s[i]=s[i]/(n/2);

  return;
}

static void fft(double * s, int m){

  int n =m/2;
  int n2=n/2;
  fft(s,m,false);
  double x=sin(0.5*PI/(double)n);
  double yr2=-2.0*x*x;
  double yi2=sin(PI/(double)n);
  double yr=1.0+yr2;
  double yi=yi2;
  for(int i=2;i<=n2;i++){
    int i1=i+i-1;
    int i2=i1+1;
    int i3=n+n+3-i2;
    int i4=i3+1;
    double wrs=yr;
    double wis=yi;
    double xr1=(s[i1]+s[i3])/2.0;
    double xi1=(s[i2]-s[i4])/2.0;
    double xr2=(s[i2]+s[i4])/2.0;
    double xi2=(s[i3]-s[i1])/2.0;
    s[i1]= xr1+wrs*xr2-wis*xi2;
    s[i2]= xi1+wrs*xi2+wis*xr2;
    s[i3]= xr1-wrs*xr2+wis*xi2;
    s[i4]=-xi1+wrs*xi2+wis*xr2;
    double yr0=yr;
    yr=yr*yr2-yi *yi2+yr;
    yi=yi*yr2+yr0*yi2+yi;
   }

  double tmp=s[1];
  s[1]=tmp+s[2];
  s[2]=0.0;

  return;
}

// フィルタバンク分析クラスのメンバ関数定義

// コンストラクタとディストラクタ関数

FBANK::FBANK(int veclen,int zerolen,int winlen,int shiftlen,int smpfreq,
	     double lowcutoff,double highcutoff,double preemp){

  // 分析条件の設定

  VecLen  =veclen;
  ZeroLen =zerolen;
  WinLen  =winlen;
  ShiftLen=shiftlen;
  FFTLen  =1;
  while(FFTLen<WinLen)FFTLen*=2;

  SmpFreq   =smpfreq;
  LowCutoff =lowcutoff;
  HighCutoff=highcutoff;
  PreEmp    =preemp;

  // ハミング窓の設定

  HamWin=new double [WinLen];
  double a=TPI/(double)(WinLen-1);
  for(int t=0;t<WinLen;t++)HamWin[t]=0.54-0.46*cos(a*(double)t);

  // フィルタバンクの設定

  int    nby2=FFTLen/2;
  double fres=SmpFreq/((double)FFTLen*700.0);

  double mlo=(double)(1127.0*log(1.0+ LowCutoff/700.0));
  double mhi=(double)(1127.0*log(1.0+HighCutoff/700.0));
  KLo=(int)(( LowCutoff/(double)SmpFreq*(double)FFTLen)+1.5);
  if(KLo<1)KLo=1;
  KHi=(int)((HighCutoff/(double)SmpFreq*(double)FFTLen)-0.5);
  if(KHi>nby2-1)KHi=nby2-1;

  LoChan=new int    [FFTLen/2];
  LoWt  =new double [FFTLen/2];



  double *cf;
  cf = new double[VecLen + 1];
  //double cf[VecLen + 1];




  double ms=mhi-mlo;
  for(int d=0;d<=VecLen;d++)cf[d]=((double)(d+1)/(double)(VecLen+1))*ms+mlo;
  for(int k=0,d=0;k<nby2;k++){
    if(k<KLo||k>KHi)LoChan[k]=-1;
    else{
      double melk=mel(k+1,fres);
      while(cf[d]<melk&&d<=VecLen)d++;
      LoChan[k]=d;
    }
  }

  for(int k=0;k<nby2;k++){
    if(k<KLo||k>KHi)LoWt[k]=0.0;
    else{
      int d=LoChan[k];
      if(d>0)LoWt[k]=((cf[d]-mel(k+1,fres))/(cf[d]-cf[d-1]));
      else LoWt[k]=(cf[0]-mel(k+1,fres))/(cf[0]-mlo);
    }
  }

  // 分析用音声波形バッファの確保

  if((WinLen-ZeroLen)%ShiftLen==0){
    WaveLen=WinLen;
  }else{
    WaveLen=ZeroLen+((WinLen-ZeroLen)/ShiftLen+1)*ShiftLen;
  }
  WaveBuf=new short int [WaveLen];
  for(int t=0;t<WaveLen;t++)WaveBuf[t]=0;
  WaveNum=ZeroLen;

  LeftNum=0;

  delete [] cf;
}

FBANK::~FBANK(void){
  delete [] HamWin;
  delete [] LoChan;
  delete [] LoWt;
  delete [] WaveBuf;
}

// 各種定数の取得関数

int FBANK::get_veclen(void) const{
  return(VecLen);
}

int FBANK::get_winlen(void) const{
  return(WinLen);
}

int FBANK::get_shiftlen(void) const{
  return(ShiftLen);
}

int FBANK::get_smpfreq(void) const{
  return(SmpFreq);
}

double FBANK::get_lowcutoff(void) const{
  return(LowCutoff);
}

double FBANK::get_highcutoff(void) const{
  return(HighCutoff);
}

double FBANK::get_preemp(void) const{
  return(PreEmp);
}

// 初期化関数

void FBANK::clear(void){
  for(int t=0;t<WaveLen;t++)WaveBuf[t]=0;
  WaveNum=ZeroLen;
  LeftNum=0;
  FBank.clear();
  return;
}

// 音声波形の入力関数

void FBANK::in(const short int * wave){

  // 音声波形をバッファへ追加

  LeftNum++;

  if(WaveLen!=WaveNum){
    for(int t=0;t<ShiftLen;t++)WaveBuf[WaveNum++]=wave[t];
  }else{
    for(int t=0;t<WaveLen-ShiftLen;t++)WaveBuf[t]=WaveBuf[t+ShiftLen];
    WaveNum-=ShiftLen;
    for(int t=0;t<ShiftLen;t++)WaveBuf[WaveNum++]=wave[t];
  }
  if(WaveNum!=WaveLen)return;

  // プリエンファシス


  double *fftbuf;
  fftbuf = new double[FFTLen];
  //double fftbuf[FFTLen];


  fftbuf[0]=(double)WaveBuf[0]*(1.0-PreEmp);
  for(int t=1;t<WinLen;t++)
    fftbuf[t]=(double)WaveBuf[t]-(double)WaveBuf[t-1]*PreEmp;
  for(int t=WinLen;t<FFTLen;t++)fftbuf[t]=0.0;

  // ハミング窓の適用

  for(int t=0;t<WinLen;t++)fftbuf[t]*=HamWin[t];

  // 対数パワーの計算

  double pow=0.0;
  for(int t=0;t<WinLen;t++)pow+=fftbuf[t]*fftbuf[t];
  if(pow==0.0)pow=1.0/(32768.0*32768.0);
  pow=log(pow);

  // フーリエ変換

  fft(fftbuf-1,FFTLen);

  // フィルタバンク係数の計算


  double *fbank;
  fbank = new double[VecLen];
  //double fbank[VecLen];




  for(int d=0;d<VecLen;d++)fbank[d]=0.0;
  for(int k=1;k<FFTLen/2;k++){
    int d=LoChan[k];
    if(d==-1)continue;
    double t1=fftbuf[2*k];
    double t2=fftbuf[2*k+1];
    double t3=sqrt(t1*t1+t2*t2);
    double t4=LoWt[k]*t3;
    if(d>0)fbank[d-1]+=t4;
    if(d<VecLen)fbank[d]+=t3-t4;
  }

  vector <double> parvec;
  for(int d=0;d<VecLen;d++){
    if(fbank[d]<1.0)parvec.push_back(0.0);
    else parvec.push_back(log(fbank[d]));
  }
  parvec.push_back(pow);

  LeftNum--;
  FBank.push_back(parvec);

  delete [] fftbuf;
  delete [] fbank;

  return;
}

void FBANK::in(const vector <short int> & wave){


  short int *tmp;
  tmp = new short int[ShiftLen];	
  //short int tmp[ShiftLen];


  for(int t=0;t<ShiftLen;t++)tmp[t]=wave[t];
  in(tmp);

  delete [] tmp;
  return;
}

// 音声波形の入力終了関数
void FBANK::flush(void){


  short int *zero;
  zero = new short int[ShiftLen];
  //short int zero[ShiftLen];



  for(int t=0;t<ShiftLen;t++)zero[t]=0;
  int num=LeftNum+(int)FBank.size();
  while(num>(int)FBank.size())in(zero);

  delete [] zero;

  return;
}

// フィルタバンク係数の取得関数

int FBANK::outnum(void) const{
  return((int)FBank.size());
}

vector <double> FBANK::out(void){
  vector <double> ret=FBank[0];
  FBank.erase(FBank.begin());
  return(ret);
}

const vector <vector <double> > & FBANK::get_fbank(void) const{
  return(FBank);
}
