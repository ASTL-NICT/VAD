﻿/*-----------------------------------------------------------------------------
 GMM class
-------------------------------------------------------------------------------
 Copyright (C) 2012 - 2016
   National Institute of Information and Communications Technology.
   All rights reserved.
-----------------------------------------------------------------------------*/

#include<cmath>

#include<vector>
#include<string.h>
#include<stdlib.h>
#include<stdio.h>

#include "addlog.h"
#include "gmm.h"

using namespace std;

const double LOGTPI=1.83787706640935;

// G 定数の計算関数

static double calc_gconst(int veclen,const double * variance){
  double gconst=(double)veclen*LOGTPI;
  for(int d=0;d<veclen;d++)gconst+=log(variance[d]);
  return(gconst);
}

// ファイルから 1 行読み込み要素に分解する関数

static string readline(FILE *fp){
  string str;
  while(true){
    char buf[1024];
    if(!fgets(buf,1024,fp))break;
    str+=buf;
    if(buf[strlen(buf)-1]=='\n')break;
  }

  return(str);
}

static vector <string> readtoken(FILE * fp){
  vector <string> ret;
  string str=readline(fp);
  if(feof(fp)!=0)return(ret);
  str.erase(str.size()-1);


  char *buf;
  buf = new char[str.size()+1];

  //char buf[str.size()+1];


  strcpy(buf,str.c_str());
  for(char * token=strtok(buf," \t\r\n");token;token=strtok(NULL," \t\r\n"))
    ret.push_back(token);

  delete [] buf;
  return(ret);
}

// GMM クラスのメンバ関数定義

// コンストラクタとディストラクタ関数

GMM::GMM(const string & filename){
  vector <string> token;


  FILE * fp=fopen(filename.c_str(),"r");
  if(fp==NULL)
//    throw (char *)"ERR: GMM 定義ファイルのオープンに失敗しました.";
    {
	  fprintf( stderr,  "@NICTvad_init ERROR : GMM definition file open failure.\n" ) ;
	  exit(1);
    }

  // ヘッダの読み込み

  token=readtoken(fp);

  if(token.size() != 1)
//    throw (char *)"ERR: GMM 定義ファイルの読み込みに失敗しました.";
  {
	fprintf( stderr ,"ERR: GMM definition file reading failure.");
	exit(1);
  }

  VecLen=atoi(token[0].c_str());

  if(VecLen <= 0)
//    throw (char *)"ERR: GMM 定義ファイルの読み込みに失敗しました.";
  {
	fprintf( stderr ,"ERR: GMM definition file reading failure.");
	exit(1);
  }

  token=readtoken(fp);

  if(token.size() != 1)
//    throw (char *)"ERR: GMM 定義ファイルの読み込みに失敗しました.";
  {
	fprintf( stderr ,"ERR: GMM definition file reading failure.");
	exit(1);
  }

  MixNum=atoi(token[0].c_str());

  if(MixNum <= 0)
//    throw (char *)"ERR: GMM 定義ファイルの読み込みに失敗しました.";
  {
	fprintf( stderr ,"ERR: GMM definition file reading failure.");
	exit(1);
  }



  // GMM の領域の確保

  BWeight =new double   [MixNum];
  Mean    =new double * [MixNum];
  Variance=new double * [MixNum];
  GConst  =new double   [MixNum];
  for(int m=0;m<MixNum;m++){
    Mean    [m]=new double [VecLen];
    Variance[m]=new double [VecLen];
  }

  // パラメータの読み込み


  for(int m=0;m<MixNum;m++){

	token=readtoken(fp);

	if(token.size() != 1)
    //  throw (char *)"ERR: GMM 定義ファイルの読み込みに失敗しました.";
	
	{
	  fprintf( stderr ,"ERR: GMM definition file reading failure.");
	  exit(1);
    }
	
    double bweight=atof(token[0].c_str());

    if(bweight<0.0)
    //  throw (char *)"ERR: GMM 定義ファイルの読み込みに失敗しました.";
	{
	  fprintf( stderr ,"ERR: GMM definition file reading failure.");
	  exit(1);
    }

    BWeight[m] = log(bweight);

	for(int d=0;d<VecLen;d++){
      token=readtoken(fp);
      if(token.size()!=2)
	//  throw (char *)"ERR: GMM 定義ファイルの読み込みに失敗しました.";
	  {
	    fprintf( stderr ,"ERR: GMM definition file reading failure.");
	    exit(1);
      }
	
      Mean    [m][d]=atof(token[0].c_str());
      Variance[m][d]=atof(token[1].c_str());

      if(Variance[m][d]<=0.0)
	//  throw (char *)"ERR: GMM 定義ファイルの読み込みに失敗しました.";
	  {
	    fprintf( stderr ,"ERR: GMM definition file reading failure.");
	    exit(1);
	  }
    }
    GConst[m]=calc_gconst(VecLen,Variance[m]);
  }



  fclose(fp);

}

GMM::GMM(int veclen,int mixnum){
  VecLen=veclen;
  MixNum=mixnum;
  BWeight =new double   [MixNum];
  Mean    =new double * [MixNum];
  Variance=new double * [MixNum];
  GConst  =new double   [MixNum];
  for(int m=0;m<MixNum;m++){
    BWeight [m]=log(1.0/(double)MixNum);
    Mean    [m]=new double [VecLen];
    Variance[m]=new double [VecLen];
    for(int d=0;d<VecLen;d++){
      Mean    [m][d]=0.0;
      Variance[m][d]=1.0;
    }
    GConst[m]=calc_gconst(VecLen,Variance[m]);
  }
}

GMM::GMM(const GMM & gmm){
  VecLen=gmm.VecLen;
  MixNum=gmm.MixNum;
  BWeight =new double   [MixNum];
  Mean    =new double * [MixNum];
  Variance=new double * [MixNum];
  GConst  =new double   [MixNum];
  for(int m=0;m<MixNum;m++){
    BWeight [m]=gmm.BWeight[m];
    Mean    [m]=new double [VecLen];
    Variance[m]=new double [VecLen];
    for(int d=0;d<VecLen;d++){
      Mean    [m][d]=gmm.Mean    [m][d];
      Variance[m][d]=gmm.Variance[m][d];
    }
    GConst[m]=gmm.GConst[m];
  }
}

GMM::~GMM(void){
  for(int m=0;m<MixNum;m++){
    delete [] Mean    [m];
    delete [] Variance[m];
  }
  delete [] BWeight;
  delete [] Mean;
  delete [] Variance;
  delete [] GConst;
}

// 代入演算子

GMM & GMM::operator=(const GMM & gmm){
  if(this==&gmm)return(*this);
  if(VecLen!=gmm.VecLen||MixNum!=gmm.MixNum){
    for(int m=0;m<MixNum;m++){
      delete [] Mean    [m];
      delete [] Variance[m];
    }
    delete [] BWeight;
    delete [] Mean;
    delete [] Variance;
    delete [] GConst;
    VecLen=gmm.VecLen;
    MixNum=gmm.MixNum;
    BWeight =new double   [MixNum];
    Mean    =new double * [MixNum];
    Variance=new double * [MixNum];
    GConst  =new double   [MixNum];
    for(int m=0;m<MixNum;m++){
      Mean    [m]=new double [VecLen];
      Variance[m]=new double [VecLen];
    }
  }
  for(int m=0;m<MixNum;m++){
    BWeight[m]=gmm.BWeight[m];
    for(int d=0;d<VecLen;d++){
      Mean    [m][d]=gmm.Mean    [m][d];
      Variance[m][d]=gmm.Variance[m][d];
    }
    GConst[m]=gmm.GConst[m];
  }
  return(*this);
}

// ベクトル長, 混合数の取得関数

int GMM::get_veclen(void) const{
  return(VecLen);
}

int GMM::get_mixnum(void) const{
  return(MixNum);
}

// 混合分岐確率, 平均分散ベクトルの取得関数

double GMM::get_bweight(int m) const{
  return(BWeight[m]);
}

const double * GMM::get_mean(int m) const{
  return(Mean[m]);
}

const double * GMM::get_variance(int m) const{
  return(Variance[m]);
}

// 混合分岐確率, 平均分散ベクトルの設定関数

void GMM::set_bweight(int m,double bweight){
  BWeight[m]=bweight;
  return;
}

void GMM::set_mean(int m,const vector <double> & mean){
  for(int d=0;d<VecLen;d++)Mean[m][d]=mean[d];
  return;
}

void GMM::set_mean(int m,const double * mean){
  for(int d=0;d<VecLen;d++)Mean[m][d]=mean[d];
  return;
}

void GMM::set_variance(int m,const vector <double> & variance){
  for(int d=0;d<VecLen;d++)Variance[m][d]=variance[d];
  GConst[m]=calc_gconst(VecLen,Variance[m]);
  return;
}

void GMM::set_variance(int m,const double * variance){
  for(int d=0;d<VecLen;d++)Variance[m][d]=variance[d];
  GConst[m]=calc_gconst(VecLen,Variance[m]);
  return;
}

// 確率の計算関数

double GMM::calc_prob(const double * parvec) const{
  double prob=LOG_ZERO;
  for(int m=0;m<MixNum;m++)prob=addlog(prob,calc_prob(m,parvec));
  return(prob);
}


double GMM::calc_prob(int m,const double * parvec) const{
  double prob=0.0;
  for(int d=0;d<VecLen;d++){
    double x=parvec[d]-Mean[m][d];
    prob+=(x*x)/Variance[m][d];
  }
  prob=(prob+GConst[m])/-2.0;
  prob+=BWeight[m];
  return(prob);
}



#if !defined(SPRINTRA2_OPT_GMM_CALC_PROB)


double GMM::calc_prob(const vector <double> & parvec) const{


  double *tmp;
  tmp = new double[VecLen];

 //double tmp[VecLen];


  for(int d=0;d<VecLen;d++)tmp[d]=parvec[d];



  double calc_prob_tmp;
  calc_prob_tmp = calc_prob(tmp);

  delete [] tmp;

  return(calc_prob_tmp);

//  return(calc_prob(tmp));




}


double GMM::calc_prob(int m,const vector <double> & parvec) const{


  double *tmp;
  tmp = new double[VecLen];
  //double tmp[VecLen];


  for(int d=0;d<VecLen;d++)tmp[d]=parvec[d];



  double calc_prob_tmp;
  calc_prob_tmp = calc_prob(m,tmp);
  delete [] tmp;

  return(calc_prob_tmp);
  //return(calc_prob(m,tmp));


}

#endif

