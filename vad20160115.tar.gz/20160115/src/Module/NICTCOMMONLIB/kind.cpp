/*-----------------------------------------------------------------------------
 KIND + KIND_CONV class
-------------------------------------------------------------------------------
 Copyright (C) 2012 - 2016
   National Institute of Information and Communications Technology.
   All rights reserved.
-----------------------------------------------------------------------------*/

#include "kind.h"
#include<string.h>

using namespace std;

// 特徴量構成クラスのメンバ関数定義

// コンストラクタ関数

KIND::KIND(int ceplen){
  CepLen=ceplen;
  VecLen=0;
}

KIND::KIND(int ceplen,const string & comp){
  CepLen=ceplen;
  VecLen=0;
  add(comp);
}

KIND::KIND(int ceplen,const vector <string> & comps){
  CepLen=ceplen;
  VecLen=0;
  add(comps);
}

// ケプストラム次元数の取得関数

int KIND::get_ceplen(void) const{
  return(CepLen);
}

// 特徴量次元数の取得関数

int KIND::get_veclen(void) const{
  return(VecLen);
}

// 特徴量構成の取得関数

const string & KIND::operator [] (int n) const{
  return((*((vector <string> *)this))[n]);
}

// 特徴量の有無判定関数

bool KIND::has(const string & comp){
  for(int n=0;n<(int)size();n++)if((*this)[n]==comp)return(true);
  return(false);
}

bool KIND::has(const KIND & kind){
  for(int n=0;n<kind.size();n++)if(has(kind[n])==false)return(false);
  return(true);
}

// 初期化関数

void KIND::clear(void){
  ((vector <string> *)this)->clear();
  VecLen=0;
  return;
}

// 特徴量数の取得関数

int KIND::size(void) const{
  return(((vector <string> *)this)->size());
}

// 特徴量の追加関数

bool KIND::add(const string & comp){

  char *buf;
  buf = new char[comp.size()+1];

   //char buf[comp.size()+1];



  strcpy(buf,comp.c_str());
  for(char * token=strtok(buf,"+");token;token=strtok(NULL,"+")){
    string tmp=(string)token;
    if(tmp!="cep" && tmp!="dcep" && tmp!="ddcep" &&
       tmp!="c0"  && tmp!="dc0"  && tmp!="ddc0"  &&
       tmp!="pow" && tmp!="dpow" && tmp!="ddpow"){
		  delete [] buf;
		  return(false);
	}
    this->push_back(tmp);
    if(tmp=="cep" || tmp=="dcep" || tmp=="ddcep"){
      VecLen += CepLen;
    }else{
      VecLen++;
    }
  }

  delete [] buf;
  return(true);
}

bool KIND::add(const vector <string> & comps){
  for(int n=0;n<(int)comps.size();n++)if(add(comps[n])==false)return(false);
  return(true);
}

// 特徴量構成変換クラス

// コンストラクタとディストラクタ関数

KIND_CONV::KIND_CONV(const KIND & ikind,const KIND & okind){
  IKind=new KIND(ikind);
  OKind=new KIND(okind);
  for(int n=0;n<OKind->size();n++){
    string comp=(*OKind)[n];
    int d=0;
    for(int m=0;m<IKind->size();m++){
      if((*IKind)[m]==comp){
	if(comp=="cep"||comp=="dcep"||comp=="ddcep"){
	  for(int i=0;i<IKind->get_ceplen();i++)IOMap.push_back(d++);
	}else{
	  IOMap.push_back(d++);
	}
	break;
      }else{
	if((*IKind)[m]=="cep"||(*IKind)[m]=="dcep"||(*IKind)[m]=="ddcep"){
	  d+=IKind->get_ceplen();
	}else{
	  d++;
	}
      }
    }
  }
}

KIND_CONV::~KIND_CONV(void){
  delete IKind;
  delete OKind;
}

// 特徴量構成の変換関数

vector <double> KIND_CONV::conv(const vector <double> & parvec) const{
  vector <double> ret;
  for(int d=0;d<(int)IOMap.size();d++)ret.push_back(parvec[IOMap[d]]);
  return(ret);
}

