﻿/*-----------------------------------------------------------------------------
 VAD class
-------------------------------------------------------------------------------
 Copyright (C) 2012 - 2016
   National Institute of Information and Communications Technology.
   All rights reserved.
-----------------------------------------------------------------------------*/

#include<cmath>
#include <numeric>

#include "addlog.h"
#include "NICTvad.h"

using namespace std;

// VAD ロジッククラスのメンバ関数定義

// コンストラクタとディストラクタ関数

VAD::VAD(int conlen,int gaplen,int durlen,int startlen,int endlen){
  Cont = new CONT(conlen);
  Gap  = new GAP(gaplen);
  Dur  = new DUR(durlen);
  Start= new START(startlen);
  End  = new END(endlen);
}

VAD::~VAD(void){
  delete Cont;
  delete Gap;
  delete Dur;
  delete Start;
  delete End;
}

// 初期化関数

void VAD::reset(void){
   Cont->reset();
    Gap->reset();
    Dur->reset();
  Start->reset();
    End->reset();
  return;
}

// VAD の入力関数

void VAD::in(bool flag){

  Cont->input(flag);
  if( Cont->size()!=0)  Gap->input( Cont->output());
  else return;
  if(  Gap->size()!=0)  Dur->input(  Gap->output());
  else return;
  if(  Dur->size()!=0)Start->input(  Dur->output());
  else return;
  if(Start->size()!=0)  End->input(Start->output());
  else return;
  if(  End->size()==0)return;

  vector <bool> vadseq=End->output();
  for(int n=0;n<(int)vadseq.size();n++)VADOut.push_back(vadseq[n]);

  return;
}

// VAD の入力終了関数

void VAD::flush(void){
    Gap->input( Cont->flush());
	Dur->input(  Gap->flush2());
  Start->input(  Dur->flush());
    End->input(Start->flush());

  vector <bool> vadseq=End->flush();
  for(int n=0;n<(int)vadseq.size();n++)VADOut.push_back(vadseq[n]);

  return;
}

// VAD 結果の取得関数

int VAD::outnum(void) const{
  return((int)VADOut.size());
}

bool VAD::out(void){
  bool ret=VADOut[0];
  VADOut.erase(VADOut.begin());
  return(ret);
}

// フレーム単位 VAD クラス (GMM) のメンバ関数定義

// コンストラクタとディストラクタ関数

FRAME_VAD_GMM::FRAME_VAD_GMM(double posthr,const GMM & noisygmm,
			     const GMM & noisegmm){
  PostThresh=posthr;
  NoisyGMM=new GMM(noisygmm);
  NoiseGMM=new GMM(noisegmm);
}

FRAME_VAD_GMM::~FRAME_VAD_GMM(void){
  delete NoisyGMM;
  delete NoiseGMM;
}

// 初期化関数

void FRAME_VAD_GMM::reset(void){
  VADOut.clear();
  return;
}

// 特徴ベクトルの入力関数

void FRAME_VAD_GMM::in(const vector <double> & parvec){
  double prob   =NoisyGMM->calc_prob(parvec);
  double allprob=addlog(prob,NoiseGMM->calc_prob(parvec));
  double post   =exp(prob-allprob);
  if(post>PostThresh)VADOut.push_back(true);
  else VADOut.push_back(false);
  return;
}

// VAD 結果出力関数

int FRAME_VAD_GMM::outnum(void) const{
  return((int)VADOut.size());
}

bool FRAME_VAD_GMM::out(void){
  bool ret=VADOut[0];
  VADOut.erase(VADOut.begin());
  return(ret);
}

// フレーム単位 VAD クラス (パワー) のメンバ関数定義

// コンストラクタ関数

FRAME_VAD_POW::FRAME_VAD_POW(double powthr,int initlen, int noisebuflen){
  Count=0;
  PowThresh=powthr;
  InitNoiseLen=initlen;
  InitNoisePow=0.0;
  NoiseBufferLen=noisebuflen;
}

// 初期化関数

void FRAME_VAD_POW::reset(void){
  Count=0;
  InitNoisePow=0.0;
  PowBuf.clear();
  VADOut.clear();
  NoiseBuf.clear();
  NoiseTmp.clear();
  return;
}

// パワーの入力関数

void FRAME_VAD_POW::in(double pow){
  Count++;
  if(Count<InitNoiseLen){
    PowBuf.push_back(pow);
  }else if(Count==InitNoiseLen){
    PowBuf.push_back(pow);
    InitNoisePow=0.0;
    for(int t=0;t<(int)PowBuf.size();t++)InitNoisePow+=PowBuf[t];
    InitNoisePow/=(double)PowBuf.size();
    for(int t=0;t<(int)PowBuf.size();t++){
      if((InitNoisePow+PowThresh)<=PowBuf[t])VADOut.push_back(true);
      else VADOut.push_back(false);
    }
    PowBuf.clear();
  }else{
    if((InitNoisePow+PowThresh)<pow)VADOut.push_back(true);
    else VADOut.push_back(false);
  }
  return;
}

// ノイズ候補データの入力
void FRAME_VAD_POW::in_noise(double pow)
{
  NoiseTmp.push_back( pow );
}

// ノイズデータの更新
void FRAME_VAD_POW::renew_noise(bool is_noise)
{
  if ( ! NoiseTmp.empty() ) {
    double noise = NoiseTmp.at(0);
    NoiseTmp.pop_front();

    // ノイズであれば、ノイズモデルにデータを追加する
    if ( is_noise ) {
      NoiseBuf.push_back( noise );
    }

    // ノイズバッファが規定値以上であれば、ノイズモデルの更新を行う
    if ( NoiseBuf.size() > (unsigned int)NoiseBufferLen ) {
      // ノイズバッファのサイズ調整を行う
      while( NoiseBuf.size() > (unsigned int)NoiseBufferLen ) NoiseBuf.pop_front();

      // ノイズモデルを更新する
      InitNoisePow = std::accumulate( NoiseBuf.begin(), NoiseBuf.end(), 0.0 ) / NoiseBuf.size();
    } else {
      // Do Nothing
    }
  }
}

// パワーの入力終了関数

void FRAME_VAD_POW::flush(void){
  if(Count==0)return;
  if(Count<InitNoiseLen){
    for(int t=0;t<Count;t++)InitNoisePow+=PowBuf[t];
    InitNoisePow/=(double)Count;
    for(int t=0;t<Count;t++){
      if((InitNoisePow+PowThresh)<=PowBuf[t])VADOut.push_back(true);
      else VADOut.push_back(false);
    }
  }
  return;
}

// VAD 結果出力関数

int FRAME_VAD_POW::outnum(void) const{
  return((int)VADOut.size());
}

bool FRAME_VAD_POW::out(void){
  bool ret=VADOut[0];
  VADOut.erase(VADOut.begin());
  return(ret);
}
