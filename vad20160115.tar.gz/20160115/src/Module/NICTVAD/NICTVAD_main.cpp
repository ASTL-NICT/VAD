﻿/*------------------------------------------------------------------------------
// 発話区間検出プログラム NICTVAD_main.cpp
//------------------------------------------------------------------------------
// Copyright (C) 2012 - 2016
//   National Institute of Information and Communications Technology.
//   All rights reserved.
//----------------------------------------------------------------------------*/

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include "NICTvad.h"

using namespace std;

NICTvad::NICTvad()
{
  pEvent       = NULL ;
  pOption      = NULL ;
  pcvadOptions  = NULL ;
  options_id   = 0 ;

  pInp_Kind = NULL;
  pOut_Kind = NULL;
  pPow_Kind = NULL;
  pGmm_Kind = NULL;

  pTo_pow = NULL;
  pTo_gmm = NULL;
  pTo_out = NULL;

  pVad_pow = NULL;
  pVad_gmm = NULL;

  pVad = NULL;

  EventTbl.clear() ;
}

NICTvad::NICTvad(NICTevent2 *event, NICToptions *option)
{
  pEvent       = event ;
  pOption      = option ;
  pcvadOptions  = NULL ;
  options_id   = 0 ;

  pInp_Kind = NULL;
  pOut_Kind = NULL;
  pPow_Kind = NULL;
  pGmm_Kind = NULL;

  pTo_pow = NULL;
  pTo_gmm = NULL;
  pTo_out = NULL;

  pVad_pow = NULL;   	
  pVad_gmm = NULL;

  pVad = NULL;

  EventTbl.clear() ;
}

NICTvad::~NICTvad()
{
  // LocalEvent領域を解放する
  if( !EventTbl.empty() ) {
    intFloatStar *ptr ;
    int size = EventTbl.size() ;
    for( int i = 0 ; i < size ; i++ ) {
      ptr = EventTbl[i] ;
      if( ptr->fs ) free( ptr->fs ) ;
      free( ptr ) ;
    }
  }
}

int NICTvad::Initialize( int argn, char *argv[] )
{
  int     iRetVal;
  char*   optionvaluebox = NULL;

  /* ---------- options envelop start ---------- */



  const char default_options[] = "\
	Vad=off\n\
    FrameLength=20.0\n\
    FrameShift=10.0\n\
    SamplingFrequency=16000\n\
    CepstrumOrder=12\n\
    InputParameter=pow+cep+dpow+dcep\n\
    OutputParameter=cep+dpow+dcep\n\
    PowParameter=pow\n\
    InitialPowerLength=100.0\n\
    PowerThreshold=8.0\n\
    GMMParameter=cep+dpow+dcep\n\
    NoisyGMM=\n\
    NoiseGMM=\n\
    PosteriorThreshold=0.8\n\
    ConsecutiveLength=3\n\
    MaximumGapLength=30\n\
    MinimumUtteranceLength=20\n\
    PrerollLength=30\n\
    AfterrollLength=30\n\
    SendSpeechOnly=yes\n\
    Tof_eq_StartMark=on\n\
    PowerNoiseSequentialEstimation=off\n\
    PowerNoiseBufferLength=200\n\
    ";


  /*  Get Options  */
  iRetVal = pOption->ReadMain( argn, argv, &options_id, NICT_VAD_STR,
			       default_options, OPT_PrintOptList |OPT_PrintSetOptList );

  if( iRetVal == OPT_FAILURE ) {
    fprintf( stderr, "@NICTvad ERROR: Invalid argument.\n" );
    return( 1 );
  }

  /****  parse options  ****/

  cvadOptions.VAD = "off";     	
  cvadOptions.FrameLength = 20.0;
  cvadOptions.FrameShift = 10.0;
  cvadOptions.SamplingFrequency = 16000;
  cvadOptions.CepstrumOrder = 12;
  cvadOptions.InputParameter = "pow+cep+dpow+dcep";
  cvadOptions.OutputParameter = "cep+dpow+dcep";
  cvadOptions.PowParameter = "pow";
  cvadOptions.InitialPowerLength = 100.0;
  cvadOptions.PowerThreshold = 8.0;
  cvadOptions.GMMParameter = "cep+dpow+dcep";
  cvadOptions.NoisyGMM = "";
  cvadOptions.NoiseGMM = "";
  cvadOptions.PosteriorThreshold = 0.8;
  cvadOptions.ConsecutiveLength = 3;
  cvadOptions.MaximumGapLength = 30;
  cvadOptions.MinimumUtteranceLength = 20;
  cvadOptions.PrerollLength = 30;
  cvadOptions.AfterrollLength = 30;
  cvadOptions.SendSpeechOnly = "yes";
  cvadOptions.Tof_eq_StartMark = "on";
  cvadOptions.PowerNoiseSequentialEstimation = "off";
  cvadOptions.PowerNoiseBufferLength = 200;

  pcvadOptions = &cvadOptions;



  /* Vad */
  iRetVal = pOption->GetOptValue( options_id, "VAD", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTvad_init: OPTIONLIB error in Vad\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION Vad is not setting.\n" ) ;
    return( 1 );
  }

  pcvadOptions->VAD = (string)optionvaluebox;

  if ( pcvadOptions->VAD != "on" &&
       pcvadOptions->VAD != "off" ){
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION Vad is different\n" ) ;
    free( optionvaluebox );
    return( 1 );
  }

  free( optionvaluebox );




  /* FrameLength */
  iRetVal = pOption->GetOptValue( options_id, "FrameLength", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTvad_init: OPTIONLIB error in FrameLength\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION FrameLength is not setting.\n" ) ;
    return( 1 );
  }
  pcvadOptions->FrameLength = atof(optionvaluebox);

  if( pcvadOptions->FrameLength <= 0.0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION FrameLength is out of range.\n" ) ;
    return( 1 );
  }
  free( optionvaluebox );


  /* FrameShift */
  iRetVal = pOption->GetOptValue( options_id, "FrameShift", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTvad_init: OPTIONLIB error in FrameShift\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION FrameShift is not setting.\n" ) ;
    return( 1 );
  }
  pcvadOptions->FrameShift = atof(optionvaluebox);

  if( pcvadOptions->FrameShift <= 0.0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION FrameShift is out of range.\n" ) ;
    return( 1 );
  }
  free( optionvaluebox );


  /* SamplingFrequency */
  iRetVal = pOption->GetOptValue( options_id, "SamplingFrequency", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTvad_init: OPTIONLIB error in SamplingFrequency\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION SamplingFrequency is not setting.\n" ) ;
    return( 1 );
  }
  pcvadOptions->SamplingFrequency = atoi(optionvaluebox);

  if( pcvadOptions->SamplingFrequency <= 0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION SamplingFrequency is out of range.\n" ) ;
    return( 1 );
  }
  free( optionvaluebox );



  /* CepstrumOrder */
  iRetVal = pOption->GetOptValue( options_id, "CepstrumOrder", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTvad_init: OPTIONLIB error in CepstrumOrder\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION CepstrumOrder is not setting.\n" ) ;
    return( 1 );
  }
  pcvadOptions->CepstrumOrder = atoi(optionvaluebox);

  if( pcvadOptions->CepstrumOrder <= 0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION CepstrumOrder is out of range.\n" ) ;
    return( 1 );
  }
  free( optionvaluebox );


  /* InputParameter */
  iRetVal = pOption->GetOptValue( options_id, "InputParameter", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTvad_init: OPTIONLIB error in InputParameter\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION InputParameter is not setting.\n" ) ;
    return( 1 );
  }

  pcvadOptions->InputParameter = (string)optionvaluebox;

  char *buf;
  buf = new char[pcvadOptions->InputParameter.size()+1];

  strcpy(buf , pcvadOptions->InputParameter.c_str());

  for(char * token = strtok(buf,"+") ; token ; token = strtok(NULL,"+")){
    string tmp = (string)token;
    if(tmp != "cep" && tmp != "dcep" && tmp != "ddcep" &&
       tmp != "c0"  && tmp != "dc0"  && tmp != "ddc0" &&
       tmp != "pow" && tmp != "dpow" && tmp != "ddpow") {
      fprintf( stderr,  "@NICTvad_init ERROR : OPTION InputParameter is different\n" ) ;
      return( 1 );
    }
    kind_in.push_back(tmp);
  }

  //KIND inp_kind( pcvadOptions->CepstrumOrder, kind_in );
  pInp_Kind = new KIND( pcvadOptions->CepstrumOrder, kind_in );

  free( optionvaluebox );
  delete [] buf;


  /* OutputParameter */
  iRetVal = pOption->GetOptValue( options_id, "OutputParameter", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTvad_init: OPTIONLIB error in OutputParameter\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION OutputParameter is not setting.\n" ) ;
    return( 1 );
  }

  pcvadOptions->OutputParameter = (string)optionvaluebox;

  buf = new char[pcvadOptions->OutputParameter.size()+1];

  strcpy(buf , pcvadOptions->OutputParameter.c_str());


  for(char * token = strtok(buf,"+") ; token ; token = strtok(NULL,"+")){
    string tmp = (string)token;
    if(tmp != "cep" && tmp != "dcep" && tmp != "ddcep" &&
       tmp != "c0"  && tmp != "dc0"  && tmp != "ddc0" &&
       tmp != "pow" && tmp != "dpow" && tmp != "ddpow") {
      fprintf( stderr,  "@NICTvad_init ERROR : OPTION OutputParameter is different\n" ) ;
      return( 1 );
    }
    kind_out.push_back(tmp);
  }

  //KIND out_kind( pcvadOptions->CepstrumOrder, kind_out );
  pOut_Kind = new KIND( pcvadOptions->CepstrumOrder, kind_out );

  free( optionvaluebox );
  delete [] buf;


  /* PowParameter */
  iRetVal = pOption->GetOptValue( options_id, "PowParameter", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTvad_init: OPTIONLIB error in PowParameter\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION PowParameter is not setting.\n" ) ;
    return( 1 );
  }

  pcvadOptions->PowParameter = (string)optionvaluebox;

  buf = new char[pcvadOptions->PowParameter.size()+1];

  strcpy(buf , pcvadOptions->PowParameter.c_str());


  for(char * token = strtok(buf,"+") ; token ; token = strtok(NULL,"+")){
    string tmp = (string)token;
    if(tmp != "c0" && tmp != "pow"){
      fprintf( stderr,  "@NICTvad_init ERROR : OPTION PowParameter is different\n" ) ;
      return( 1 );
    }
    kind_pow.push_back(tmp);
  }

  if(kind_pow.size() > 1) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION PowParameter is different\n" ) ;
    return( 1 );
  }

  //KIND pow_kind( pcvadOptions->CepstrumOrder, kind_pow );
  pPow_Kind = new KIND( pcvadOptions->CepstrumOrder, kind_pow );

  //if(inp_kind.has(pow_kind)==false){
  if(pInp_Kind->has(*pPow_Kind) == false){
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION PowParameter is different\n" ) ;
    return( 1 );
  }

  free( optionvaluebox );
  delete [] buf;


  /* InitialPowerLength */
  iRetVal = pOption->GetOptValue( options_id, "InitialPowerLength", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTvad_init: OPTIONLIB error in InitialPowerLength\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION InitialPowerLength is not setting.\n" ) ;
    return( 1 );
  }
  pcvadOptions->InitialPowerLength = atof(optionvaluebox);

  if( pcvadOptions->InitialPowerLength <= 0.0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION InitialPowerLength is out of range.\n" ) ;
    return( 1 );
  }
  free( optionvaluebox );


  /* PowerThreshold */
  iRetVal = pOption->GetOptValue( options_id, "PowerThreshold", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTvad_init: OPTIONLIB error in PowerThreshold\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION PowerThreshold is not setting.\n" ) ;
    return( 1 );
  }

  pcvadOptions->PowerThreshold = atof(optionvaluebox);

  if(0 <= pcvadOptions->PowerThreshold) {
    if( isdigit( *optionvaluebox ) == 0 ) {
      fprintf( stderr, "NICTvad_init: OPTIONLIB error in PowerThreshold is out of range.\n" );
      return( 1 );
    }
  }


  free( optionvaluebox );


  /* GMMParameter */
  iRetVal = pOption->GetOptValue( options_id, "GMMParameter", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTvad_init: OPTIONLIB error in GMMParameter\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION GMMParameter is not setting.\n" ) ;
    return( 1 );
  }

  pcvadOptions->GMMParameter = (string)optionvaluebox;

  buf = new char[pcvadOptions->GMMParameter.size()+1];

  strcpy(buf , pcvadOptions->GMMParameter.c_str());


  for(char * token = strtok(buf,"+") ; token ; token = strtok(NULL,"+")){
    string tmp = (string)token;
    if(tmp != "cep" && tmp != "dcep" && tmp != "ddcep" &&
       tmp != "c0"  && tmp != "dc0"  && tmp != "ddc0" &&
       tmp != "pow" && tmp != "dpow" && tmp != "ddpow") {
      fprintf( stderr,  "@NICTvad_init ERROR : OPTION GMMParameter is different\n" ) ;
      return( 1 );
    }
    kind_gmm.push_back(tmp);
  }

  //KIND gmm_kind( pcvadOptions->CepstrumOrder, kind_gmm );
  pGmm_Kind = new KIND( pcvadOptions->CepstrumOrder, kind_gmm );

  if(pInp_Kind->has(*pGmm_Kind)==false){
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION GMMParameter is different\n" ) ;
    return( 1 );
  }

  free( optionvaluebox );
  delete [] buf;


  /* NoisyGMM */
  iRetVal = pOption->GetOptValue( options_id, "NoisyGMM", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTvad_init: OPTIONLIB error in NoisyGMM\n" );
    return( 1 );
  }

  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION NoisyGMM is not setting.\n" ) ;
    return( 1 );
  }

  pcvadOptions->NoisyGMM = (string)optionvaluebox;

  free( optionvaluebox );


  /* NoiseGMM */
  iRetVal = pOption->GetOptValue( options_id, "NoiseGMM", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTvad_init: OPTIONLIB error in NoiseGMM\n" );
    return( 1 );
  }

  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION NoiseGMM is not setting.\n" ) ;
    return( 1 );
  }

  pcvadOptions->NoiseGMM = (string)optionvaluebox;

  free( optionvaluebox );


  /* PosteriorThreshold */
  iRetVal = pOption->GetOptValue( options_id, "PosteriorThreshold", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTvad_init: OPTIONLIB error in PosteriorThreshold\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION PosteriorThreshold is not setting.\n" ) ;
    return( 1 );
  }

  if( isdigit( *optionvaluebox ) == 0 ) {
    fprintf( stderr, "NICTvad_init:  OPTION PosteriorThreshold is out of range.\n" );
    return( 1 );
  }

  pcvadOptions->PosteriorThreshold = atof(optionvaluebox);

  if( pcvadOptions->PosteriorThreshold < 0.0 || pcvadOptions->PosteriorThreshold > 1.0) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION PosteriorThreshold is out of range.\n" ) ;
    return( 1 );
  }
  free( optionvaluebox );


  /* ConsecutiveLength */
  iRetVal = pOption->GetOptValue( options_id, "ConsecutiveLength", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTvad_init: OPTIONLIB error in ConsecutiveLength\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION ConsecutiveLength is not setting.\n" ) ;
    return( 1 );
  }
  pcvadOptions->ConsecutiveLength = atoi(optionvaluebox);

  if( pcvadOptions->ConsecutiveLength <= 0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION ConsecutiveLength is out of range.\n" ) ;
    return( 1 );
  }
  free( optionvaluebox );


  /* MaximumGapLength */
  iRetVal = pOption->GetOptValue( options_id, "MaximumGapLength", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTvad_init: OPTIONLIB error in MaximumGapLength\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION MaximumGapLength is not setting.\n" ) ;
    return( 1 );
  }
  pcvadOptions->MaximumGapLength = atoi(optionvaluebox);

  if( pcvadOptions->MaximumGapLength <= 0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION MaximumGapLength is out of range.\n" ) ;
    return( 1 );
  }
  free( optionvaluebox );



  /* MinimumUtteranceLength */
  iRetVal = pOption->GetOptValue( options_id, "MinimumUtteranceLength", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTvad_init: OPTIONLIB error in MinimumUtteranceLength\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION MinimumUtteranceLength is not setting.\n" ) ;
    return( 1 );
  }
  pcvadOptions->MinimumUtteranceLength = atoi(optionvaluebox);

  if( pcvadOptions->MinimumUtteranceLength <= 0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION MinimumUtteranceLength is out of range.\n" ) ;
    return( 1 );
  }
  free( optionvaluebox );


  /* PrerollLength */
  iRetVal = pOption->GetOptValue( options_id, "PrerollLength", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTvad_init: OPTIONLIB error in PrerollLength\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION PrerollLength is not setting.\n" ) ;
    return( 1 );
  }
  pcvadOptions->PrerollLength = atoi(optionvaluebox);

  if( pcvadOptions->PrerollLength <= 0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION PrerollLength is out of range.\n" ) ;
    return( 1 );
  }
  free( optionvaluebox );


  /* AfterrollLength */
  iRetVal = pOption->GetOptValue( options_id, "AfterrollLength", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTvad_init: OPTIONLIB error in AfterrollLength\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION AfterrollLength is not setting.\n" ) ;
    return( 1 );
  }
  pcvadOptions->AfterrollLength = atoi(optionvaluebox);

  if( pcvadOptions->AfterrollLength <= 0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION AfterrollLength is out of range.\n" ) ;
    return( 1 );
  }
  free( optionvaluebox );


  /* SendSpeechOnly */
  iRetVal = pOption->GetOptValue( options_id, "SendSpeechOnly", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTvad_init: OPTIONLIB error in SendSpeechOnly\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION SendSpeechOnly is not setting.\n" ) ;
    return( 1 );
  }

  pcvadOptions->SendSpeechOnly = (string)optionvaluebox;

  if ( pcvadOptions->SendSpeechOnly != "yes" &&
       pcvadOptions->SendSpeechOnly != "no" ){
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION SendSpeechOnly is different\n" ) ;
    return( 1 );
  }

  free( optionvaluebox );


  /* Tof_eq_StartMark */
  iRetVal = pOption->GetOptValue( options_id, "Tof_eq_StartMark", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTvad_init: OPTIONLIB error in Tof_eq_StartMark\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION Tof_eq_StartMark is not setting.\n" ) ;
    return( 1 );
  }

  pcvadOptions->Tof_eq_StartMark = (string)optionvaluebox;

  if ( pcvadOptions->Tof_eq_StartMark != "on"  &&
       pcvadOptions->Tof_eq_StartMark != "off"){
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION Tof_eq_StartMark is different\n" ) ;
    return( 1 );
  }


  free( optionvaluebox );

  /* PowerNoiseSequentialEstimation */
  iRetVal = pOption->GetOptValue( options_id, "PowerNoiseSequentialEstimation", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTvad_init: OPTIONLIB error in PowerNoiseSequentialEstimation\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION PowerNoiseSequentialEstimation is not setting.\n" ) ;
    return( 1 );
  }

  pcvadOptions->PowerNoiseSequentialEstimation = (string)optionvaluebox;

  if ( pcvadOptions->PowerNoiseSequentialEstimation != "on" &&
       pcvadOptions->PowerNoiseSequentialEstimation != "off" ){
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION PowerNoiseSequentialEstimation is different\n" ) ;
    return( 1 );
  }

  free( optionvaluebox );


  /* PowerNoiseBufferLength */
  iRetVal = pOption->GetOptValue( options_id, "PowerNoiseBufferLength", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTvad_init: OPTIONLIB error in PowerNoiseBufferLength\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION PowerNoiseBufferLength is not setting.\n" ) ;
    return( 1 );
  }
  pcvadOptions->PowerNoiseBufferLength = atoi(optionvaluebox);

  if( pcvadOptions->PowerNoiseBufferLength <= 0 ) {
    fprintf( stderr,  "@NICTvad_init ERROR : OPTION PowerNoiseBufferLength is out of range.\n" ) ;
    return( 1 );
  }
  free( optionvaluebox );

  // パワー VAD の準備

  winlen  =(int)((double)pcvadOptions->SamplingFrequency*0.001*pcvadOptions->FrameLength+0.5);
  initlen=(int)((double)pcvadOptions->InitialPowerLength/(double)pcvadOptions->FrameShift+0.5);

  pVad_pow = new FRAME_VAD_POW(pcvadOptions->PowerThreshold,initlen, pcvadOptions->PowerNoiseBufferLength);

  // GMM VAD の準備

  GMM  noisygmm(pcvadOptions->NoisyGMM);
  GMM  noisegmm(pcvadOptions->NoiseGMM);

  if(noisygmm.get_veclen() != pGmm_Kind->get_veclen() ||
     noisegmm.get_veclen() != pGmm_Kind->get_veclen()){
    fprintf( stderr, "@NICTvad_init ERROR : The number of dimensions of GMM and the amount of the features is not in agreement. \n");
    return(1);
  }

  //FRAME_VAD_GMM  vad_gmm(pcvadOptions->PosteriorThreshold, noisygmm, noisegmm);
  pVad_gmm = new FRAME_VAD_GMM(pcvadOptions->PosteriorThreshold, noisygmm, noisegmm);

  // 特徴構成変換の準備

  //KIND_CONV to_pow(inp_kind, pow_kind);
  //KIND_CONV to_gmm(inp_kind, gmm_kind);
  //KIND_CONV to_out(inp_kind, out_kind);
  pTo_pow = new KIND_CONV(*pInp_Kind, *pPow_Kind);
  pTo_gmm = new KIND_CONV(*pInp_Kind, *pGmm_Kind);
  pTo_out = new KIND_CONV(*pInp_Kind, *pOut_Kind);

  // VAD の準備

  pVad = new VAD( pcvadOptions->ConsecutiveLength, pcvadOptions->MaximumGapLength, pcvadOptions->MinimumUtteranceLength, pcvadOptions->PrerollLength, pcvadOptions->AfterrollLength);


  // intFloatStarを200個作成して置く
  EventUseIndex = 0 ;
  for( int i = 0 ; i < 200 ; i++ ) {
    if( GetLocalEvent() == NULL ) return 1 ;
  }

  prev = false;

  tof_flag = false;

  return 0;
}


void NICTvad::Terminate( int arg )
{
  if(pInp_Kind)  delete pInp_Kind;
  if(pOut_Kind)  delete pOut_Kind;
  if(pPow_Kind)  delete pPow_Kind;
  if(pGmm_Kind)  delete pGmm_Kind;

  if(pTo_pow)  delete pTo_pow;
  if(pTo_gmm)  delete pTo_gmm;
  if(pTo_out)  delete pTo_out;

  if(pVad_pow) delete pVad_pow;
  if(pVad_gmm) delete pVad_gmm;

  if(pVad)  delete pVad;
}


void NICTvad::Execute( int eventType, EventNICT *event )
{

  intFloatStar *pifs = (intFloatStar*)event->message_body;
  EventUseIndex = 0 ;


  if(pcvadOptions->VAD == "on"){     	


    switch( event->message_type ) {
    case INITIALIZE:
      break;

    case EV_KILL:
      pEvent->PutEvent( NICT_PROCESS, NORMAL_EXIT, NULL );
      break;

    case EV_ABEND:
      pEvent->PutEvent( NICT_PROCESS, ERROR_EXIT, NULL );
      break;

    case EPV_DATA:

      if (tof_flag ){

	// 入力特徴ベクトルの設定
	inp_parvec.clear();
	for( int d = 0 ; d < pInp_Kind->get_veclen() ; d++) inp_parvec.push_back((double)pifs->fs[d]);

	// 出力特徴ベクトルの追加
	out_parvec.push_back(pTo_out->conv(inp_parvec));

	// POW VAD への入力
        double vad_power = 0.0;
	if( pPow_Kind->has("pow") ) {
          vad_power = 10.0 * log10( exp(pTo_pow->conv(inp_parvec)[0] ) / (double)winlen );
        } else if( pPow_Kind->has("c0") ) {
          vad_power = pTo_pow->conv(inp_parvec)[0];
        }
        pVad_pow->in( vad_power );
        if ( pcvadOptions->PowerNoiseSequentialEstimation == "on" ) {
          pVad_pow->in_noise( vad_power );
        }

	// GMM VAD への入力
	pVad_gmm->in(pTo_gmm->conv(inp_parvec));

	// VAD への入力
	while(pVad_pow->outnum() != 0 && pVad_gmm->outnum() != 0){
          bool is_speech_section = pVad_pow->out() & pVad_gmm->out();
          pVad->in( is_speech_section );

          // 発話検出（パワー） のノイズモデルを更新する
          if ( pcvadOptions->PowerNoiseSequentialEstimation == "on" ) {
            pVad_pow->renew_noise( !is_speech_section );   // 発話区間でないのならば、ノイズ
          }
	}


	// 特徴ベクトルの送信

	bool loop_flg = false;

	if ( out_parvec.empty() )  loop_flg = true;
	else  loop_flg = false;

	//while( pVad->outnum() != 0){
	while( (pVad->outnum() != 0) && !loop_flg){

	  curr = pVad->out();

	  if((prev == true) && (curr == false) && !startmark) pEvent->PutEvent( NICTD_MARKED_PARA, EPV_ENDPU, NULL );

	  if((startmark == true) ||(pcvadOptions->SendSpeechOnly != "yes" ) || (curr != false)){

	    if ((prev == false) && (curr == true)) {
	      if( pcvadOptions->Tof_eq_StartMark == "on" && startmark) startmark = false;
	      else pEvent->PutEvent( NICTD_MARKED_PARA, EPV_STARTPU, NULL );
	    }

	    intFloatStar *ptr = GetLocalEvent() ;

	    for(int d = 0 ; d < pOut_Kind->get_veclen() ; d++) {

	      ptr->fs[d] = (float)out_parvec[0][d] ;

	    }

	    pEvent->PutEvent( NICTD_MARKED_PARA, EPV_DATA, (EventNICT*)ptr );

	  }

	  out_parvec.erase(out_parvec.begin());
	  prev = curr;

	  if ( out_parvec.empty() )  loop_flg = true;

	}
      }

      break;

    case EV_TOF:

      prev = false;
      startmark = false;

      if(tof_flag) pEvent->PutEvent( NICTD_MARKED_PARA, EV_EOF, NULL );
      else tof_flag = true;

      inp_parvec.clear();
      out_parvec.clear();
      pVad_pow->reset();
      pVad_gmm->reset();

      pEvent->PutEvent( NICTD_MARKED_PARA, EV_TOF, NULL );

      if( pcvadOptions->Tof_eq_StartMark == "on" ) {
	pEvent->PutEvent( NICTD_MARKED_PARA, EPV_STARTPU, NULL );
	prev = true;
	startmark = true;
      }

      break;

    case EV_EOF:

      if (tof_flag ){

	pVad_pow->flush();

	while( pVad_pow->outnum() != 0 && pVad_gmm->outnum() != 0){
	  if(pVad_pow->out() & pVad_gmm->out())  pVad->in(true);
	  else pVad->in(false);
	}

	pVad->flush();


	// 特徴ベクトルの送信

	bool loop_flg = false;

	if ( out_parvec.empty() )  loop_flg = true;
	else  loop_flg = false;

	//while( pVad->outnum() != 0){
	while( (pVad->outnum() != 0) && !loop_flg){

	  curr = pVad->out();

	  if((prev == true) && (curr == false) && (!startmark)) pEvent->PutEvent( NICTD_MARKED_PARA, EPV_ENDPU, NULL );

	  if((startmark == true) || (pcvadOptions->SendSpeechOnly != "yes" ) || (curr != false)){

	    if ((prev == false) && (curr == true)) {
	      if( pcvadOptions->Tof_eq_StartMark == "on" && startmark) startmark = false;
	      else pEvent->PutEvent( NICTD_MARKED_PARA, EPV_STARTPU, NULL );
	    }

	    intFloatStar *ptr = GetLocalEvent() ;

	    for(int d = 0 ; d < pOut_Kind->get_veclen() ; d++) {

	      ptr->fs[d] = (float)out_parvec[0][d] ;

	    }

	    pEvent->PutEvent( NICTD_MARKED_PARA, EPV_DATA, (EventNICT*)ptr );

	  }

	  out_parvec.erase(out_parvec.begin());
	  prev = curr;

	  if ( out_parvec.empty() )  loop_flg = true;

	}

	if( prev || startmark == true )	pEvent->PutEvent( NICTD_MARKED_PARA, EPV_ENDPU, NULL );

	pEvent->PutEvent( NICTD_MARKED_PARA, EV_EOF, NULL );
	tof_flag = false;

      }

      break;

    case EPV_STARTPU:

      break;

    case EPV_ENDPU:

      break;

    case EV_ABORT:    /* cancel of speech */

      pEvent->PutEvent( NICTD_MARKED_PARA, EV_ABORT, NULL );
      break;

    default:
      break;
    }
  }     	
  else{

    switch( event->message_type ) {
    case INITIALIZE:
      break;

    case EV_KILL:
      pEvent->PutEvent( NICT_PROCESS, NORMAL_EXIT, NULL );
      break;

    case EV_ABEND:
      pEvent->PutEvent( NICT_PROCESS, ERROR_EXIT, NULL );
      break;

    case EPV_DATA:
      {
	// 入力特徴ベクトルの設定
	inp_parvec.clear();
	out_parvec.clear();

	for( int d = 0 ; d < pInp_Kind->get_veclen() ; d++)  inp_parvec.push_back((double)pifs->fs[d]);

	// 出力特徴ベクトルの追加
	out_parvec.push_back(pTo_out->conv(inp_parvec));

	// 特徴ベクトルの送信
	for(int d = 0 ; d < pOut_Kind->get_veclen() ; d++)	pifs->fs[d] = (float)out_parvec[0][d] ;

	pifs->i  = pOut_Kind->get_veclen() ;

	pEvent->PutEvent( NICTD_MARKED_PARA, EPV_DATA, (EventNICT*)(pifs));

	break;
      }
    case EV_TOF:
      {
	pEvent->PutEvent( NICTD_MARKED_PARA, EV_TOF, NULL );
	break;
      }
    case EV_EOF:
      {
	pEvent->PutEvent( NICTD_MARKED_PARA, EV_EOF, NULL );
	break;
      }
    case EPV_STARTPU:
      {
	pEvent->PutEvent( NICTD_MARKED_PARA, EPV_STARTPU, NULL );
	break;
      }
    case EPV_ENDPU:
      {
	pEvent->PutEvent( NICTD_MARKED_PARA, EPV_ENDPU, NULL );
	break;
      }
    case EV_ABORT:    /* cancel of speech */
      {
	pEvent->PutEvent( NICTD_MARKED_PARA, EV_ABORT, NULL );
	break;
      }
    default:
      break;
    }

  }   	
}




// データタイプ・個数取得処理
void NICTvad::GetDataParam( int *in_size1, int *in_size2, int *out_size1, int *out_size2)
{

  *in_size1 = DEF_FLOAT;
  *in_size2 = pInp_Kind->get_veclen();

  *out_size1 = DEF_FLOAT;
  *out_size2 = pOut_Kind->get_veclen();

  return;
}

// intFloatStar型の領域を確保して、そのポインタを返す。
// 既存領域がある場合は生成しない。
intFloatStar* NICTvad::GetLocalEvent()
{
  intFloatStar* ptr ;

  if( EventUseIndex < (int)EventTbl.size() ) {
    ptr = EventTbl[EventUseIndex] ;
  }
  else {
    ptr = (intFloatStar*)malloc(sizeof(intFloatStar)) ;
    if( ptr == NULL ) {
      fprintf( stderr, "NICTvad_execute: Cannot alloc memory for local_data\n" );
      return NULL ;
    }
    ptr->i  = pOut_Kind->get_veclen() ;
    ptr->fs = (float*)malloc( sizeof(float) * pOut_Kind->get_veclen() ) ;
    if( ptr->fs == NULL ) {
      fprintf( stderr, "NICTvad_execute: Cannot alloc memory for local_data.fs\n" );
      free( ptr ) ;
      return NULL ;
    }
    EventTbl.push_back( ptr ) ;
  }
  EventUseIndex++ ;

  return ptr ;
}
