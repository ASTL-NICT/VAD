#include <stdio.h>
#include <stdlib.h>

void usage(int argc, char **argv) {
  fprintf(stderr,"\n");
  fprintf(stderr,"Usage\n");
  fprintf(stderr,"  %s [-h] [-b] [-d (dim)] < (FrameSync output)\n",argv[0]);
  fprintf(stderr,"  cat (FrameSync output) | %s [-b] [-d (dim)]\n",argv[0]);
  fprintf(stderr,"\n");
  fprintf(stderr,"Comment\n");
  fprintf(stderr,"  Convert binary FrameSync messages (output from NICTmmcv)\n");
  fprintf(stderr,"  to human readable text.\n");
  fprintf(stderr,"\n");
  fprintf(stderr,"Args\n");
  fprintf(stderr,"  -b: Byte swap. This is necessary when the output endian\n");
  fprintf(stderr,"      of NICTmmcv is different from the native endian.");
  fprintf(stderr,"      See \"outputByteOrder\" in .ini file for the byte order.\n");
  fprintf(stderr,"  -d: Number of feature vector dimension. default=25\n");
  fprintf(stderr,"\n");
  fprintf(stderr,"  FrameSync output\n");
  fprintf(stderr,"    Binary output from NICTmmcv.\n");
  fprintf(stderr,"    This output must be fed from stdin. Input can be\n");
  fprintf(stderr,"    a file or the direct output (stdout, not stderr)\n");
  fprintf(stderr,"    from NICTmmcv.\n");
  fprintf(stderr,"\n");
  exit(1);
}

void swap_endian32(unsigned int *value)
{
  unsigned int v=*value;
  v=(v>>24)|(v<<24)|((v>>8)&0xFF00)|((v<<8)&0xFF0000);
  *value=v;
}

int main(int argc,char **argv) {

  int n;
  int byte_swap = 0;
  int veclen = 25;

  for (n = 1; n < argc; n++) {
    if (argv[n][0] != '-') usage(argc, argv);
    switch(argv[n][1]) {
      case 'b':
        byte_swap = 1;
        break;
      case 'd':
        if (++n < argc) {
          veclen=atoi(argv[n]);
        } else {
          fprintf(stderr, "ERR: no value for \"-d\"\n");
          usage(argc, argv);
        }
        break;
      case 'h':
        usage(argc, argv);
      default:
        fprintf(stderr, "ERR: invalid option %s\n", argv[n]);
        usage(argc, argv);
        break;
    }
  }

  if (veclen<=0) {
    fprintf(stderr,"ERR: dim[%d] is not valid\n",veclen);
    exit(2);
  }

  unsigned int header;
  float *data = (float*)malloc(sizeof(float) * veclen);
  if (data == NULL) {
    fprintf(stderr,"ERR: cant get memory\n");
    exit(2);
  }

  int j = 0;
  int vad = 0;
  unsigned int frameNo = 0;

  while (fread((void*)&header,sizeof(unsigned int),1,stdin)==1) {
    fread((void*)data,sizeof(float)*veclen,1,stdin);
    if (byte_swap) swap_endian32(&header);
    if (header==0) { // data packet # NICTASR:DATA_MARK
      fprintf(stdout,"%010d [%d] vad=%d\n",frameNo,j,vad);
      frameNo++;
      if (vad==1) j++;
    } else if (header==1) { // speech start # NICTASR:START_MARK
      fprintf(stdout,"===speech start\n");
      vad=1;
      j=0;
    } else if (header==2) { // speech end # NICTASR:END_MARK
      vad=0;
      j=0;
      fprintf(stdout,"===speech end\n");
    } else if (header==9) { // new file # NICTASR:TOF_MARK
      frameNo=0;
      fprintf(stdout,"===new file\n");
    } else if (header==10) { // eof marker # NICTASR:EOF_MARK
      fprintf(stdout,"===EOF\n");
      j=0;
    } else { // something wrong ...
      fprintf(stdout,"Unexpected header: %d\n",header);
      break;
    }
    fflush(stdout);
  }
  if (data) free(data);
  return 0;
}
