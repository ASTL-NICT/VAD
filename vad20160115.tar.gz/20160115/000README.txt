
 VAD 20160115版

配布物の説明

[1] ディレクトリ構成
　doc/        NICTmmcv(VADの実行ファイル）の入出力フォーマットに関する
              ドキュメント。

　model/      NICTmmcvの実行に必要なモデル一式。

　src/        NICTmmcv、および、サンプルスクリプトで使用する
              framesync2txtのソースがあります。

　vad_script/ VADサンプルスクリプト。
              NICTmmcvを使用して、与えられた音声ファイルリストに対し、
              音声区間検出を実行し、検出した音声区間を表示するサンプル
              スクリプトがあります。

[2] コンパイル/インストール方法
  src/000INSTALL.txtを参照してください。

[3] VADサンプルスクリプトの実行
  vad_script/000README.txtを参照してください。

-以上

