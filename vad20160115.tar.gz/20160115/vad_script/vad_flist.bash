#!/bin/bash

#******************************************************************
# 1. Set proper LD_LIBRARY_PATH
# 2. Use python2.7 or above, but not python 3.X. 
#******************************************************************
PYTHON27=python

#
BASE_DIR=${0%/*}
if [ "$BASE_DIR" == "$0" ]; then
  BASE_DIR=`pwd`
fi

MMCV=${BASE_DIR}/NICTmmcv
FRAMESYNC=${BASE_DIR}/framesync2txt
SPEECH_RATIO=${BASE_DIR}/speech_ratio.py
BASE_PARAM=${BASE_DIR}/NICTmmcv_flist.ini


# Assumption
#   (1) Binary files and data files are in current directory
#       and ../model (relavive from current directory).
#   (2) Parameter lines in $BASE_PARAM start with no blanks, 
#       as well as no blanks before "=", that is, param lines look
#       like "(param)=(val)" or "(param)= (val)".
#       Otherwise create_param doesn't work.
#   (3) Audio file format is 16kHz, 1ch, 16bit linear PCM.
#   (4) Filenames in the input wav file list must be with full-path.
#   (5) Files listed in the input wav file list must be .wav files.
#       (You can use .raw files just by setting "inputFormat=NoHeader"
#        NICTmmcv_flist.ini, which is now set to WavFo

function usage () {
  echo ""
  # $1 == extra message
  if [ $# == 0 -o "$1" == "-h" ]; then echo $1; fi
  echo "------------------------------------------------------------"
  echo "Usage: $0 [-h] [OPTIONS for speech_ratio.py]  (wav_file_list)" 
  echo "  Output VAD results of input files to stdout."
  echo ""
  echo "Argument"
  echo "  wav_file_list: text list of .wav file paths."
  echo ""
  echo "OPTIONS"
  echo "  Options for speech_ratio.py. See usage below."
  $PYTHON27 $SPEECH_RATIO -h
  echo "------------------------------------------------------------"
  exit
}

#------------------------------------------------------------ def
DIM=25
FRAME_PER_MSEC=10
SAMPLING_RATE=16000
BYTE_PER_SAMPLE=2

#------------------------------------------------------------ arguments
if [ $# -eq 0 ]; then 
  usage
#  exit
fi

if [ $# -eq 1 ]; then
  flistpath=$1
  options=""
elif [ $# -gt 1 ]; then
  argv=("$@")
  flistpath="${argv[$#-1]}"
  unset argv[$#-1]
  options="${argv[@]}"
fi

absflistpath="$(cd $(dirname $flistpath) && pwd)/$(basename $flistpath)"
if [ ! -e $absfilepath ]; then
  echo "Error: File not found. Check \"$1\""
  exit
fi

#------------------------------------------------------------ start
pushd $BASE_DIR > /dev/null

#param_file=`mktemp`
#log_file=`mktemp`
param_file=./tmp_$$.ini
log_file=./make_$$.log

exit_cmd="rm -f $param_file; popd > /dev/null"
trap "eval $exit_cmd; exit" 2

sed 's|^inputFd=.*$|inputFd='"$absflistpath"'|' $BASE_PARAM > $param_file

byte_order=$(grep '^outputByteOrder=' $param_file)
[ "${byte_order##*=}" == "Big" ] && fs_opt="-b -d $DIM" || fs_opt="-d $DIM"

vad_config=$(grep '^SignalProcessingConfigFile=' $param_file)
sp_opt="-S -C ${vad_config##*=} $options"

$MMCV $param_file 2> /dev/null | \
  $FRAMESYNC $fs_opt | \
  $PYTHON27 $SPEECH_RATIO $sp_opt $absflistpath
eval $exit_cmd
