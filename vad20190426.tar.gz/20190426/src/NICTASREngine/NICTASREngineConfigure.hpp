/*-----------------------------------------------------------------------------
 NICT ASR Engine Configure Class
-------------------------------------------------------------------------------
 Copyright (C) 2012 - 2016
   National Institute of Information and Communications Technology.
   All rights reserved.
-----------------------------------------------------------------------------*/

#ifndef _NICTASRENGINECONFIGURE_HPP_
#define _NICTASRENGINECONFIGURE_HPP_

#include <cstdio>
#include <string>
#include <vector>

// NICTASREngine用の設定情報をファイルより読み込み処理を行うクラス
class NICTASREngineConfigure {
public:
  bool                       TimeStamp ;
  bool                       UseMemory ;
  unsigned char              inputFormatId ;
  unsigned char              inputEndianId ;
  unsigned char              outputFormatId ;
  unsigned char              outputEndianId ;
  std::string                inputFd ;
  std::string                outputFd ;
  std::string                SignalConfig ;
  std::string                FilterConfig ;
  std::vector<int>           convertFeatureOrder;
  std::vector<unsigned char> ModuleRoutingTable;

public:
  NICTASREngineConfigure() ;
  virtual ~NICTASREngineConfigure() ;

  bool ReadIniFile( const char *IniFileName, std::vector<std::string> ArgFileList ) ;
private:
  int ModuleName2ModuleNo(std::string name);

public:
  std::vector<std::string>   WaveFileList;
  int                        ListPosition;
  bool                       SetNextList();

private:
  bool  GetWaveList( const char *ListFile );
};

#endif
