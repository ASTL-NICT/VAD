﻿/*------------------------------------------------------------------------------
// NICT Speech Rex Class Implementation
//------------------------------------------------------------------------------
// Copyright (C) 2012 - 2016
//   National Institute of Information and Communications Technology.
//   All rights reserved.
//----------------------------------------------------------------------------*/
#define NICT_DEBUG_PRINT(X) (std::cerr << __func__ << "(" << __LINE__ << ") " << X << std::endl)

#include "NICTSpeechRex.hpp"
#include "SpeechRexDefine.h"
#include "NICTSpeechRexDefine.h"

//#endif
#include "NICTheader.h"

#ifdef WIN32
#include <regex>
#endif

using namespace std;

// コンストラクタ
NICTSpeechRex::NICTSpeechRex()
{
  // 変数初期化
  iniFlag   = false ;
  pEvent    = NULL ;
  pOption   = NULL ;

  pMMSE     = NULL ;

  pVAD      = NULL ;
  pMFCC     = NULL ;
  pCMS      = NULL ;

  inputData = NULL ;
  paramData = NULL ;
  UtteranceNumber = 0 ;
  outString.clear() ;
  outEvent.clear() ;

  FE_param_size=-1;
  convertFeatureOrder.clear(); // default no convert
}

// デストラクタ
NICTSpeechRex::~NICTSpeechRex()
{
  // オブジェクト廃棄処理
  if( inputData ) {
    if( inputDataTypeID == DATA_TYPE_SHORT ) {
      if( ((intShortStar*)inputData)->ss ) free( ((intShortStar*)inputData)->ss ) ;
    }
    else if( inputDataTypeID == DATA_TYPE_FLOAT ) {
      if( ((intFloatStar*)inputData)->fs ) free( ((intFloatStar*)inputData)->fs ) ;
    }
    else if( inputDataTypeID == DATA_TYPE_DOUBLE ) {
      if( ((intDoubleStar*)inputData)->ds ) free( ((intDoubleStar*)inputData)->ds ) ;
    }
    free( inputData ) ;
  }
  if( paramData ) {
    free( paramData ) ;
  }
  if( pEvent ) {
    pEvent->Terminate() ;
    delete pEvent ;
  }
  if( pOption ) {
    delete pOption ;
  }
  if( pMMSE ) {
    pMMSE->Terminate(0) ;
    delete pMMSE ;
  }
  if( pMFCC ) {
    pMFCC->Terminate(0) ;
    delete pMFCC ;
  }
  if( pCMS ) {
    pCMS->Terminate(0) ;
    delete pCMS ;
  }
  if( pVAD ) {
    pVAD->Terminate(0) ;
    delete pVAD ;
  }
}

int NICTSpeechRex::GetDataParam(
					unsigned char moduleID,
					int *dt,
					int *idtID,
					int *ids,
					int *odtID,
					int *ods
					) {

  if( moduleID == ID_MODULE_NICTMMSE && pMMSE!=NULL) {
    *dt = NICTD_WAVE ;
    pMMSE->GetDataParam(idtID,ids,odtID,ods);
  }
  else if( moduleID == ID_MODULE_NICTMFCC && pMFCC!=NULL) {
    *dt = NICTD_MARKED_WAVE ;
    pMFCC->GetDataParam(idtID,ids,odtID,ods);
  }
  else if( moduleID == ID_MODULE_NICTCMS && pCMS!=NULL) {
    *dt = NICTD_CEP ;
    pCMS->GetDataParam(idtID,ids,odtID,ods);
  }
  else if( moduleID == ID_MODULE_NICTVAD && pVAD!=NULL) {
    *dt = NICTD_PARA ;
    pVAD->GetDataParam(idtID,ids,odtID,ods);
  }
  else return -1;
  return 0;
}

string NICTSpeechRex::IntToString(int number) {
  stringstream ss;
  ss << number;
  return ss.str();
}

  // 初期化
int NICTSpeechRex::Initialize( std::vector<unsigned char> ModuleRoutingTable,
				       unsigned char inputFormat,
				       unsigned char outputFormat,
				       std::string SignalConfig,
				       std::string FilterConfig,
				       bool TimeFlag,
				       bool UseMemory,
				       std::vector<int> _convertFeatureOrder
				       )
{
  // 初期化済チェック
  if( iniFlag ) return SR_ERROR_INIT;

  try {
    // 指定値を保存する
    inputFormatID   = inputFormat ;
    outputFormatID  = outputFormat ;

    // 必要なオブジェクトを作成する
    pEvent  = new NICTevent2() ;
    pOption = new NICToptions() ;
    if( pEvent == NULL || pOption == NULL ) return SR_ERROR_INIT_FRONT;

    // 入出力モジュールに必要なオブジェクトのみ生成する
    for (int i=0;i<(int)ModuleRoutingTable.size();i++) {
      int index=ModuleRoutingTable[i];

      switch( index ) {
      case ID_MODULE_NICTMMSE:
	// NICTmmseオブジェクト生成
	pMMSE = new NICTmmse( pEvent, pOption ) ;
	if( pMMSE == NULL ) return SR_ERROR_INIT_FRONT;
	break ;
      case ID_MODULE_NICTMFCC:
	// NICTmfccオブジェクト生成
	pMFCC = new NICTmfcc( pEvent, pOption ) ;
	if( pMFCC == NULL ) return SR_ERROR_INIT_FRONT;
	break ;
      case ID_MODULE_NICTCMS:
	// NICTcmsオブジェクト生成
	pCMS = new NICTcms( pEvent, pOption ) ;
	if( pCMS == NULL ) return SR_ERROR_INIT_FRONT;
	break ;
      case ID_MODULE_NICTVAD:
	// NICTvadオブジェクト生成
	pVAD = new NICTvad( pEvent, pOption ) ;
	if( pVAD == NULL ) return SR_ERROR_INIT_FRONT;
	break ;
      }
    }

    // モジュールの初期化をする
    // 作成したオブジェクトを使用して、オプション値のチェックを行う
    int ret = pEvent->Initialize();
    string config = "-config="+SignalConfig ;
    const char *argv[2] = { "dummy", config.c_str() };

    // NICTmmse初期化
    if( pMMSE ) {
      ret |= pMMSE->Initialize( 2, (char**)argv ) ;
    }
    // NICTmfcc初期化
    if( pMFCC ) {
      ret |= pMFCC->Initialize( 2, (char**)argv ) ;
    }
    // NICTcms初期化
    if( pCMS ) {
      ret |= pCMS->Initialize( 2, (char**)argv ) ;
    }
    // NICTvad初期化
    if( pVAD ) {
      ret |= pVAD->Initialize( 2, (char**)argv ) ;
    }

    if( ret ) return SR_ERROR_INIT_FRONT;

    // 整形処理オブジェクトが生成されていたらSprinTraのエンジンを生成して初期化する


    // 入力モジュールのタイプ、バイトサイズ、データ数を設定する
    int dummy ;

    // 最終的にFEから出力される特徴量のvector sizeを設定する
    GetDataParam(ModuleRoutingTable.back(),&dummy,&dummy,&dummy,&dummy,&FE_param_size);

    // in/out moduleのdata type/sizeをgetする
    if (GetDataParam( ModuleRoutingTable.front(),&DataType, &inputDataTypeID, &inputDataSize, &dummy, &dummy )!=0) return SR_ERROR_SYSTEM;
    if (GetDataParam( ModuleRoutingTable.back(),&dummy, &dummy, &dummy,&outputDataTypeID, &outputDataSize )!=0) return SR_ERROR_SYSTEM;

    // 入力データ格納領域を確保する
    if( inputDataTypeID == DATA_TYPE_SHORT ) {
      inputData = malloc(sizeof(intShortStar));
      if( inputData == NULL ) return SR_ERROR_INIT_FRONT;
      ((intShortStar*)inputData)->i = inputDataSize ;
      ((intShortStar*)inputData)->ss = (short*)malloc( sizeof(short) * inputDataSize ) ;
      if( ((intShortStar*)inputData)->ss == NULL ) return SR_ERROR_INIT_FRONT ;
    }
    else if( inputDataTypeID == DATA_TYPE_FLOAT ) {
      inputData = malloc(sizeof(intFloatStar));
      if( inputData == NULL ) return SR_ERROR_INIT_FRONT;
      ((intFloatStar*)inputData)->i = inputDataSize ;
      ((intFloatStar*)inputData)->fs = (float*)malloc( sizeof(float) * inputDataSize ) ;
      if( ((intFloatStar*)inputData)->fs == NULL ) return SR_ERROR_INIT_FRONT ;
    }
    else if( inputDataTypeID == DATA_TYPE_DOUBLE ) {
      inputData = (intDoubleStar*)malloc(sizeof(intDoubleStar));
      if( inputData == NULL ) return SR_ERROR_INIT_FRONT;
      ((intDoubleStar*)inputData)->i = inputDataSize ;
      ((intDoubleStar*)inputData)->ds = (double*)malloc( sizeof(double) * inputDataSize ) ;
      if( ((intDoubleStar*)inputData)->ds == NULL) return SR_ERROR_INIT_FRONT ;
    }
    else return SR_ERROR_INIT_FRONT ;

    // モジュールに初期化イベントを発行する
    if( pMMSE ) pEvent->PutEvent(NICT_MMSE, INITIALIZE, NULL) ;
    if( pMFCC ) pEvent->PutEvent(NICT_MFCC, INITIALIZE, NULL) ;
    if( pCMS )  pEvent->PutEvent(NICT_CMS, INITIALIZE, NULL) ;
    if( pVAD )  pEvent->PutEvent(NICT_VAD, INITIALIZE, NULL) ;

    // タイムスタンプ用出力フラグを設定する
    TimeStampFlag = TimeFlag ;
    // 使用メモリ出力フラグ
    UseMemoryFlag = UseMemory ;
    // 初期化済フラグ設定
    iniFlag = true ;
  }
  catch(...) {
    return SR_ERROR_SYSTEM;
  }
  return SR_SUCCESS ;
}

// 処理開始
int NICTSpeechRex::Start()
{
  // 初期化済？
  if( iniFlag == false ) return SR_FAILURE ;

  // 入力フォーマットを調べる
  if( inputFormatID == ID_FORMAT_FRAMESYNC ) return SR_SUCCESS ;

  // TOF及びSTARTイベントをキューに設定して処理を行う
  int stat = Execute( EV_TOF, NULL ) ;
  if( stat != -1 ) {
    stat = Execute( EPV_STARTPU, NULL ) ;
  }
  return (stat==-1) ? SR_ERROR_SYSTEM : SR_SUCCESS ;
}

// 終了
int NICTSpeechRex::End()
{
  // 初期化済？
  if( iniFlag == false ) return SR_FAILURE ;

  // 入力フォーマットを調べる
  if( inputFormatID == ID_FORMAT_FRAMESYNC ) return SR_SUCCESS ;

  // END及びEOFイベントをキューに設定して処理を行う
  int stat = Execute( EPV_ENDPU, NULL ) ;
  if( stat != -1 ) stat = Execute( EV_EOF, NULL ) ;

  return (stat==-1) ? SR_ERROR_SYSTEM : SR_SUCCESS ;
}

// 中断
int NICTSpeechRex::Cancel()
{
  // 初期化済？
  if( iniFlag == false ) return SR_FAILURE ;

  // ABORTイベントをキューに設定して処理を行う
  int stat = Execute( EV_ABORT, NULL ) ;

  return (stat==-1) ? SR_ERROR_SYSTEM : SR_SUCCESS ;
}

// 入力データ設定メソッド
int NICTSpeechRex::SetInputData( int size, char *data )
{
  int stat ;

  if( inputFormatID == ID_FORMAT_FRAMESYNC  ) {
    // 先頭の4バイトを見てデータタイプ決める
    int type = FrameSyncToEPV( ((int*)data)[0] ) ;
    stat = Execute( type, (unsigned char*)&data[4] ) ;
  }
  else {
    // データタイプは、EPV_DATA
    stat = Execute( EPV_DATA, (unsigned char*)data ) ;
  }
  return (stat==-1) ? SR_ERROR_SYSTEM : SR_SUCCESS ;
}

// 出力データ取得メソッド
int NICTSpeechRex::GetOutputData( int size, char *data, std::string& result )
{
  void            *ptr ;
  pair<int,void*> event ;

    if( outEvent.empty() ) return SR_EMPTY ;
    // データを取得してリストから削除する
    event = outEvent.front() ;
    outEvent.pop_front() ;
    // メモリクリア
    memset( data, 0, size ) ;
    // イベント構造体データを引数に設定する。
    if( outputFormatID == ID_FORMAT_FRAMESYNC ) {
      ((int*)data)[0] = EPVToFrameSync( event.first ) ;
      ptr = &data[4] ;
    }
    else ptr = data ;
    if( event.first == EPV_DATA ) {
      // 出力データの1データ当たりのサイズを調べて処理を分ける
      if( outputDataTypeID == DATA_TYPE_SHORT ) {
	intShortStar *ids = (intShortStar*)(event.second) ;
	memcpy( (int*)ptr, (int*)ids->ss, sizeof(int)*outputDataSize);
	free (ids->ss);
      }
      else if( outputDataTypeID == DATA_TYPE_FLOAT ) {
	intFloatStar *ids = (intFloatStar*)(event.second) ;
	memcpy( (float*)ptr, (float*)ids->fs, sizeof(float)*outputDataSize);
	free (ids->fs);
      }
      else if( outputDataTypeID == DATA_TYPE_DOUBLE ) {
	intDoubleStar *ids = (intDoubleStar*)(event.second) ;
	memcpy( (double*)ptr, (double*)ids->ds, sizeof(double)*outputDataSize);
	free (ids->ds);
      }

      free (event.second);
    }

  return SR_NOT_EMPTY ;
}


// 入力データパラメータ取得
int NICTSpeechRex::GetInputSize( int& size1, int& size2 )
{
  if( inputDataTypeID == DATA_TYPE_SHORT )       size1 = sizeof(short) ;
  else if( inputDataTypeID == DATA_TYPE_FLOAT )  size1 = sizeof(float) ;
  else if( inputDataTypeID == DATA_TYPE_DOUBLE ) size1 = sizeof(double) ;
  size2 = inputDataSize ;

  return 0 ;
}

// 出力データパラメータ取得
int NICTSpeechRex::GetOutputSize( int& size1, int& size2 )
{
  if( outputDataTypeID == DATA_TYPE_SHORT )       size1 = sizeof(short) ;
  else if( outputDataTypeID == DATA_TYPE_FLOAT )  size1 = sizeof(float) ;
  else if( outputDataTypeID == DATA_TYPE_DOUBLE ) size1 = sizeof(double) ;
  size2 = outputDataSize ;

  return 0 ;
}

// イベントループ処理
int NICTSpeechRex::Execute( int key, unsigned char *data )
{
  enum NICT_message_body	type ;
  EventNICT				*event ;

  try {
    // 指定データをイベント構造体にしてキューに設定する。
    PushEventData( key, data ) ;
    // イベントループ処理
    while(1)  {
      type = (NICT_message_body)pEvent->GetEvent( &event ) ;

      switch( type ) {
      case NICT_OFE:
      case NICT_MMSE:
      case NICTD_WAVE:
	if (pMMSE!=NULL) pMMSE->Execute( type, event ) ;
	break ;
      case NICT_MFCC:
      case NICTD_MARKED_WAVE:
	if( pMFCC ) pMFCC->Execute( type, event ) ;
	else        PushOutputData( event, "" ) ;
	break ;
      case NICT_CMS:
      case NICTD_CEP:
	if( pCMS ) pCMS->Execute( type, event ) ;
	else       PushOutputData( event, "" ) ;
	break ;
	


      case NICT_VAD:
	pVAD->Execute( type, event ) ;
	break;

      case NICTD_PARA:
	if( pVAD ) {
          pVAD->Execute( type, event ) ;
          break ;
        }
	/***************************************************
         * NOTICE: DO NOT PUT ANY CODE HERE!
         *         This case goes down into the case below.
	***************************************************/
      case NICTD_MARKED_PARA:
	PushOutputData( event, "" ) ;
	break ;

      default:
	return 0;
      }
    }
  } catch(...) {
    return -1;
  }
  return 0 ;
}

void NICTSpeechRex::PushEventData( int key, unsigned char *data )
{
  // message_bodyタイプは、DataTypeを使用する。
  switch(key) {
  case EV_TOF:
  case EV_EOF:
  case EPV_STARTPU:
  case EPV_ENDPU:
  case EV_ABORT:
    pEvent->PutEvent( DataType, key, NULL ) ;
    break ;
  case EPV_DATA:
    if( TimeStampFlag ) TIMESTAMP.SetInputTime() ;
    pEvent->PutEvent( DataType, key, (EventNICT*)ConvertEventData(key, data) ) ;
    break ;
  }
}

// データをイベント構造体にする
void* NICTSpeechRex::ConvertEventData( int key, unsigned char *data )
{
  if( inputDataTypeID == DATA_TYPE_SHORT ) {
    for( int i = 0 ; i < inputDataSize ; i++ ) {
      ((intShortStar*)inputData)->ss[i] = ((short*)data)[i] ;
    }
  }
  else if( inputDataTypeID == DATA_TYPE_FLOAT ) {
    for( int i = 0 ; i < inputDataSize ; i++ ) {
      ((intFloatStar*)inputData)->fs[i] = ((float*)data)[i] ;
    }
  }
  else if( inputDataTypeID == DATA_TYPE_DOUBLE ) {
    for( int i = 0 ; i < inputDataSize ; i++ ) {
      ((intDoubleStar*)inputData)->ds[i] = ((double*)data)[i] ;
    }
  }
  return inputData ;
}

// SprinTraに行く前に特徴量の並びを入れ替える
float* NICTSpeechRex::ConvertFeatureData( void *event )
{
  return paramData ;
}

// 出力データを蓄積する
void NICTSpeechRex::PushOutputData( EventNICT *event, std::string res )
{
  if( event != NULL ) {
    if( TimeStampFlag ) TIMESTAMP.SetOutputTime( event->message_type ) ;
    if( outputFormatID == ID_FORMAT_NOHEADER ) {
      // 出力フォーマットがNoHeaderの場合は、EPV_DATA以外は蓄積しない
      if( event->message_type != EPV_DATA ) return ;
    }

    int buf_message_type = (int)event->message_type;
    void *buf_message_body = NULL;
    if ( event->message_body != NULL ) {
      buf_message_body = ensure_buffer((void*)event->message_body);
      if ( buf_message_body == (void *)NULL ) {
	fprintf (stderr, "NICTSpeechRex::PushOutputData : memory allocation error.\n");
	return ;
      }
    }

    outEvent.push_back( pair<int, void*>((int)buf_message_type,(void*)buf_message_body) ) ;
  }
  else {
    if( TimeStampFlag ) TIMESTAMP.SetOutputTime() ;
    outString.push_back( res ) ;
  }
}

// データ格納領域を確保しデータをコピーする
void *NICTSpeechRex::ensure_buffer(void *targetBuffer) {
  void *tmpBuffer = NULL ;

  if( outputDataTypeID == DATA_TYPE_SHORT ) {
    tmpBuffer = malloc(sizeof(intShortStar));
    if( tmpBuffer == NULL ) return ((void*)NULL);
    int size = ((intShortStar*)targetBuffer)->i;
    ((intShortStar*)tmpBuffer)->i = size ;
    ((intShortStar*)tmpBuffer)->ss = (short*)malloc( sizeof(short) * size ) ;
    if( ((intShortStar*)tmpBuffer)->ss == NULL ) return ((void*)NULL) ;
    memcpy( (void *)&((intShortStar*)tmpBuffer)->ss[0], (void *)&((intShortStar*)targetBuffer)->ss[0], size*sizeof(short) );

  } else if( outputDataTypeID == DATA_TYPE_FLOAT ) {
    tmpBuffer = malloc(sizeof(intFloatStar));
    if( tmpBuffer == NULL ) return ((void*)NULL);
    int size = ((intFloatStar*)targetBuffer)->i;
    ((intFloatStar*)tmpBuffer)->i = size ;
    ((intFloatStar*)tmpBuffer)->fs = (float*)malloc( sizeof(float) * size ) ;
    if( ((intFloatStar*)tmpBuffer)->fs == NULL ) return ((void*)NULL) ;
    memcpy( (void *)&((intFloatStar*)tmpBuffer)->fs[0], (void *)&((intFloatStar*)targetBuffer)->fs[0], size*sizeof(float) );

  } else if( outputDataTypeID == DATA_TYPE_DOUBLE ) {
    tmpBuffer = (intDoubleStar*)malloc(sizeof(intDoubleStar));
    if( tmpBuffer == NULL ) return ((void*)NULL);
    int size = ((intDoubleStar*)targetBuffer)->i;
    ((intDoubleStar*)tmpBuffer)->i = size ;
    ((intDoubleStar*)tmpBuffer)->ds = (double*)malloc( sizeof(double) * size ) ;
    if( ((intDoubleStar*)tmpBuffer)->ds == NULL) return ((void*)NULL) ;
    memcpy( (void *)&((intDoubleStar*)tmpBuffer)->ds[0], (void *)&((intDoubleStar*)targetBuffer)->ds[0], size*sizeof(double) );
  }

  return ( tmpBuffer );
}

// EPV値をFrameSyncMark値に変換する
int NICTSpeechRex::EPVToFrameSync( int epv )
{
  if( epv == EPV_DATA ) return DATA_MARK ;
  else if( epv == EPV_STARTPU ) return START_MARK ;
  else if( epv == EPV_ENDPU ) return END_MARK ;
  else if( epv == EV_EOF ) return EOF_MARK ;
  else if( epv == EV_TOF ) return TOF_MARK ;
  return -1 ;
}

// FrameSyncMark値をEPV値に変換する
int NICTSpeechRex::FrameSyncToEPV( int mark )
{
  if( mark == DATA_MARK ) return EPV_DATA ;
  else if( mark == START_MARK ) return EPV_STARTPU ;
  else if( mark == END_MARK ) return EPV_ENDPU ;
  else if( mark == EOF_MARK ) return EV_EOF ;
  else if( mark == TOF_MARK ) return EV_TOF ;
  return -1 ;
}

// 発話数出力
void NICTSpeechRex::PrintUtteranceNumber()
{
  fprintf( stderr, "UTTERANCE = %d\n", ++UtteranceNumber ) ;
  fflush( stderr ) ;
}
