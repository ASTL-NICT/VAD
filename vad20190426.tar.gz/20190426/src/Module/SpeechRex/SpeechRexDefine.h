﻿/*------------------------------------------------------------------------------
// Speech Rex Define Header
//------------------------------------------------------------------------------
// Copyright (C) 2012 - 2016
//   National Institute of Information and Communications Technology.
//   All rights reserved.
//----------------------------------------------------------------------------*/

#ifndef _SPEECHREXDEFINE_H_
#define _SPEECHREXDEFINE_H_

// 戻り値定義
#define SR_SUCCESS                 0  //成功
#define SR_FAILURE                -1  //失敗
#define SR_ERROR_DIR              -2  //ライブラリインストールディレクトリ不正
#define SR_ERROR_SYSTEM           -3  //システムエラー
#define SR_ERROR_INIT             -4  //既に初期化済
#define SR_ERROR_CONF_FRONT       -5  //信号処理コンフィグエラー
#define SR_ERROR_INIT_FRONT       -6  //信号処理初期化エラー
//
#define SR_PARAM_SIZE             1600  //音声データサイズ
#define VECLENGTH                 25    // 次元数は固定

#endif
