﻿/*------------------------------------------------------------------------------
// NICT Speech Rex Define Header
//------------------------------------------------------------------------------
// Copyright (C) 2012 - 2016
// National Institute of Information and Communications Technology.
// All rights reserved.
//----------------------------------------------------------------------------*/

#ifndef _NICTSPEECHREXDEFINE_H_
#define _NICTSPEECHREXDEFINE_H_

#include <cstdio>
#include <string>

// 項目名定義
#define ITEM_INPUTFORMAT                "inputFormat="
#define ITEM_INPUTBYTEORDER             "inputByteOrder="
#define ITEM_OUTPUTFORMAT               "outputFormat="
#define ITEM_OUTPUTBYTEORDER            "outputByteOrder="
#define ITEM_INPUTFD                    "inputFd="
#define ITEM_OUTPUTFD                   "outputFd="
#define ITEM_SIGNALPROCESSINGCONFIGFILE "SignalProcessingConfigFile="
#define ITEM_TIMESTAMP                  "TimeStamp="
#define ITEM_USEMEMORY                  "UseMemory="
#define ITEM_DEBUG                      "debug="
#define ITEM_CONVERTFEATUREORDER        "convertFeatureOrder="
#define ITEM_MODULEROUTINGTABLE         "ModuleRoutingTable="

// モジュール名定義
#define MODULE_NICTMMSE                 "NICTmmse"
#define MODULE_NICTMFCC                 "NICTmfcc"
#define MODULE_NICTCMS                  "NICTcms"
#define MODULE_NICTVAD                  "NICTvad"
// ID(モジュール)定義
#define ID_MODULE_NICTMMSE              0
#define ID_MODULE_NICTMFCC              1
#define ID_MODULE_NICTCMS               2
#define ID_MODULE_NICTVAD               3

// フォーマット定義
#define FROMAT_FRAMESYNC                "FrameSync"
#define FROMAT_NOHEADER                 "NoHeader"
#define FROMAT_WAVFILE                  "WavFile"
#define FROMAT_WAVLIST                  "WavList"
#define FROMAT_ARGLIST                  "ArgList"
#define FROMAT_NHLIST                   "NHList"
#define FROMAT_ARGNHLIST                "ArgNHList"
// ID(フォーマット)定義
#define ID_FORMAT_FRAMESYNC             0
#define ID_FORMAT_NOHEADER              1
#define ID_FORMAT_WAVFILE               2

// エンディアン定義
#define ENDIAN_LITTLE                   "Little"
#define ENDIAN_BIG                      "Big"
// ID(エンディアン)定義
#define ID_ENDIAN_LITTLE                0
#define ID_ENDIAN_BIG                   1

// 戻り値定義(追加)
#define SR_NOT_EMPTY                    SR_SUCCESS
#define SR_EMPTY                        1

// データ型定義
#define DATA_TYPE_STRING                0
#define DATA_TYPE_SHORT                 1
#define DATA_TYPE_FLOAT                 2
#define DATA_TYPE_DOUBLE                3

#endif
