﻿/*------------------------------------------------------------------------------
// OptionsDB Access Library class
//------------------------------------------------------------------------------
// Copyright (C) 2011 - 2016
//   National Institute of Information and Communications Technology.
//   All rights reserved.
//----------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <iostream>

#include "NICToptions.h"
extern "C" {
#include "NICTutil.h"
}





// コンストラクタ
NICToptions::NICToptions()
{
    // 変数の初期化
    nowOptParseId = 0 ;
    iOptionCheckFlg = 0;
	fixoptions[0].optionflag = OPT_OptionsList ;
	fixoptions[0].name       = FIXoptOptionsList ;
	fixoptions[0].defvalue   = FIXoptDEFvalue ;
	fixoptions[1].optionflag = OPT_ConfigFile ;
	fixoptions[1].name       = FIXoptConfig ;
	fixoptions[1].defvalue   = FIXoptDEFvalue ;
	fixoptions[2].optionflag = OPT_Help ;
	fixoptions[2].name       = FIXoptHelp ;
	fixoptions[2].defvalue   = FIXoptDEFbool ;
	fixoptions[3].optionflag = OPT_Version ;
	fixoptions[3].name       = FIXoptVersion ;
	fixoptions[3].defvalue   = FIXoptDEFbool ;
	fixcount = 4 ;
}

// デストラクタ
NICToptions::~NICToptions()
{
}

/*
***
   オプションモジュールに、オプションの読み込みを依頼する関数。
   コマンドラインより固定のオプション( optionsList config help version )を
   まず取り込む。そして、この関数に渡している認識させたいオプションを、
   先の固定のオプションより得たファイルや、コマンドラインより読み込む。
***
*/
int NICToptions::ReadMainWithOptionNameCheck(int argc, char **argv, int *parseIdBox, const char *opt_grp, const char *cdo, int msgSw )
{
    int     i;
    int     opt_stat ;
    int     fix_stat ;
    int     optliststd = NoSTD ;
    int     configstd = NoSTD ;
    char    *optionslist = NULL ;
    char    *configfile = NULL ;
    FILE    *OptionsListFileStream = NULL ;
    FILE    *ConfigFileStream = NULL ;
    char    *progname ;
    char    *ret_ptr ;
    char    *def_opt = NULL ;

    /* BR: copy the cdo so that it will not be overwritten
     (so we can declare it as const)
     */
    if( cdo != NULL ) {
        i = strlen( cdo );
        def_opt = (char*)NICT_CALLOC( i + 2, sizeof(char));
        memcpy( def_opt, cdo, (i + 1) * (sizeof(char)) );
    }

    /*  コマンド名より、パスの部分を取り除く  */
	progname = argv[0] ;

	//Windows移植用追加
#ifndef _WIN32
	ret_ptr = strrchr( progname, (int)'/' ) ;
#else
	ret_ptr = strrchr( progname, (int)'\\' ) ;
#endif

	if( ret_ptr != NULL ) progname = ret_ptr +1 ;

	/*  オプションパースＩＤの更新チェック  */
	if( parseIdBox != NULL && *parseIdBox != 0 ) {
		nowOptParseId = *parseIdBox ;
	} else {
		nowOptParseId = 0 ;
	}

	/*  オプションモジュールが固定として持っているオプションを、コマンドラインについてチェックする。( optionsList config help version )  */
	fix_stat = fixOptParse( &nowOptParseId, opt_grp, argc, argv );
	if( fix_stat == OPT_FAILURE ) {
		fprintf( stderr, "NICToptions::ReadMain(): fixOptParse():\n" ) ;
		return( OPT_FAILURE ) ;
	}

	/*  どのオプションが設定されていたかのチェック  */
	if ( fix_stat &  OPT_Help ) {
		/*  Ｕｓａｇｅメッセージの出力  */
		if ( msgSw & OPT_PrintHelp ) {
			opt_stat = fixOptPrUsage( stderr, nowOptParseId, progname ) ;
		}
		return( fix_stat & ( OPT_PrintHelp + OPT_Version + OPT_SUCCESS ) ) ;
	}
	if ( fix_stat &  OPT_Version ) {
		return( fix_stat & ( OPT_PrintHelp + OPT_Version + OPT_SUCCESS ) ) ;
	}

	if ( fix_stat & OPT_ConfigFile ) {
		opt_stat = fixGetConfFile( nowOptParseId, &configfile );
		if ( configfile == NULL || !strlen(configfile) ) {
			fprintf( stderr, "Configuration file is not specified.\n" ) ;
			return( OPT_FAILURE | (fix_stat&0xFE) ) ;
		} else if ( !strcmp( configfile, "stdin" ) ) {
			ConfigFileStream = stdin ;
			configstd = YesSTD ;
		} else {
			ConfigFileStream = NULL ;
			configstd = YesSTD ;
		}
	}
	if ( fix_stat & OPT_OptionsList ) {
		opt_stat = fixGetOptFile( nowOptParseId, &optionslist );
		if ( optionslist == NULL ) {
			optionslist = (char *)"stdout" ;
			OptionsListFileStream = stdout ;
			optliststd = YesSTD ;
		} else if ( !strcmp( optionslist, "stdout" ) ) {
			OptionsListFileStream = stdout ;
			optliststd = YesSTD ;
		} else if ( !strcmp( optionslist, "stderr" ) ) {
			OptionsListFileStream = stderr ;
			optliststd = YesSTD ;
		} else {
			OptionsListFileStream = NULL ;
			optliststd = YesSTD ;
		}
	}

	/*  オプションモジュールに対して認識させたいオプションをセットする  */
	if ( def_opt != NULL ) {
		if ( !((SetDefOpts( &nowOptParseId, opt_grp, def_opt )) & OPT_SUCCESS) ) {
			fprintf( stderr, "NICToptions::ReadMain(): NICToptions::SetDefOpts():\n" ) ;
			return( OPT_FAILURE | (fix_stat&0xFE) ) ;
		}
	}

	/*  コマンドラインより読み取ったオプション設定ファイルをオープン。  */
	if ( configfile != NULL ) {
		if ( ConfigFileStream == NULL ) {
			ConfigFileStream = fopen( configfile, "r" ) ;
			if ( ConfigFileStream == NULL ) {
				fprintf( stderr, "NICToptions::ReadMain(): can not open the OptionsConfigFile : %s\n", configfile ) ;
				return( OPT_FAILURE | (fix_stat&0xFE) ) ;
			}
			configstd = NoSTD ;
		}
	}
	/*  先程設定したオプションを、オプション設定ファイルとコマンドラインより認識する。
	    オプションモジュールにオプション設定ファイルストリームをＮＵＬＬで渡せば、オプション設定ファイルを読まないで、
		コマンドラインだけをチェックする。また、ａｒｇｖがＮＵＬＬのときはコマンドラインをチェックしない。  */
	opt_stat = Parse( ConfigFileStream, &nowOptParseId, opt_grp, argc, argv );
	if ( configfile != NULL && configstd == NoSTD ) {
		fclose( ConfigFileStream ) ;
	}
	if ( !(opt_stat & OPT_SUCCESS) ) {
		fprintf( stderr, "NICToptions::ReadMain(): NICToptions::Parse():\n" ) ;
		return( OPT_FAILURE | (fix_stat&0xFE) ) ;
	}

	if(iOptionCheckFlg == 0) {
		iOptionCheckFlg = 1;
		if(checkAllOptionNames(configfile, argc, argv) != OPT_SUCCESS) {
			return( OPT_FAILURE | (fix_stat&0xFE) ) ;
		}
	}
	/*  オプションを読み込んだ後の各オプションの再設定値の出力  */
	if ( optionslist != NULL ) {
		if ( msgSw & OPT_PrintSetOptList || msgSw & OPT_PrintOptList ) {
			if ( OptionsListFileStream == NULL ) {
				OptionsListFileStream = fopen( optionslist, "a" ) ;
				if ( OptionsListFileStream == NULL ) {
					fprintf( stderr, "NICToptions::ReadMain(): can not open the OptionsListFile : %s\n", optionslist ) ;
					return( OPT_FAILURE | (fix_stat&0xFE) ) ;
				}
				optliststd = NoSTD ;
			}
			opt_stat = optPrOptsList( OptionsListFileStream, nowOptParseId, opt_grp, progname ) ;
			if ( optliststd == NoSTD ) {
				fclose( OptionsListFileStream ) ;
			}
			if ( opt_stat == OPT_FAILURE ) {
				fprintf( stderr, "NICToptions::ReadMain() : optPrOptsList():\n" ) ;
				return( OPT_FAILURE | (fix_stat&0xFE) ) ;
			}
		}
	}

	/*  デフォルト設定のままのオプションについて注意を促すメッセージを出力する。  */
	if ( msgSw & OPT_PrintDefWarn ) {
		opt_stat = optPrWarnUseDef( stderr, nowOptParseId, opt_grp, progname ) ;
		if ( opt_stat == OPT_FAILURE ) {
			fprintf( stderr, "NICToptions::ReadMain() : optPrWarnUseDef():\n" ) ;
			return( OPT_FAILURE  | (fix_stat&0xFE) ) ;
		}
	}

	// 注意 : オプションモジュールの関数群より受け取った
	// char * 型のデータは、使用後メモリー領域をフリーしてやる必要がある。
	if( configstd == NoSTD && configfile != NULL ) {
		free( configfile ) ;
	}
	if ( optliststd == NoSTD && optionslist != NULL ) {
		free( optionslist ) ;
	}

	/*  通常のアプリケーション側からの設定依頼オプションと、オプションモジュール
      固定のオプション、それぞれのパーズ済みデータへのアクセスＩＤを指定の変数に代入して返す。  */
	if ( parseIdBox ) {
		*parseIdBox = nowOptParseId ;
	}
	return( fix_stat ) ;
}

int NICToptions::ReadMain( int argc, char **argv, int *parseIdBox, const char *opt_grp, const char *cdo, int msgSw )
{
	int		i ;
	int     opt_stat ;
	int     fix_stat ;
	int     optliststd = NoSTD ;
	int     configstd = NoSTD ;
	char    *optionslist = NULL ;
	char    *configfile = NULL ;
	FILE    *OptionsListFileStream = NULL ;
	FILE    *ConfigFileStream = NULL ;
	char    *progname ;
	char    *ret_ptr ;
	char    *def_opt = NULL ;

	/* BR: copy the cdo so that it will not be overwritten
     (so we can declare it as const)
     */

	if ( cdo != NULL ) {
		i = strlen( cdo );
		def_opt = (char *) NICT_CALLOC( i + 2, sizeof(char));
		memcpy( def_opt, cdo, (i + 1) * (sizeof(char)) );
	}

	/*  コマンド名より、パスの部分を取り除く  */
	progname = argv[0] ;

	//Windows移植用追加
#ifndef _WIN32
	ret_ptr = strrchr( progname, (int)'/' ) ;
#else
	ret_ptr = strrchr( progname, (int)'\\' ) ;
#endif
	if ( ret_ptr != NULL ) progname = ret_ptr +1 ;

	/*  オプションパースＩＤの更新チェック  */
	if ( parseIdBox != NULL && *parseIdBox != 0 ) {
		nowOptParseId = *parseIdBox ;
	} else {
		nowOptParseId = 0 ;
	}


	// オプションモジュールが固定として持っているオプションを、コマンドラインについてチェックする。
    // ( optionsList config help version )
	fix_stat = fixOptParse( &nowOptParseId, opt_grp, argc, argv );
	if ( fix_stat == OPT_FAILURE ) {
		fprintf( stderr, "NICToptions::ReadMain(): fixOptParse():\n" ) ;
		return( OPT_FAILURE ) ;
	}
	

	// どのオプションが設定されていたかのチェック
	if ( fix_stat &  OPT_Help ) {
		/*  Ｕｓａｇｅメッセージの出力  */
		if ( msgSw & OPT_PrintHelp ) {
			opt_stat = fixOptPrUsage( stderr, nowOptParseId, progname ) ;
		}
		return( fix_stat & ( OPT_PrintHelp + OPT_Version + OPT_SUCCESS ) ) ;
	}
	if ( fix_stat &  OPT_Version ) {
		return( fix_stat & ( OPT_PrintHelp + OPT_Version + OPT_SUCCESS ) ) ;
	}
	if ( fix_stat & OPT_ConfigFile ) {
		opt_stat = fixGetConfFile( nowOptParseId, &configfile );
		if ( configfile == NULL || !strlen(configfile) ) {
			fprintf( stderr, "Configuration file is not specified.\n" ) ;
			return( OPT_FAILURE ) ;
		} else if ( !strcmp( configfile, "stdin" ) ) {
			ConfigFileStream = stdin ;
			configstd = YesSTD ;
		} else {
			ConfigFileStream = NULL ;
			configstd = YesSTD ;
		}
	}
	
	if ( fix_stat & OPT_OptionsList ) {
		opt_stat = fixGetOptFile( nowOptParseId, &optionslist );
		if ( optionslist == NULL ) {
			optionslist = (char *)"stdout" ;
			OptionsListFileStream = stdout ;
			optliststd = YesSTD ;
		} else if ( !strcmp( optionslist, "stdout" ) ) {
			OptionsListFileStream = stdout ;
			optliststd = YesSTD ;
		} else if ( !strcmp( optionslist, "stderr" ) ) {
			OptionsListFileStream = stderr ;
			optliststd = YesSTD ;
		} else {
			OptionsListFileStream = NULL ;
			optliststd = YesSTD ;
		}
	}

	// オプションモジュールに対して認識させたいオプションをセットする
	if( def_opt != NULL ) {
		if ( !((SetDefOpts( &nowOptParseId, opt_grp, def_opt )) & OPT_SUCCESS) ) {
			fprintf( stderr, "NICToptions::ReadMain(): NICToptions::SetDefOpts():\n" ) ;
			return( OPT_FAILURE ) ;
		}
	}
	

	// コマンドラインより読み取ったオプション設定ファイルをオープン。
	if ( configfile != NULL ) {
		if ( ConfigFileStream == NULL ) {
			ConfigFileStream = fopen( configfile, "r" ) ;
			if ( ConfigFileStream == NULL ) {
				fprintf( stderr, "NICToptions::ReadMain(): can not open the OptionsConfigFile : %s\n", configfile ) ;
				return( OPT_FAILURE ) ;
			}
			configstd = NoSTD ;
		}
	}
	

	// 先程設定したオプションを、オプション設定ファイルとコマンドラインより認識する。
	// オプションモジュールにオプション設定ファイルストリームをＮＵＬＬで渡せば、オプション設定ファイルを読まないで、
	// コマンドラインだけをチェックする。また、ａｒｇｖがＮＵＬＬのときはコマンドラインをチェックしない。
	opt_stat = Parse( ConfigFileStream, &nowOptParseId, opt_grp, argc, argv );
	if ( configfile != NULL && configstd == NoSTD ) {
		fclose( ConfigFileStream ) ;
	}
	if ( !(opt_stat & OPT_SUCCESS) ) {
		fprintf( stderr, "NICToptions::ReadMain(): NICToptions::Parse():\n" ) ;
		return( OPT_FAILURE ) ;
	}
	

	// オプションを読み込んだ後の各オプションの再設定値の出力
	if ( optionslist != NULL ) {
		if ( msgSw & OPT_PrintSetOptList || msgSw & OPT_PrintOptList ) {
			if ( OptionsListFileStream == NULL ) {
				OptionsListFileStream = fopen( optionslist, "a" ) ;
				if ( OptionsListFileStream == NULL ) {
					fprintf( stderr, "NICToptions::ReadMain(): can not open the OptionsListFile : %s\n", optionslist ) ;
					return( OPT_FAILURE ) ;
				}
				optliststd = NoSTD ;
			}
			opt_stat = optPrOptsList( OptionsListFileStream, nowOptParseId, opt_grp, progname ) ;
			if ( optliststd == NoSTD ) {
				fclose( OptionsListFileStream ) ;
			}
			if ( opt_stat == OPT_FAILURE ) {
				fprintf( stderr, "NICToptions::ReadMain() : optPrOptsList():\n" ) ;
				return( OPT_FAILURE ) ;
			}
		}
	}


	// デフォルト設定のままのオプションについて注意を促すメッセージを出力する。
	if ( msgSw & OPT_PrintDefWarn ) {
		opt_stat = optPrWarnUseDef( stderr, nowOptParseId, opt_grp, progname ) ;
		if ( opt_stat == OPT_FAILURE ) {
			fprintf( stderr, "NICToptions::ReadMain() : optPrWarnUseDef():\n" ) ;
			return( OPT_FAILURE ) ;
		}
	}


	// 注意 : オプションモジュールの関数群より受け取った
    // char * 型のデータは、使用後メモリー領域をフリーしてやる必要がある。
	if ( configstd == NoSTD && configfile != NULL ) {
		free( configfile ) ;
	}
	if ( optliststd == NoSTD && optionslist != NULL ) {
		free( optionslist ) ;
	}

	// 通常のアプリケーション側からの設定依頼オプションと、オプションモジュール
    // 固定のオプション、それぞれのパーズ済みデータへのアクセスＩＤを指定の変数に代入して返す。
	if ( parseIdBox ) {
		*parseIdBox = nowOptParseId ;
	}
	return( fix_stat ) ;
}

// このモジュールが、固定のオプションとして読み込みたいものを、コマンドラインより読み込む。
//		fixed options (-help -config -optionsList -version )
//リターン値の”OPT_FAILURE == 0, OPT_SUCCESS == 1”のスイッチの為のマスク
int NICToptions::fixOptParse( int *fixParseId, const char *grpName, int argc, char **argv )
{
	int		opt_stat;
	int     cnt;
	int     ret_stat;
	char    *optvaluebox ;

	/*  argvからのfix optionsの取り込み  */
	if ( argc && argv != NULL ) {
		opt_stat = Parse( (FILE *)NULL, fixParseId, grpName, argc, argv );
		if ( !(opt_stat & OPT_SUCCESS) ) {
			return( OPT_FAILURE ) ;
		}
	}
	/*  オプションの読み込み状況のチェック  */
	ret_stat = OPT_SUCCESS ;
	for ( cnt=0; cnt < fixcount ; cnt++ ) {
		optvaluebox = NULL ;
		opt_stat = GetOptValue( *fixParseId, fixoptions[ cnt ].name, &optvaluebox ) ;
		if ( opt_stat == OPT_SUCCESS ) {
			ret_stat |= fixoptions[ cnt ].optionflag ;
		}
		if ( optvaluebox != NULL ) {
			free( optvaluebox ) ;
		}
	}
	return( ret_stat ) ;
}

// 簡単なオプション設定についてのコメントを出力する。
int NICToptions::fixOptPrUsage( FILE *usage_stream, int fixParseId, char *progname )
{
	/*  オプションの固定のusageメッセージ  */
	const static char *fix_usage_str = "\
Options can be specified using a configuration file or on the command line. \n\
To specify options using a configuration file, do the following : \n\
COMMAND -OptionsList=path/filename \n\
    There are NO SPACES around the =. \n\
    This will write a list of all options into the path/filename. \n\
Edit the path/filename to set the options as you like, and then run COMMAND as: \n\
COMMAND -config=path/filename \n\
COMMAND -help \n\
    Prints out a brief description of the usage, on stderr. \n\
COMMAND -version \n\
    Prints out a number of the version, on stderr. \n\
COMMAND -config=cfile -OptionsList=oFile [-[optionGroupName:]option[=value[,value2,value3...]]]... ... \n\
    If OptionsList is not the only argument on the command line, \n\
    it will print the options' values on path/outputFile as they \n\
    are used at runtime, and will not exit. \n\
" ;

	fprintf(usage_stream, "Usage :: %s : [COMMAND == %s]\n", progname, progname);
	fputs( fix_usage_str, usage_stream ) ;
	putc('\n', usage_stream);
	fflush( usage_stream ) ;

	return( OPT_SUCCESS ) ;
}

// オプションを設定する為に読み込むファイルの名前を調べる。
int NICToptions::fixGetOptFile( int fixParseId, char **filenamebox )
{
	if( !fixParseId ) {
		*filenamebox = NULL ;
		return( OPT_FAILURE ) ;
	}

	if ( GetOptValue( fixParseId, fixoptions[ NUMBER_OptionsList ].name, filenamebox ) == OPT_FAILURE ) {
		return( OPT_FAILURE ) ;
	}
	return( OPT_SUCCESS ) ;
}

// オプションを設定する為のファイルのサンプルを出力するファイルの名前を調べる。
int NICToptions::fixGetConfFile( int fixParseId, char **filenamebox )
{
	if ( ! fixParseId ) {
		*filenamebox = NULL ;
		return( OPT_FAILURE ) ;
	}

	if ( GetOptValue( fixParseId, fixoptions[ NUMBER_ConfigFile ].name, filenamebox ) == OPT_FAILURE ) {
		return( OPT_FAILURE ) ;
	}
	return( OPT_SUCCESS ) ;
}

// 外部からのオプション設定読み込み後のオプションリストを出力する。
int NICToptions::optPrOptsList( FILE *opStream, int optParseId, const char *grpName, char *progName )
{
	char  **namelist ;
	char  **freepoint ;
	char  *value ;
	const char  *pr_grpname ;
	int   cnt ;
	int   skip ;

	if ( grpName != NULL && *grpName != '\0' ) {
		pr_grpname = grpName ;
	} else {
		pr_grpname = " " ;
	}

	if ( OptsNameList( optParseId, &namelist ) == OPT_FAILURE ) {
		return( OPT_FAILURE ) ;
	}

	/* fprintf( opStream, "\n# make use of this options list : %s : %s : %s", progName, pr_grpname, timeStamp() ); */
	fprintf( opStream, "\n#%s config : %s", pr_grpname, timeStamp() );

	freepoint = namelist ;
	for ( ; namelist != NULL && *namelist != NULL ; namelist ++ ) {
		/* skip print meta options */
		for ( skip=cnt=0; cnt < fixcount ; cnt++ ) {
			/* fixcount & fixoptions use fixOptParse() */
			if ( !strcasecmp( fixoptions[ cnt ].name, *namelist ) ) {
				skip = 1 ;
				break ;
			}
		}
		if ( skip ) {
			free( *namelist ) ;
			continue ;
		}

		fprintf( opStream, "\t" ) ;
		if ( grpName != NULL && *grpName != '\0' ) {
			fprintf( opStream, "%s:", grpName ) ;
		}
		GetOptValue( optParseId, *namelist, &value ) ;
		if ( value == NULL ) {
			fprintf( opStream, "%s\n", *namelist ) ;
		} else {
			fprintf( opStream, "%s=%s\n", *namelist, value ) ;
			free( value ) ;
		}
		free( *namelist ) ;
	}
	free( freepoint ) ;

	/* fprintf( opStream, "\n# --- make use of this options list : %s : END ---\n\n", pr_grpname ); */
	fflush( opStream ) ;

	return( OPT_SUCCESS ) ;
}

// デフォルト設定のまま使用しようとしているオプションについて注意を促すメッセージを出力する。
int NICToptions::optPrWarnUseDef( FILE *opStream, int optParseId, const char *grpName, const char *progName )
{
	char  **namelist ;
	char  **freepoint ;
	const char  *pr_grpname ;
	int   prtsw ;

	if ( grpName != NULL && *grpName != '\0' ) {
		pr_grpname = grpName ;
	} else {
		pr_grpname = " " ;
	}

	if ( OptsNameList( optParseId, &namelist ) == OPT_FAILURE ) {
		return( OPT_FAILURE ) ;
	}

	freepoint = namelist ;
	prtsw = 0 ;
	for ( ; namelist != NULL && *namelist != NULL ; free( *namelist ), namelist ++ ) {
		if ( CheckReadAlready( optParseId, *namelist ) >= OPT_FAILURE ) {
			/* (NICToptions::CheckReadAlready() < OPT_FAILURE) == Use Default option */
			continue ;
		}
		if ( !prtsw ) {
			fprintf( opStream, "\n\nwarning! use default options? : %s : %s : %s", progName, pr_grpname, timeStamp() );
			prtsw = 1 ;
		}

		fprintf( opStream, "\t" ) ;
		if ( grpName != NULL && *grpName != '\0' ) {
			fprintf( opStream, "%s:", grpName ) ;
		}
		fprintf( opStream, "%s", *namelist ) ;
		fprintf( opStream, "\n" );
	}
	free( freepoint ) ;

	if ( prtsw ) {
		fprintf( opStream, "<--- warning! default options : %s : END ---:\n\n", pr_grpname ) ;
		fflush( opStream ) ;
	}
	return( OPT_SUCCESS ) ;
}

// time stamp
char *NICToptions::timeStamp( void )
{
	static char   def_str[] = "??? ??? ?? ??:??:?? ????" ;
	time_t        timedata ;
	char          *tstamp ;

	/*  get the time */
	if ( time( &timedata ) != -1 ) {
		tstamp = ctime( &timedata ) ;
	} else {
		tstamp = def_str ;
	}
	return( tstamp ) ;
}


// 指定のオプションセットから、Booleanタイプとしてオプションが設定されているか調べる。
int NICToptions::optGetBool( int optionsPaseId, const char *optionName, int *optionValueBox )
{
	char    *string;

	/* search the given string on the options */
	if ( GetOptValue( optionsPaseId, optionName, &string ) == OPT_FAILURE ) {
          return( OPT_FAILURE );
	}
	if ( string == NULL ) {
		GetOptDefValue( optionsPaseId, optionName, &string ) ;
		*optionValueBox = OPT_FAILURE ;
		if ( string != NULL ) {
			if (! local_strcmp(string, OPT_ON)) ;
			else if (! local_strcmp(string, OPT_TRUE)) ;
			else if (! local_strcmp(string, OPT_1)) ;
			else {
				*optionValueBox = OPT_SUCCESS ;
				if (! local_strcmp(string, OPT_OFF)) ;
				else if (! local_strcmp(string, OPT_FALSE)) ;
				else if (! local_strcmp(string, OPT_0)) ;
				else {
					return( OPT_FAILURE ) ;
				}
			}
		}
	} else {
		*optionValueBox = OPT_SUCCESS ;
		if (! local_strcmp(string, OPT_ON)) ;
		else if (! local_strcmp(string, OPT_TRUE)) ;
		else if (! local_strcmp(string, OPT_1)) ;
		else {
			*optionValueBox = OPT_FAILURE ;
			if (! local_strcmp(string, OPT_OFF)) ;
			else if (! local_strcmp(string, OPT_FALSE)) ;
			else if (! local_strcmp(string, OPT_0)) ;
			else {
				return( OPT_FAILURE ) ;
			}
		}
	}
	if ( string != NULL ) {
		free( string ) ;
	}
	return( OPT_SUCCESS ) ;
}

// 指定のオプションセットから、Integerタイプのオプションの設定値を取り出す。
int NICToptions::optGetInt( int optionsPaseId, const char *optionName, int *optionValueBox )
{
	char    *string;
	char    *nullchk;

	/* search the given string on the options */
	if ( GetOptValue( optionsPaseId, optionName, &string ) == OPT_FAILURE ) {
        return( OPT_FAILURE );
	}
	if ( string == NULL ) {
        fprintf( stderr, "NICToptions::optGetInt() : I know about this option but I can not get its value.  optionName = %s\n", optionName );
		return( OPT_FAILURE );        /* not found */
	}

	*optionValueBox = (int) strtol( string, &nullchk, 0 ) ;

	if ( *nullchk != '\0' ) {
        fprintf( stderr, "NICToptions::optGetInt() : You asked me to get an int but this is not an int.  optionValueBox = %s\n", string );
		free( string ) ;
		return( OPT_FAILURE );        /* not integer */
	}

	free( string ) ;
	return( OPT_SUCCESS ) ;
}

// 指定のオプションセットから、Doubleタイプのオプションの設定値を取り出す。
int NICToptions::optGetDouble( int optionsPaseId, const char *optionName, double *optionValueBox )
{
	char    *string;
	char    *nullchk;

	/* search the given string on the options */
	if ( GetOptValue( optionsPaseId, optionName, &string ) == OPT_FAILURE ) {
        return( OPT_FAILURE );
	}
	if ( string == NULL ) {
		fprintf( stderr, "NICToptions::optGetDouble() : I know about this option but I can not get its value.  optionName = %s\n", optionName );
		return( OPT_FAILURE );        /* not found */
	}

	*optionValueBox = strtod( string, &nullchk ) ;

	if ( *nullchk != '\0' ) {
        fprintf( stderr, "NICToptions::optGetDouble() : You asked me to get an double but this is not an double.  optionValueBox = %s\n", string );
		free( string ) ;
		return( OPT_FAILURE );        /* not double */
	}

	free( string ) ;
	return( OPT_SUCCESS ) ;
}

// Idで指定したオプションセットの中のあるオプションのメンバーとして、指定のメンバーが与えられたかを調べる。
int NICToptions::optIsMember( int optionsPaseId, const char *optionName, char *checkMember, const char *punctuation )
{
	char    *string;
	int     ret_sts ;

	/* search the given string on the options */
	if ( GetOptValue( optionsPaseId, optionName, &string ) == OPT_FAILURE ) {
		return( OPT_FAILURE );
	}
	if ( string == NULL ) {
        fprintf( stderr, "NICToptions::optIsMember() : I know about this option but I can not get its value.  optionName = %s\n", optionName );
		return( OPT_FAILURE );        /* not found */
	}

	if ( punctuation == NULL ) {
	  punctuation = " " ;
	}
	ret_sts = MemberChkMember( checkMember, punctuation, string, punctuation ) ;
	free( string ) ;
	return( ret_sts ) ;
}

int NICToptions::local_strcmp( const char *str_left, const char *str_right )
{
        return( strcasecmp( str_left, str_right ) );
}

/*
 * -----------------------------------------
        strFindCombine

	与えられた文字列”string”が句切り文字で結合された文字列集合である
	”combine_string”に含まれるかどうかをチェックする。
	文字列集合の例："pow+cep+dcep" "123,456,789"など。
 * ----------------------------------------- */
char *NICToptions::local_strtok( char * org_str, const char * delim, char ** next_point )
{
	char  *spanp;
	char  *tok;
	int   top_c;
	int   span_c;
	int   loop_on ;

	if (org_str == NULL) {
		return (NULL);
	}

	/*
	* Skip (span) leading delimiters
	*/
	for (loop_on = 1; loop_on;) {
		loop_on = 0;
		top_c = *org_str++;
		for (spanp = (char *)delim; (span_c = *spanp++) != 0;) {
			if (top_c == span_c) {
				loop_on = 1 ;
				break ;
			}
		}
	}

	if (top_c == 0) {	/* no non-delimiter characters */
		*next_point = NULL;
		return (NULL);
	}
	tok = org_str - 1;

	/*
	* Scan token
	*/
	while ( 1 ) {
		top_c = *org_str++;
		spanp = (char *)delim;
		do {
			if ((span_c = *spanp++) == top_c) {
				if (top_c == 0) {
					org_str = NULL;
				} else {
					org_str[-1] = 0;
				}
				*next_point = org_str;
				return (tok);
			}
		} while (span_c != 0);
	}
}

int NICToptions::strFindCombine( char *string, const char *combine_string, const char *tokensep )
{
	char    * token ;
	char    * tok_str ;
	char    * top_ptr ;
	int     ret_stat = OPT_FAILURE ;

	if ((top_ptr = tok_str = (char *)NICT_CALLOC( strlen( combine_string ) +1, sizeof( char ))) == NULL) {
		fprintf( stderr, "NICToptions::strFindCombine():\n" ) ;
		return( ret_stat ) ;
	} else {
		strcpy( tok_str, combine_string );
	}

	token = local_strtok( tok_str, tokensep, &tok_str ) ;
	while ( token != NULL ) {
		if ( ! local_strcmp( string, token ) ) {
			ret_stat = OPT_SUCCESS ;
			break ;
		}
		token = local_strtok( tok_str, tokensep, &tok_str ) ;
	}
	free( top_ptr ) ;
	return( ret_stat ) ;
}

/*
 * -----------------------------------------
        MemberChkMember

	与えられた文字列”combleft””combright”の比較。
	”combleft””combright”は、句切り文字で結合された文字列集合である。
	”punctleft” ”punctright” は、各々の句切り文字のストリング。
	標準関数 strtok() での句切り文字と同じ。
	例："pow+cep+dcep" "123,456,789"など。
	”combleft”が”combright”の文字列の集合に含まれるかどうかをチェックする。
 * ----------------------------------------- */
int NICToptions::MemberChkMember( char *comb1, const char *punctleft, char *comb2, const char *punctright )
{
	char            * combleft = comb1 ;
	char            * combright = comb2 ;
	int             ret_sts ;
	char            * token ;
	char            * free_point ;

	if ( combleft == NULL || combright == NULL ) {
		return( OPT_FAILURE ) ;
	}

	if ( punctleft == NULL && punctright == NULL ) {
		if ( ! local_strcmp( combleft, combright ) ) {
			ret_sts = OPT_SUCCESS ;
		} else {
			ret_sts = OPT_FAILURE ;
		}

	} else if ( punctleft && punctright ) {
		if ((free_point = combleft = (char *)NICT_CALLOC( strlen( comb1 ) +1, sizeof( char ))) == NULL) {
			fprintf( stderr, "NICToptions::MemberChkMember() :\n" ) ;
			return( OPT_FAILURE ) ;
		} else {
			strcpy( combleft, comb1 );
		}

		ret_sts = OPT_FAILURE ;
		token = local_strtok( combleft, punctleft, &combleft ) ;
		while ( token != NULL ) {
			ret_sts = strFindCombine( token, combright, punctright ) ;
			if ( ret_sts == OPT_FAILURE ) {
				break ;
			}
			token = local_strtok( combleft, punctleft, &combleft ) ;
		}
		free( free_point ) ;

	} else if ( punctleft == NULL && punctright ) {
		ret_sts = strFindCombine( combleft, combright, punctright ) ;

	} else {
		ret_sts = OPT_FAILURE ;
	}
	return( ret_sts ) ;
}
