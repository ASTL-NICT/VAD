﻿/*-----------------------------------------------------------------------------
 DELTA class
-------------------------------------------------------------------------------
 Copyright (C) 2012 - 2016
   National Institute of Information and Communications Technology.
   All rights reserved.
-----------------------------------------------------------------------------*/

#include<NICTdelta.h>

using namespace std;

// 時間微分特徴量計算クラスのメンバ関数定義

// 時間微分特徴量の計算関数

void DELTA::calc_delta(void){
  vector <double> delta;
  for(int d=0;d<VecLen;d++){
    double nom=0.0;
    for(int t=1;t<=DeltaWinLen;t++)
      nom+=(double)t*(ParvecBuf[t][d]-ParvecBuf[-t][d]);
    delta.push_back(nom/Denom);
  }
  DeltaBuf.push_back(delta);
  return;
}

// コンストラクタとディストラクタ関数

DELTA::DELTA(int veclen,int deltawinlen){
  VecLen     =veclen;
  DeltaWinLen=deltawinlen;
  ParvecBuf=new double * [DeltaWinLen+1+DeltaWinLen];
  ParvecBuf+=DeltaWinLen;
  for(int t=-DeltaWinLen;t<=DeltaWinLen;t++){
    ParvecBuf[t]=new double [VecLen];
    for(int d=0;d<VecLen;d++)ParvecBuf[t][d]=0.0;
  }
  ParvecNum=-1;
  Denom=0.0;
  for(int t=1;t<=DeltaWinLen;t++)Denom+=(double)t*(double)t;
  Denom*=2.0;
}

DELTA::~DELTA(void){
  for(int t=-DeltaWinLen;t<=DeltaWinLen;t++)delete [] ParvecBuf[t];
  ParvecBuf-=DeltaWinLen;
  delete [] ParvecBuf;
}

// 計算条件の取得関数

int DELTA::get_veclen(void) const{
  return(VecLen);
}

int DELTA::get_deltawinlen(void) const{
  return(DeltaWinLen);
}

// 初期化関数

void DELTA::clear(void){
  for(int t=-DeltaWinLen;t<=DeltaWinLen;t++){
    for(int d=0;d<VecLen;d++)ParvecBuf[t][d]=0.0;
  }
  ParvecNum=-1;
  return;
}

// 特徴ベクトルの入力関数

void DELTA::in(const vector <double> & parvec){

  // 時間微分計算用バッファへの特徴ベクトルの追加

  if(ParvecNum==-1){
    for(int t=-DeltaWinLen;t<0;t++){
      for(int d=0;d<VecLen;d++)ParvecBuf[t][d]=parvec[d];
    }
  }else if(ParvecNum==DeltaWinLen){
    double * tmp=ParvecBuf[-DeltaWinLen];
    for(int t=-DeltaWinLen;t<DeltaWinLen;t++)ParvecBuf[t]=ParvecBuf[t+1];
    ParvecBuf[DeltaWinLen]=tmp;
    ParvecNum--;
  }
  ParvecNum++;
  for(int d=0;d<VecLen;d++)ParvecBuf[ParvecNum][d]=parvec[d];

  // 時間微分特徴量の計算

  if(ParvecNum==DeltaWinLen)calc_delta();

  return;
}

// 特徴ベクトルの入力終了関数

void DELTA::flush(void){
  vector <double> parvec;
  for(int d=0;d<VecLen;d++)parvec.push_back(ParvecBuf[ParvecNum][d]);
  for(int t=0;t<DeltaWinLen;t++)in(parvec);
  return;
}

// 時間微分特徴量の取得関数

int DELTA::outnum(void) const{
  return(DeltaBuf.size());
}

vector <double> DELTA::out(void){
  vector <double> ret=DeltaBuf[0];
  DeltaBuf.erase(DeltaBuf.begin());
  return(ret);
}
