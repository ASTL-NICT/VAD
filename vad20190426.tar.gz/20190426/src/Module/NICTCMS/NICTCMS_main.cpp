﻿/*------------------------------------------------------------------------------
// CMS によるチャネル特性補正プログラム   NICTCMS_main.cpp
//------------------------------------------------------------------------------
// Copyright (C) 2012 - 2016
//   National Institute of Information and Communications Technology.
//   All rights reserved.
//----------------------------------------------------------------------------*/

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>

#include "NICTcms.h"
#include "fsync.h"


using namespace std;


NICTcms::NICTcms()
{
  pEvent       = NULL ;
  pOption      = NULL ;
  pccmsOptions  = NULL ;
  options_id   = 0 ;
  pCms_1pass   = NULL;
  pCms_2pass   = NULL;
  pCms_online  = NULL;
  pCms_average = NULL;
  pCms         = NULL;

  EventTbl.clear() ;
}

NICTcms::NICTcms(NICTevent2 *event, NICToptions *option)
{
  pEvent       = event ;
  pOption      = option ;
  pccmsOptions  = NULL ;
  options_id   = 0 ;
  pCms_1pass   = NULL;
  pCms_2pass   = NULL;
  pCms_online  = NULL;
  pCms_average = NULL;
  pCms         = NULL;

  EventTbl.clear() ;
}

NICTcms::~NICTcms()
{
  // LocalEvent領域を解放する
  if( !EventTbl.empty() ) {
    intFloatStar *ptr ;
    int size = EventTbl.size() ;
    for( int i = 0 ; i < size ; i++ ) {
      ptr = EventTbl[i] ;
      if( ptr->fs ) free( ptr->fs ) ;
      free( ptr ) ;
    }
  }
}

int NICTcms::Initialize( int argn, char *argv[] )
{
  int     iRetVal;
  char*   optionvaluebox = NULL;

  /* ---------- options envelop start ---------- */
	



  const char default_options[] = "\
    CepstrumOrder=12\n\
    Parameter=pow+cep+dpow+dcep\n\
    CMSType=2pass\n\
    AttRate=0.9\n\
    InitMean=\n\
    Delay=90\n\
    AverageFrames=0\n\
    ";




  /*  Get Options  */
  iRetVal = pOption->ReadMain( argn, argv, &options_id, NICT_CMS_STR,
			       default_options, OPT_PrintOptList |OPT_PrintSetOptList );

  if( iRetVal == OPT_FAILURE ) {
    fprintf( stderr, "@NICTcms ERROR: Invalid argument.\n" );
    return( 1 );
  }

  /****  parse options  ****/

  ccmsOptions.CepstrumOrder = 20;
  ccmsOptions.Parameter = "pow+cep+dpow+dcep";   	

  ccmsOptions.CMSType = "2pass";
  ccmsOptions.AttRate = 0.9;
  ccmsOptions.InitMean = "";
  ccmsOptions.Delay = 90;
  ccmsOptions.AverageFrames=0;

  pccmsOptions = &ccmsOptions;


  /* CepstrumOrder */
  iRetVal = pOption->GetOptValue( options_id, "CepstrumOrder", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTcms_init: OPTIONLIB error in CepstrumOrder\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTcms_init ERROR : OPTION CepstrumOrder is not setting.\n" ) ;
    return( 1 );
  }
  pccmsOptions->CepstrumOrder = atoi(optionvaluebox);

  if( pccmsOptions->CepstrumOrder <= 0 ) {
    fprintf( stderr,  "@NICTcms_init ERROR : OPTION CepstrumOrder is out of range.\n" ) ;
    return( 1 );
  }
  free( optionvaluebox );



  /* Parameter */
  iRetVal = pOption->GetOptValue( options_id, "Parameter", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTcms_init: OPTIONLIB error in Parameter\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTcms_init ERROR : OPTION Parameter is not setting.\n" ) ;
    return( 1 );
  }

  pccmsOptions->Parameter = (string)optionvaluebox;

  char *buf;
  buf = new char[pccmsOptions->Parameter.size()+1];

  strcpy(buf , pccmsOptions->Parameter.c_str());


  for(char * token = strtok(buf,"+") ; token ; token = strtok(NULL,"+")){
    string tmp = (string)token;
    if(tmp != "cep" && tmp != "dcep" && tmp != "ddcep" &&
       tmp != "c0"  && tmp != "dc0"  && tmp != "ddc0" &&
       tmp != "pow" && tmp != "dpow" && tmp != "ddpow") {
      fprintf( stderr,  "@NICTcms_init ERROR : OPTION Parameter are different\n" ) ;
      return( 1 );
    }
    kind.push_back(tmp);
  }


      	
  free( optionvaluebox );
  delete [] buf;


  /* CMSType */
  iRetVal = pOption->GetOptValue( options_id, "CMSType", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTcms_init: OPTIONLIB error in CMSType\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTcms_init ERROR : OPTION CMSType is not setting.\n" ) ;
    return( 1 );
  }

  pccmsOptions->CMSType = (string)optionvaluebox;

  if ( pccmsOptions->CMSType != "1pass" &&
       pccmsOptions->CMSType != "2pass" &&
       pccmsOptions->CMSType != "online" &&
       pccmsOptions->CMSType != "average") {
    fprintf( stderr,  "@NICTcms_init ERROR : OPTION CMSType are different\n" ) ;
    return( 1 );
  }

  free( optionvaluebox );


  /* AttRate;  */
  iRetVal = pOption->GetOptValue( options_id, "AttRate", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTcms_init: OPTIONLIB error in AttRate\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTcms_init ERROR : OPTION AttRate is not setting.\n" ) ;
    return( 1 );
  }
  pccmsOptions->AttRate= atof(optionvaluebox);

  if( pccmsOptions->AttRate < 0.0 || pccmsOptions->AttRate > 1.0 ) {
    fprintf( stderr,  "@NICTcms_init ERROR : OPTION AttRate is out of range.\n" ) ;
    return( 1 );
  }

  free( optionvaluebox );


  /* InitMean */
  iRetVal = pOption->GetOptValue( options_id, "InitMean", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTcms_init: OPTIONLIB error in InitMean\n" );
    return( 1 );
  }

  if ( pccmsOptions->CMSType == "online") {
    if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
      fprintf( stderr,  "@NICTcms_init ERROR : OPTION InitMean is not setting.\n" ) ;
      return( 1 );
    }

    pccmsOptions->InitMean = (string)optionvaluebox;
  }
	
  free( optionvaluebox );

   	
  /* Delay */
  iRetVal = pOption->GetOptValue( options_id, "Delay", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTcms_init: OPTIONLIB error in Delay\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTcms_init ERROR : OPTION Delay is not setting.\n" ) ;
    return( 1 );
  }
  pccmsOptions->Delay = atoi(optionvaluebox);

  if( pccmsOptions->Delay < 0 ) {
    fprintf( stderr,  "@NICTcms_init ERROR : OPTION Delay is out of range.\n" ) ;
    return( 1 );
  }
  free( optionvaluebox );

  /* AverageFrames */
  iRetVal = pOption->GetOptValue( options_id, "AverageFrames", &optionvaluebox );
  if( iRetVal != OPT_SUCCESS ) {
    fprintf( stderr, "NICTcms_init: OPTIONLIB error in AverageFrames\n" );
    return( 1 );
  }
  if( !optionvaluebox || strlen(optionvaluebox) == 0 ) {
    fprintf( stderr,  "@NICTcms_init ERROR : OPTION AverageFrames is not setting.\n" ) ;
    return( 1 );
  }
  pccmsOptions->AverageFrames = atoi(optionvaluebox);

  if( pccmsOptions->AverageFrames < 0 ) {
    fprintf( stderr,  "@NICTcms_init ERROR : OPTION AverageFrames is out of range.\n" ) ;
    return( 1 );
  }
  free( optionvaluebox );


  // 次元数の設定

  veclen = 0;
  for(int n = 0 ; n < (int)kind.size() ; n++){
    if(kind[n] == "cep" || kind[n] == "dcep" || kind[n] == "ddcep"){
      veclen += pccmsOptions->CepstrumOrder;
    }
    else if(kind[n] == "c0" || kind[n] == "dc0" || kind[n] == "ddc0" || kind[n] == "pow" || kind[n] == "dpow" || kind[n] == "ddpow"){
      veclen++;
    }
  }



  if(pccmsOptions->CMSType == "1pass" ){
    pCms_1pass = new CMS_1PASS(pccmsOptions->CepstrumOrder,kind,pccmsOptions->AttRate);
    pCms = pCms_1pass;
  }
  else if(pccmsOptions->CMSType == "average" ){
    pCms_average = new CMS_AVERAGE(pccmsOptions->CepstrumOrder,kind,pccmsOptions->AverageFrames);
    pCms = pCms_average;
  }
  else if( pccmsOptions->CMSType == "2pass" ){
    pCms_2pass = new CMS_2PASS(pccmsOptions->CepstrumOrder,kind);
    pCms = pCms_2pass;
  }
  else if( pccmsOptions->CMSType == "online" ){

    // 初期平均ケプストラムファイルの読み込み
    vector <double> initcepmean;

    FILE * fp = fopen( pccmsOptions->InitMean.c_str(),"r" );
    if( fp == NULL ) {
      fprintf( stderr,  "@NICTcms_init ERROR : OPTION InitMean is file open error.\n" ) ;
      return( 1 );
    }

    while( true ) {
      string str = readline(fp);
      if( feof(fp)!=0 ) break;
	
      str.erase( str.size() - 1 );
      char *buf;
      buf = new char[str.size() + 1];
		
      strcpy( buf , str.c_str() );
	
      for( char * token = strtok(buf," \t\r\n") ; token ; token = strtok(NULL," \t\r\n"))   initcepmean.push_back(atof(token));

      delete [] buf;
    }

    fclose( fp );

    if (initcepmean.size()!=(unsigned int)veclen) {
      fprintf( stderr,  "@NICTcms_init ERROR : Meanfile vecsize error (InitMean_file_vec.size()=%ld,Feats[i].vec.size()=%d\n",initcepmean.size(),veclen);
      return 1;
    }

    pCms_online = new CMS_ONLINE(pccmsOptions->CepstrumOrder,kind,initcepmean,pccmsOptions->Delay);
    pCms = pCms_online;

  }

  // intFloatStarを200個作成して置く
  EventUseIndex = 0 ;
  for( int i = 0 ; i < 200 ; i++ ) {
    if( GetLocalEvent() == NULL ) return 1 ;
  }
  return 0;
}


void NICTcms::Terminate( int arg )
{

  if( pCms_1pass ) delete ( pCms_1pass );
  if( pCms_2pass ) delete ( pCms_2pass );
  if( pCms_online ) delete ( pCms_online );
  if( pCms_average ) delete ( pCms_average );
}


void NICTcms::Execute( int eventType, EventNICT *event )
{
  vector <double> tmp;

  intFloatStar *pifs = (intFloatStar*)event->message_body;
  EventUseIndex = 0 ;
  switch( event->message_type ) {
  case INITIALIZE:
    break;

  case EV_KILL:
    pEvent->PutEvent( NICT_PROCESS, NORMAL_EXIT, NULL );
    break;

  case EV_ABEND:
    pEvent->PutEvent( NICT_PROCESS, ERROR_EXIT, NULL );
    break;
     	
  case EPV_DATA:
    for( int d = 0 ; d < veclen ; d++) tmp.push_back((double)pifs->fs[d]);
    pCms->in(tmp);
    while( pCms->outnum() != 0){
      tmp = pCms->out();
      intFloatStar *ptr = GetLocalEvent() ;
      for(int d = 0 ; d < veclen ; d++) ptr->fs[d] = (float)tmp[d] ;
      pEvent->PutEvent( NICTD_PARA, EPV_DATA, (EventNICT*)ptr );
    }
    break;
	
  case EV_TOF:
    pCms->tof();
    pEvent->PutEvent( NICTD_PARA, EV_TOF, NULL );	
    break;
	
  case EV_EOF:
    pEvent->PutEvent( NICTD_PARA, EV_EOF, NULL );	
    break;        			
  	
  case EPV_STARTPU:
    pEvent->PutEvent( NICTD_PARA, EPV_STARTPU, NULL );	
    break;
	
  case EPV_ENDPU:   	
    pCms->eof();
    while( pCms->outnum() != 0){
      tmp = pCms->out();
      intFloatStar *ptr = GetLocalEvent() ;
      for(int d = 0 ; d < veclen ; d++) ptr->fs[d] = (float)tmp[d] ;
      pEvent->PutEvent( NICTD_PARA, EPV_DATA, (EventNICT*)ptr );
    }
    pEvent->PutEvent( NICTD_PARA, EPV_ENDPU, NULL );	
    break;

  case EV_ABORT:    /* cancel of speech */

    pEvent->PutEvent( NICTD_PARA, EV_ABORT, NULL );
    break;
	
  default:
    break;
  }
}	


//private sub
// ファイルから 1 行読み込む関数

string NICTcms::readline(FILE *fp)
{

  string str;

  while(true){

    char buf[1024];
    if(!fgets(buf,1024,fp))  break;
    str+=buf;
    if(buf[strlen(buf)-1]=='\n')  break;

  }

  return(str);
}



// データタイプ・個数取得処理
void NICTcms::GetDataParam( int *in_size1, int *in_size2, int *out_size1, int *out_size2)
{

  *in_size1 = DEF_FLOAT;
  *in_size2 = veclen ;

  *out_size1 = DEF_FLOAT;
  *out_size2 = veclen;

  return;
}

// intFloatStar型の領域を確保して、そのポインタを返す。
// 既存領域がある場合は生成しない。
intFloatStar* NICTcms::GetLocalEvent()
{
  intFloatStar* ptr ;

  if( EventUseIndex < (int)EventTbl.size() ) {
    ptr = EventTbl[EventUseIndex] ;
  }
  else {
    ptr = (intFloatStar*)malloc(sizeof(intFloatStar)) ;
    if( ptr == NULL ) {
      fprintf( stderr, "NICTcms_execute: Cannot alloc memory for local_data\n" );
      return NULL ;
    }
    ptr->i  = veclen ;
    ptr->fs = (float*)malloc( sizeof(float) * veclen ) ;
    if( ptr->fs == NULL ) {
      fprintf( stderr, "NICTcms_execute: Cannot alloc memory for local_data.fs\n" );
      free( ptr ) ;
      return NULL ;
    }
    EventTbl.push_back( ptr ) ;
  }
  EventUseIndex++ ;

  return ptr ;
}
