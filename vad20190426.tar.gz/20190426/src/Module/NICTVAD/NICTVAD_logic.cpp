﻿/*-----------------------------------------------------------------------------
 VAD logic classes
-------------------------------------------------------------------------------
 Copyright (C) 2012 - 2016
   National Institute of Information and Communications Technology.
   All rights reserved.
-----------------------------------------------------------------------------*/

#include "logic.h"

using namespace std;

// 連続判定クラスのメンバ関数定義

// コンストラクタ関数

CONT::CONT(int len){
  Len=len;
  reset();
}

// 初期化関数

void CONT::reset(void){
  CalBuffer.clear();
  CalBuffer.resize(Len,false);
  OutBuffer.clear();
  return;
}

// 入力関数

void CONT::input(bool flag){
  CalBuffer.push_back(flag);
  while((Len+1+Len)<(int)CalBuffer.size())CalBuffer.erase(CalBuffer.begin());
  if((int)CalBuffer.size()!=(Len+1+Len))return;
  bool ret=true;
  for(int n=0;n<(Len+1+Len);n++){
    if(CalBuffer[n]==false){
      ret=false;
      break;
    }
  }
  OutBuffer.push_back(ret);
  return;
}

void CONT::input(const vector <bool> & flagseq){
  for(int n=0;n<(int)flagseq.size();n++)input(flagseq[n]);
  return;
}

// 出力関数

vector <bool> CONT::output(void){
  vector <bool> ret=OutBuffer;
  OutBuffer.clear();
  return(ret);
}

// 出力フレーム数の取得関数

int CONT::size(void) const{
  return(OutBuffer.size());
}

// 終了関数

vector <bool> CONT::flush(void){
  for(int n=0;n<Len;n++)input(false);
  vector <bool> ret=output();
  reset();
  return(ret);
}

// ギャップ補完クラスのメンバ関数定義

// コンストラクタ関数

GAP::GAP(int gaplen){
  GapLen=gaplen+1;
  reset();
}

// 初期化関数

void GAP::reset(void){
  Count = GapLen;
  OutBuffer.clear();
  return;
}

// 入力関数

void GAP::input(bool flag){
  if(flag==false)Count++;
  if((flag==true )&&(Count< GapLen)){
    for(int n=0;n<=Count ;n++)OutBuffer.push_back(true );
  }else if((flag==true )&&(Count>=GapLen)){
    OutBuffer.push_back(true );
  }else if((flag==false)&&(Count==GapLen)){
    for(int n=0;n<GapLen;n++)OutBuffer.push_back(false);
  }else if((flag==false)&&(Count>=GapLen)){
    OutBuffer.push_back(false);
  }
  if(flag==true)Count=0;
  return;
}

void GAP::input(const vector <bool> & flagseq){
  for(int n=0;n<(int)flagseq.size();n++)input(flagseq[n]);
  return;
}

// 出力関数

vector <bool> GAP::output(void){
  vector <bool> ret=OutBuffer;
  OutBuffer.clear();
  return(ret);
}

// 出力フレーム数の取得関数

int GAP::size(void) const{
  return(OutBuffer.size());
}

// 終了処理
vector <bool> GAP::flush2(void){
  if( Count < GapLen ) {
	  for(int n=0; n < Count ;n++) OutBuffer.push_back(false);
  }
  vector <bool> ret = output();
  reset();
  return(ret);
}


// 発話長クラスのメンバ関数定義

// コンストラクタ関数

DUR::DUR(int duration){
  Duration=duration;
  reset();
}

// 初期化関数

void DUR::reset(void){
  OutBuffer.clear();
  Count=0;
  return;
}

// 入力関数

void DUR::input(bool flag){
  if((flag==false)&&(Count<=Duration)){
    for(int n=0;n<=Count;n++)OutBuffer.push_back(false);
  }else if((flag==false)&&(Count> Duration)){
    OutBuffer.push_back(false);
  }else if((flag==true )&&(Duration< Count)){
    OutBuffer.push_back(true);
  }else if((flag==true )&&(Duration==Count)){
    for(int n=0;n<=Duration;n++)OutBuffer.push_back(true);
  }
  if(flag==true)Count++;
  else Count=0;
  return;
}

void DUR::input(const vector <bool> & flagseq){
  for(int n=0;n<(int)flagseq.size();n++)input(flagseq[n]);
  return;
}

// 出力関数

vector <bool> DUR::output(void){
  vector <bool> ret=OutBuffer;
  OutBuffer.clear();
  return(ret);
}

// 出力フレーム数の取得関数

int DUR::size(void) const{
  return(OutBuffer.size());
}

// 終了関数

vector <bool> DUR::flush(void){
  for(int n=0;n<Count;n++)input(false);
  vector <bool> ret=output();
  reset();
  return(ret);
}

// 開始繰り上げクラスのメンバ関数定義

// コンストラクタ関数

START::START(int startlen){
  StartLen=startlen;
  reset();
}

// 初期化関数

void START::reset(void){
  CalBuffer.clear();
  OutBuffer.clear();
  return;
}

// 入力関数

void START::input(bool flag){
  if(flag==true){
    for(int n=0;n<(int)CalBuffer.size();n++)OutBuffer.push_back(true);
    CalBuffer.clear();
  }
  CalBuffer.push_back(flag);
  while(StartLen<(int)CalBuffer.size()){
    OutBuffer.push_back(CalBuffer[0]);
    CalBuffer.erase(CalBuffer.begin());
  }
  return;
}

void START::input(const vector <bool> & flagseq){
  for(int n=0;n<(int)flagseq.size();n++)input(flagseq[n]);
  return;
}

// 出力関数

vector <bool> START::output(void){
  vector <bool> ret=OutBuffer;
  OutBuffer.clear();
  return(ret);
}

// 出力フレーム数の取得関数

int START::size(void) const{
  return(OutBuffer.size());
}

// 終了関数

vector <bool> START::flush(void){
  for(int n=0;n<(int)CalBuffer.size();n++)OutBuffer.push_back(CalBuffer[n]);
  vector <bool> ret=output();
  reset();
  return(ret);
}

// 終了引き延しクラスのメンバ関数定義

// コンストラクタ関数

END::END(int endlen){
  EndLen=endlen;
  reset();
}

// 初期化関数

void END::reset(void){
  Count=EndLen;
  OutBuffer.clear();
}

// 入力関数

void END::input(bool flag){
  if(flag==true){
    Count=0;
    OutBuffer.push_back(true);
  }else{
    if(Count<EndLen){
      OutBuffer.push_back(true);
    }else{
      OutBuffer.push_back(false);
    }
    Count++;
  }
  return;
}

void END::input(const vector <bool> & flagseq){
  for(int n=0;n<(int)flagseq.size();n++)input(flagseq[n]);
  return;
}

// 出力関数

vector <bool> END::output(void){
  vector <bool> ret=OutBuffer;
  OutBuffer.clear();
  return(ret);
}

// 出力フレーム数の取得関数

int END::size(void) const{
  return(OutBuffer.size());
}

// 終了関数

vector <bool> END::flush(void){
  vector <bool> ret=output();
  reset();
  return(ret);
}
