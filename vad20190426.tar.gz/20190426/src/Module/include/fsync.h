﻿/*-----------------------------------------------------------------------------
 FSYNC class
-------------------------------------------------------------------------------
 Copyright (C) 2012 - 2016
   National Institute of Information and Communications Technology.
   All rights reserved.
-----------------------------------------------------------------------------*/

#ifndef FSYNC_HH

#define FSYNC_HH

typedef unsigned char      byte;  // 1 byte
typedef unsigned short int word;  // 2 bytes
typedef unsigned int       dword; // 4 bytes

const int  DATA_MARK=0;   // データ
const int START_MARK=1;   // 発話区間開始
const int   END_MARK=2;   // 発話区間終了
const int   TOF_MARK=9;   // ファイルの先頭
const int   EOF_MARK=10;  // ファイルの終端

// FrameSync パケットクラス

class FSYNC{
private:
  dword   Headerno;   // ヘッダ番号
  int     Paramsize;  // データ数
  int     Paramtype;  // データ型
  void  * Data;       // データ本体

public:
  // コンストラクタとディストラクタ関数
   FSYNC(int paramsize,int paramtype);
   FSYNC(const FSYNC & fsync);
  ~FSYNC(void);

  // 代入演算子
  FSYNC & operator=(const FSYNC & fsync);

  // データ数とデータ型の取得関数
  int get_paramsize(void) const;
  int get_paramtype(void) const;

  // 初期化関数
  void clear(void);

  // パケットサイズの取得関数
  int size(void) const;

  // パケットデータの取得関数
        byte & operator[](int n);
  const byte & operator[](int n) const;

  // ヘッダ番号の取得設定関数
  dword get_headerno(void) const;
  void  set_headerno(dword headerno);

  // データの取得設定関数
        void * get_data(int n);
  const void * get_data(int n) const;
        void   set_data(const void * data,int n);

};

#endif
