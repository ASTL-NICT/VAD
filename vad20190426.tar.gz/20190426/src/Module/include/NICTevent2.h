﻿/*------------------------------------------------------------------------------
// Event handling Modules
//------------------------------------------------------------------------------
// Copyright (C) 2009 - 2016
//   National Institute of Information and Communications Technology.
//   All rights reserved.
//----------------------------------------------------------------------------*/

#ifndef _NICTEVENT2_H_
#define _NICTEVENT2_H_

#include <stdio.h>
#include "EventDefine.h"

// メモリ入出力用イベントライブラリ
class NICTevent2 {
private:
    // イベントキューをクラス内に取り込み、インスタンス毎に保持する。
	int        self_event_in;  /* position of last in event */
	int        self_event_receiver_queue[ SELF_EVENT_STACK_SIZE ];/* receiver id */
	int        self_event_type_queue[ SELF_EVENT_STACK_SIZE ];/* what type it was */
	EventNICT  *self_event_body_queue[ SELF_EVENT_STACK_SIZE ];/* event body (contents) */
	// 一時使用キュー
	int        self_event_in_tmp;  /* position of last in event */
	int        self_event_receiver_queue_tmp[ SELF_EVENT_QUEUE_SIZE ];
	int        self_event_type_queue_tmp[ SELF_EVENT_QUEUE_SIZE ];/* what type it was */
	EventNICT  *self_event_body_queue_tmp[ SELF_EVENT_QUEUE_SIZE ];/* event body (contents) */

	EventNICT	local_e;
public:
    NICTevent2();
    virtual ~NICTevent2();

    int Initialize();
    void Terminate();
    int GetEvent(EventNICT **event);
    int PutEvent(int receiver, int type, EventNICT *event);
    // 出力用
    int GetOutputEvent( EventNICT **event );
    int PutOutputEvent( EventNICT *event);
};
#endif
