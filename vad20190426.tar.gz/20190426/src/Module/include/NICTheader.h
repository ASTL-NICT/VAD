/*------------------------------------------------------------------------------
// NICTheader.h
//------------------------------------------------------------------------------
// Copyright (C) 2009 - 2016
//   National Institute of Information and Communications Technology.
//   All rights reserved.
//----------------------------------------------------------------------------*/

/*
  NICTheader.h
  defines header for data communication for demo

*/
#ifndef H_NICTheader
#define H_NICTheader

/* for frame sync header */
#define        DATA_MARK 0          /* a frame containing speech data */
#define        START_MARK 1         /* start of pause unit */
#define        END_MARK 2           /* end of pause unit */
#define        START_SENT_MARK 3    /* start of sentence (consisting of 1 */
                                    /*               or more pause units) */
#define        END_SENT_MARK 4      /* end of sentence (consisting of 1 */
                                    /*             or more pause units) */
#define        FILE_END_MARK 5      /* end of demo */
#define        CANCEL_MARK 6        /* false alarm: END_MARK but preceding */
                                    /* was garbage not speech */
#define        TENTATIVE_END_MARK 7 /* "maybeend": early warning of possible */
                                    /*             forthcoming END_SENT_MARK */
#define        NONSPEECH_MARK 8     /* The opposite of DATA_MARK */

#define        TOF_MARK       9     /* start of one input file %TAG-BR411a% */
#define        EOF_MARK      10     /* end of one input file %TAG-BR411a% */

#endif

/* EOF */
