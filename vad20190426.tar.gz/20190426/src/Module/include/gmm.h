﻿/*-----------------------------------------------------------------------------
 GMM class
-------------------------------------------------------------------------------
 Copyright (C) 2012 - 2016
   National Institute of Information and Communications Technology.
   All rights reserved.
-----------------------------------------------------------------------------*/

#ifndef GMM_HH

#define GMM_HH

#include<string>
#include<vector>

#define SPRINTRA2_OPT_GMM_CALC_PROB 1

using namespace std;

// GMM クラス

class GMM{
private:
  int       VecLen;    // ベクトル長
  int       MixNum;    // 混合数
  double  * BWeight;   // 混合分岐確率
  double ** Mean;      // 平均ベクトル
  double ** Variance;  // 分散ベクトル
  double  * GConst;    // G 定数

public:
  // コンストラクタとディストラクタ関数
   GMM(const string & filename);
   GMM(int veclen,int mixnum);
   GMM(const GMM & gmm);
  ~GMM(void);

  // 代入演算子
  GMM & operator=(const GMM & gmm);

  // ベクトル長, 混合数の取得関数
  int get_veclen(void) const;
  int get_mixnum(void) const;

  // 混合分岐確率, 平均分散ベクトルの取得関数
  double         get_bweight (int m) const;
  const double * get_mean    (int m) const;
  const double * get_variance(int m) const;

  // 混合分岐確率, 平均分散ベクトルの設定関数
  void set_bweight (int m,double                  bweight );
  void set_mean    (int m,const vector <double> & mean    );
  void set_mean    (int m,const double          * mean    );
  void set_variance(int m,const vector <double> & variance);
  void set_variance(int m,const double          * variance);

  // 確率の計算関数
  double calc_prob(const double * parvec) const;
  double calc_prob(int m,const double * parvec) const;



#ifdef SPRINTRA2_OPT_GMM_CALC_PROB
    // Expand in line.
    double calc_prob(const std::vector<double> & parvec) const {
        return calc_prob(parvec.data());
    }
    double calc_prob(int m,const std::vector<double> & parvec) const {
        return calc_prob(m, parvec.data());
    }
#else
    double calc_prob(const std::vector<double> & parvec) const;
    double calc_prob(int m,const std::vector<double> & parvec) const;
#endif


};

#endif


