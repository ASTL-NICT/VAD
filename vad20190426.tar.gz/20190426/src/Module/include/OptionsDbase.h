﻿/*------------------------------------------------------------------------------
//
//------------------------------------------------------------------------------
// Copyright (C) 2011 - 2016
//   National Institute of Information and Communications Technology.
//   All rights reserved.
//----------------------------------------------------------------------------*/

#ifndef _OPTIONSDBASE_H_
#define _OPTIONSDBASE_H_

#include <stdio.h>
#include <ctype.h>
#include <time.h>
#include <string>

/*  サービス関数の戻り値  */
#define OPT_FAILURE             0       /*  The function failed  */
#define OPT_SUCCESS             1       /*  all went well  */
/*  サービス関数の戻り値。上記のものにビットフラグとして加算  */
#define OPT_Help                2
#define OPT_Version             4
#define OPT_OptionsList         8
#define OPT_ConfigFile          16
#define OPT_EtcOptions          32

/*  オプションデータのリードチェックフラグ値  */
#define OPT_READYDEFAULT        -1
#define OPT_NOTREADY            0  /* set calloc() */
#define OPT_ALREADYREAD         1
#define OPT_READYREAD           2
/*  オプションデータのリードライト読みだしフラグ値  */
#define GEToptCONST             0
#define GEToptRdWt              1

/*  オプションデータリストのストラクチャーの定義  */
typedef struct {
    int				alreadyread;    /* read check flag                      */
    char			*name;      /* the string of the option     */
    char			*value;     /* the value of the option      */
    char			*defvalue;  /* the value of the default option  */
    void			*next;
} NICTargument;

typedef struct {
    int				parseId;       /*  オプションの分析単位のグループＩＤ  */
    char			*groupname;    /*  オプション読み込みファイルでの、読み込み指定見出し  */
    char			*originaladdr; /*  オプションデータのデフォルトのオリジナルのアドレス  */
    NICTargument	*options;      /*  オプションデータのリスト  */
    NICTargument	*nowoption;    /*  現在読み書きの対象となっているオプション  */
    void			*next;
} NICToptionsList ;

class OptionsDbase {
private:
    int             nowOptParseId ;
    int             iOptionCheckFlg;
    int             count_parseId ;

    NICToptionsList	*topDBase ;
    NICToptionsList	*nowDBase ;


public:
    OptionsDbase() ;
    virtual ~OptionsDbase() ;

    char *strSaveArea( const char * string ) ;
    int  createNewOption( const char *optionname ) ;
    int  createNewParse( void );
    int  setOrigAddr( char *originaldata );
    int  setGroupName( const char *datastring );
    int  setDefValue( const char *datastring );
    int  setValue( const char *datastring );
    int  alreadyread( void );
    char *getOrigAddr( void );
    int  getGroupName( char **valuebox, int gettype );
    int  getDefValue( char **valuebox, int gettype );
    int  getValue( char **valuebox, int gettype ) ;
    int  getName( char **valuebox, int gettype );
    int  setStackParseId( int parseId );
    int  setStackOptData( int parseId, const char *optionname );
    int  reSetStackOptData( void );
    int  pushStackOptData( void );

private:
    void DestroyDB() ;
    void FreeArgument( NICTargument *arg ) ;
};
#endif
