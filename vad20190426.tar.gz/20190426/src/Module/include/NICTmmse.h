﻿/*-----------------------------------------------------------------------------
 NICTmsse class
-------------------------------------------------------------------------------
 Copyright (C) 2012 - 2016
   National Institute of Information and Communications Technology.
   All rights reserved.
-----------------------------------------------------------------------------*/

#ifndef MMSE_HH

#define MMSE_HH

#include <string>
#include <vector>

#include "gmm.h"
#include "fbank.h"

#include <stdio.h>
#include "NICTevent2.h"
#include "NICToptions.h"
extern "C" {
#include "NICTutil.h"
}

#define DEF_SHORT		1	// short
#define DEF_FLOAT		2	// float
#define DEF_DOUBLE		3	// double


using namespace std;

// MMSE クラス

class MMSE{
private:

  int                            VecLen;       // ベクトル長
  int                            MixNum;       // 混合数
  int                            WinLen;       // 分析窓長
  int                            ShiftLen;     // フレームシフト幅

  FBANK                        * FBank;        // フィルタバンク分析
  vector <short int *>           FrameWave;    // フレーム音声波形

  GMM                          * CleanGMM;     // クリーン音声 GMM
  GMM                          * NoisyGMM;     // 雑音重畳音声 GMM
  int                            InitNum;      // 初期雑音推定フレーム数

  int                            FilLen;       // フィルタ長
  int                            FilLenHalf;   // ...

  double                       * CenFreq;      // フィルタバンク中心周波数
  double                       * DelFreq;      // IDCT の重み係数
  double                      ** IDCT;         // 逆 DCT 行列
  double                       * HanWin;       // ハニング窓係数

  short int                    * ConvBuf;      // 畳み込み用音声波形バッファ
  int                            ConvLen;      // バッファサイズ
  int                            ConvNum;      // データ数
  vector <double *>              Impulse;      // ウィーナフィルタ

  vector <vector <short int> >   EnhWave;      // 雑音抑圧された音声波形

  // インパルス応答の計算関数
  void calc_impulse(const vector <double> & parvec);

  // ウィーナフィルタの適用関数
  void apply_wiener(const short int * framewave);

public:
  // コンストラクタとディストラクタ関数
   MMSE(int veclen,int winlen,int shiftlen,int smpfreq,double lowcutoff,
	double highcutoff,double preemp,int initnum,
	const string & gmmfilename);
  ~MMSE(void);

  // 雑音抑圧条件の取得関数
  int    get_veclen    (void) const;
  int    get_mixnum    (void) const;
  int    get_winlen    (void) const;
  int    get_shiftlen  (void) const;
  int    get_smpfreq   (void) const;
  double get_lowcutoff (void) const;
  double get_highcutoff(void) const;
  double get_preemp    (void) const;
  int    get_initnum   (void) const;

  // 初期化関数
  void clear(void);

  // 雑音の設定関数
  void set_noise(const vector <double> & noise);

  // 音声波形の入力関数
  void in(const short int          * wave);
  void in(const vector <short int> & wave);

  // 音声波形の入力終了関数
  void flush(void);

  // 雑音抑圧された音声波形の取得関数
  int outnum(void) const;
  vector <short int> out(void);

};

struct StrNICTmmse {

    int    		FilterBankOrder;    /* veclen  */
    double 		FrameLength;         /* window  */
    double 		FrameShift;          /* shift  */
    int 		SamplingFrequency;   /* smpfreq */
    double 		highcutoff;
    double 		lowcutoff;
    double 		Preemphasis;         /*  preemp  */
    string 		CleanSpeechGMM;      /*  cleanfilename  */
    double 		InitialNoiseLength;   /*  init */
};


class NICTmmse {
private:

	int   options_id;
	// オブジェクト保持用
    NICTevent2	*pEvent;
	NICToptions	*pOption ;

    // MMSE準備   	
    int winlen;
    int initnum;

    // MMSE
  	void	 *sMMSE;
	
    // intShortStarの管理テーブル
    int                     EventUseIndex ;
    vector<intShortStar*>   EventTbl ;
	
public:
	NICTmmse() ;
    NICTmmse(NICTevent2 *event, NICToptions *option) ;
    virtual ~NICTmmse() ;

	struct StrNICTmmse cmmseOptions;
	struct StrNICTmmse *pcmmseOptions;

	// 初期化処理
    int Initialize( int argn, char *argv[] );

   	// 終了処理
    void Terminate( int arg );

    // データ処理
    void Execute( int eventType, EventNICT *event );

    // データタイプ・個数取得処理
    void GetDataParam( int *in_size1, int *in_size2, int *out_size1, int *out_size2);

    // MMSE準備   	
    int shiftlen;

private:
    intShortStar* GetLocalEvent() ;

};

#endif

