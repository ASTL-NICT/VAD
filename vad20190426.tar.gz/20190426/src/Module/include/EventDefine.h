/*------------------------------------------------------------------------------
// Event define
//------------------------------------------------------------------------------
// Copyright (C) 2011 - 2016
//   National Institute of Information and Communications Technology.
//   All rights reserved.
//----------------------------------------------------------------------------*/

#ifndef _EVENTDEFINE_H_
#define _EVENTDEFINE_H_

#define	SELF_EVENT_EMPTY		-1
#define	SELF_EVENT_STACK_SIZE	10000
#define	SELF_EVENT_QUEUE_SIZE	10000

#define NICT_FRONTEND_STR   "NICTfrontend"
#define	NICT_WAVE2CEP_STR	"NICTwave2cep"
#define	NICT_CEP2PARA_STR	"NICTcep2para"
#define NICT_MVN_STR		"NICTmvn"
#define NICT_MMSE_STR		"NICTmmse"
#define NICT_MFCC_STR		"NICTmfcc"
#define NICT_CMS_STR		"NICTcms"
#define NICT_VAD_STR		"NICTvad"
#define NICT_OFE_STR		"NICTofe"
#define NICT_FORWARD_STR	"NICTForward"

enum EPV {  /* Often assigned to message_type and EventStatus */
  /* application dependent*/
  EPV_INIT = 0,
  EPV_DATA  =         01,
  EPV_STARTPU =       02,
  EPV_ENDPU =         04,	
  EPV_MAYBESTART =   010,	
  EPV_MAYBEEND   =   020,	/* unused */
  EPV_STARTSENT =    040,	
  EPV_ENDSENT   =   0100,	
  EPV_STARTUTT =    0200,	
  EPV_ENDUTT   =    0400,	
  EPV_STARTTURN =  01000,	
  EPV_ENDTURN   =  02000,	

  /* application independent  %TODO% */
  EV_NONURGENT  = 0100000,
  EV_ABORT =      0200000,        /* EPV_CANCEL is a good alias for this */
  EV_KILL =       0400000,
  EV_NONE =      01000000,
  EV_ABEND =     02000000,
  EV_EOF   =     04000000,         /* BR: EOF has been encountered on the input */
  EV_TOF   =    010000000,         /* BR: TOF has been encountered on the input */
  EV_NONFINAL_STRING = 020000000,
  EV_FINAL_STRING    = 040000000,
  EV_CLOSED         = 0100000000,
  EV_SURE           = 0200000000,

  /* application internal base  %TODO% */
  EV_LOCAL =   0400000000	   /* ex) RPC_EXEC = EV_LOCAL + 01;	*/
} ;

enum NICT_message_body {                 /* often assigned to message_body */
  /* module id, used e.g. by rpc */

  NICT_PROCESS          = 0x00000001,	/* for messages to the process	*/
  NICT_EPD              = 0x00000002,
  NICT_FILTER           = 0x00000003,
  NICT_WAVE2CEP         = 0x00000004,
  NICT_2CHANNELSS       = 0x00000005,
  NICT_CEP2PARA         = 0x00000008,
  NICT_LATTICE          = 0x00000010,
  NICT_RESULT           = 0x00000020,
  NICT_DISPLAYPOW       = 0x00000040,
  NICT_QBADAPT          = 0x00000080,
  NICT_VITERBI          = 0x00000100,
  NICT_SENDANS          = 0x00000200,
  NICT_SENDSLF          = 0x00000300,
  NICT_WAVECUT          = 0x00000400,
  NICT_SSSDATA          = 0x00000800,
  NICT_ANSSYNC          = 0x00001000,
  NICT_F0               = 0x00002000,
  NICT_SWITCH           = 0x00003000,
  NICT_SRCONV           = 0x00004000,
  SBINPUT              = 0x00005000,
  NICT_CONTROL	       = 0x00006000,
  NICT_SPD	           = 0x00007000,
  NICT_NULLDEV          = 0x00008000,	/* Not output	*/
  NICT_USER             = 0x00010000,	/* Not output	*/
  NICT_CMS              = 0x00020000,
  NICT_MMSE             = 0x00030000,
  NICT_MFCC             = 0x00040000,
  NICT_OFE              = 0x00080000,    // ainoue 20130806
  NICT_VAD              = 0x00050000,
  NICT_FORWARD          = 0x00060000,
  NICT_RESCORE	       = 0x00009000,
  NICT_FRONTEND	       = 0x0000A000,   /* [from visit osaka] 2009/12/24 ykita add */
  NICT_MICROPHONEARRAY  = 0x0000B000,
  NICT_DECOMPRESS       = 0x0000C000,
  NICT_MVN              = 0x0000D000,
  NICT_FEATUREVAD       = 0x0000E000,
  NICT_SAMPLINGRATECONVERTER = 0x0000F000,

  /* input type id, used to send data */
  NICTD_WAVE            = 0x00100000,    /* D stands for data */
  NICTD_MARKED_WAVE     = 0x00200000,
  NICTD_SCEP            = 0x00300000,    /* subtracted cepstrum */
  NICTD_CEP             = 0x00400000,
  NICTD_DCEP            = 0x00800000,
  NICTD_DDCEP           = 0x01000000,
  NICTD_HPFCEP          = 0x02000000,
  NICTD_PARA            = 0x04000000,
  NICTD_LATTICE         = 0x08000000,
  NICTD_F0              = 0x10000000,
  NICTD_RAW_WAVE        = 0x20000000,  /* input for srconv */
  NICTD_EXTERNAL        = 0x40000000,  /* for output of NICTNULLexec	*/
  NICTD_MARKED_PARA     = 0x04000001,
  NICTD_RAW_PARA        = 0x05000000,
  NICTD_RESCOREDLATTICE = 0x08000001,

  NICTD_USER            = 0x40000001
} ;
enum NICTProcessMessage {
    NOT_EXIT	= 0,
    NORMAL_EXIT	= 1,	/*	exit( 0 );	*/
    ERROR_EXIT	= 2,	/*	exit( 1 );	*/
    MEMORY_EXIT 	= 3    	/*	exit( 2 ); 	*/
};

enum {
  INITIALIZE = 0
} ;

typedef	struct	NICT_Event	{
    enum EPV 			message_type;
    struct NICT_Event	*message_body;
} EventNICT;

#endif
