﻿/*-----------------------------------------------------------------------------
 NICTcms class
-------------------------------------------------------------------------------
 Copyright (C) 2012 - 2016
   National Institute of Information and Communications Technology.
   All rights reserved.
-----------------------------------------------------------------------------*/

#ifndef CMS_HH

#define CMS_HH

#include <string>
#include <vector>

#include "NICTevent2.h"
#include "NICToptions.h"
extern "C" {
#include "NICTutil.h"
}

#define DEF_SHORT		1	// short
#define DEF_FLOAT		2	// float
#define DEF_DOUBLE		3	// double

using namespace std;

// 抽象 CMS クラス

class CMS{
 public:
  // ディストラクタ関数
  virtual ~CMS(void){};

  // 発話開始終了宣言関数
  virtual void tof(void)=0;
  virtual void eof(void)=0;

  // 特徴ベクトルの入力関数
  virtual void in(const vector <double> & parvec)=0;

  // 特徴ベクトルの取得関数
  virtual int outnum(void) const=0;
  virtual vector <double> out(void)=0;

};

class CMS_AVERAGE : public CMS {
 private:
  vector <double> mean;
  int                       CepLen;       // MFCC 次元数
  vector <string>           Kind;         // 音響特徴量の構成
  int                       VecLen;       // ベクトル長
  vector <bool>             CMFlag;       // 補正フラグ
  int                       Count;        // 処理フレーム番号
  vector <vector <double> > TmpParvec;    // 特徴ベクトルの一時保存領域
  vector <vector <double> > OutParvec;    // 特性補正された特徴ベクトル
  int                       AverageFrames;// 過去いくつのframeの特徴量を用いて平均ベクトルを計算するのかの設定(=0は過去全てのframeを使用する)

 public:
  CMS_AVERAGE(int ceplen,const vector <string> & kind,int averageFrame);
  void in(const vector <double> & parvec);
  void tof(void);
  void eof(void);
  int outnum(void) const;
  vector <double> out(void);
};


// online CMS クラス

class CMS_ONLINE : public CMS{
 private:
  int                       CepLen;       // MFCC 次元数
  vector <string>           Kind;         // 音響特徴量の構成
  int                       VecLen;       // ベクトル長

  vector <bool>             CMFlag;       // 補正フラグ

  vector <double>           InitCepMean;  // 初期平均ケプストラム
  int                       Delay;        // 初期平均ケプストラムに対する重み
  int                       Count;        // 処理フレーム番号
  vector <double>           CepMean;      // 平均ケプストラムベクトル

  vector <vector <double> > OutParvec;    // 特性補正された特徴ベクトル

 public:
  // コンストラクタ関数
  CMS_ONLINE(int ceplen,const vector <string> & kind,
	     const vector <double> & initcepmean,int delay);

  // 補正条件の取得関数
  int                     get_ceplen     (void) const;
  const vector <string> & get_kind       (void) const;
  int                     get_veclen     (void) const;
  const vector <double> & get_initcepmean(void) const;
  int                     get_delay      (void) const;

  // 発話開始終了関数
  void tof(void);
  void eof(void);

  // 特徴ベクトルの入力関数
  void in(const vector <double> & parvec);

  // 特徴ベクトルの取得関数
  int outnum(void) const;
  vector <double> out(void);

};

// 1pass CMS クラス

class CMS_1PASS : public CMS{
 private:
  int                       CepLen;       // MFCC 次元数
  vector <string>           Kind;         // 音響特徴量の構成
  int                       VecLen;       // ベクトル長

  vector <bool>             CMFlag;       // 補正フラグ

  double                    AttRate;      // 減衰係数
  bool                      InitFlag;     // 第一発話フラグ
  vector <double>           CepMean;      // 平均ケプストラムベクトル

  vector <vector <double> > TmpParvec;    // 特徴ベクトルの一時保存領域
  vector <vector <double> > OutParvec;    // 特性補正された特徴ベクトル

 public:
  // コンストラクタ関数
  CMS_1PASS(int ceplen,const vector <string> & kind,double attrate);

  // 補正条件の取得関数
  int                     get_ceplen (void) const;
  const vector <string> & get_kind   (void) const;
  int                     get_veclen (void) const;
  double                  get_attrate(void) const;

  // 発話開始終了関数
  void tof(void);
  void eof(void);

  // 特徴ベクトルの入力関数
  void in(const vector <double> & parvec);

  // 特徴ベクトルの取得関数
  int outnum(void) const;
  vector <double> out(void);

};

// 2pass CMS クラス

class CMS_2PASS : public CMS{
 private:
  int                       CepLen;       // MFCC 次元数
  vector <string>           Kind;         // 音響特徴量の構成
  int                       VecLen;       // ベクトル長

  vector <bool>             CMFlag;       // 補正フラグ

  vector <vector <double> > TmpParvec;    // 特徴ベクトルの一時保存領域
  vector <vector <double> > OutParvec;    // 特性補正された特徴ベクトル

 public:
  // コンストラクタ関数
  CMS_2PASS(int ceplen,const vector <string> & kind);

  // 補正条件の取得関数
  int                     get_ceplen(void) const;
  const vector <string> & get_kind  (void) const;
  int                     get_veclen(void) const;

  // 発話開始終了関数
  void tof(void);
  void eof(void);

  // 特徴ベクトルの入力関数
  void in(const vector <double> & parvec);

  // 特徴ベクトルの取得関数
  int outnum(void) const;
  vector <double> out(void);

};

struct StrNICTcms {

  int    		CepstrumOrder;
  string 		Parameter;
  string 		CMSType;
  double 		AttRate;
  string 		InitMean;
  int 		Delay;
  int AverageFrames;
};



class NICTcms {
 private:


  int     options_id;
  int     veclen;

  vector <string> kind;
  vector <double> initcepmean;

  // オブジェクト保持用
  NICTevent2	*pEvent;
  NICToptions	*pOption ;

  struct StrNICTcms ccmsOptions;
  struct StrNICTcms *pccmsOptions;
	
  // CMS 処理領域の設定

  CMS_1PASS   *pCms_1pass;
  CMS_2PASS   *pCms_2pass;
  CMS_ONLINE  *pCms_online;
  CMS_AVERAGE *pCms_average;


  CMS         *pCms;

  // intFloatStarの管理テーブル
  int                     EventUseIndex ;
  vector<intFloatStar*>   EventTbl ;

  // ファイルから 1 行読み込む関数
  string readline(FILE *fp);
	

 public:
  NICTcms() ;
  NICTcms(NICTevent2 *event, NICToptions *option) ;
  virtual ~NICTcms() ;

  // 初期化
  int Initialize( int argn, char *argv[] );

  // 終了処理
  void Terminate( int arg );

  //  データ処理
  void Execute( int eventType, EventNICT *event );

  // データタイプ・個数取得処理
  void GetDataParam( int *in_size1, int *in_size2, int *out_size1, int *out_size2);
 private:
  intFloatStar* GetLocalEvent() ;
};
#endif
