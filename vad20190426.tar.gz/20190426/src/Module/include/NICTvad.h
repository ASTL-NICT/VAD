﻿/*-----------------------------------------------------------------------------
 NICTvad class
-------------------------------------------------------------------------------
 Copyright (C) 2012 - 2016
   National Institute of Information and Communications Technology.
   All rights reserved.
-----------------------------------------------------------------------------*/

#ifndef VAD_H

#define VAD_H

#include <string>
#include <vector>
#include <deque>

#include "gmm.h"
#include "kind.h"
#include "logic.h"

#include "NICTevent2.h"
#include "NICToptions.h"
extern "C" {
#include "NICTutil.h"
}


#define DEF_SHORT		1	// short
#define DEF_FLOAT		2	// float
#define DEF_DOUBLE		3	// double

using namespace std;

// VAD クラス

class VAD{
private:
  CONT          * Cont;       // 連続した発話フレームの判定
  GAP           * Gap;        // 発話フレーム間のギャップの補完
  DUR           * Dur;        // 最小発話時間の制限
  START         * Start;      // 開始の繰り上げ
  END           * End;        // 終了の引き延し
  vector <bool>   VADOut;     // VAD 出力用バッファ

public:
  // コンストラクタとディストラクタ関数
   VAD(int conlen,int gaplen,int durlen,int startlen,int endlen);
  ~VAD(void);

  // 初期化関数
  void reset(void);

  // VAD の入力関数
  void in(bool flag);

  // VAD の入力終了関数
  void flush(void);

  // VAD 結果の取得関数
  int outnum(void) const;
  bool out(void);

};

// フレーム単位 VAD クラス (GMM)

class FRAME_VAD_GMM{
private:
  double          PostThresh;  // 事後確率に対する閾値
  GMM           * NoisyGMM;    // 雑音重畳音声 GMM
  GMM           * NoiseGMM;    // 雑音 GMM

  vector <bool>   VADOut;      // VAD 出力用バッファ

public:
  // コンストラクタとディストラクタ関数
   FRAME_VAD_GMM(double posthr,const GMM & noisygmm,const GMM & noisegmm);
  ~FRAME_VAD_GMM(void);

  // 初期化関数
  void reset(void);

  // 特徴ベクトルの入力関数
  void in(const vector <double> & parvec);

  // VAD 結果出力関数
  int outnum(void) const;
  bool out(void);

};

// フレーム単位 VAD クラス (パワー)

class FRAME_VAD_POW{
private:
  int             Count;         // フレームカウンタ
  double          PowThresh;     // パワーに対する閾値
  int             InitNoiseLen;  // 初期雑音パワー推定長
  double          InitNoisePow;  // 初期雑音パワー
  int             NoiseBufferLen; // ノイズバッファのサイズ
  vector <double> PowBuf;        // パワーバッファ
  vector <bool>   VADOut;       // VAD 出力用バッファ
  deque <double>  NoiseBuf;     // ノイズバッファ
  deque <double>  NoiseTmp;     // ノイズ計算用一時バッファ

public:
  // コンストラクタ関数
  FRAME_VAD_POW(double powthr,int initlen, int noisebuflen);

  // 初期化関数
  void reset(void);

  // パワーの入力関数
  void in(double pow);

  // ノイズ候補データの入力
  void in_noise(double pow);

  // ノイズデータの更新
  void renew_noise(bool is_noise);

  // パワーの入力終了関数
  void flush(void);

  // VAD 結果出力関数
  int outnum(void) const;
  bool out(void);
};




struct StrNICTvad {

    string      VAD;  	
    double 		FrameLength;
    double 		FrameShift;
    long	    SamplingFrequency;
    long		CepstrumOrder;
    string		InputParameter;
    string		OutputParameter;
    string		PowParameter;
    double 		InitialPowerLength;
    double		PowerThreshold;
    string		GMMParameter;
    string   	NoisyGMM;
    string   	NoiseGMM;
	double 	    PosteriorThreshold;
	long 		ConsecutiveLength;
 	long	    MaximumGapLength;
    long	    MinimumUtteranceLength;
	long	    PrerollLength;
	long        AfterrollLength;
    string   	SendSpeechOnly;
    string   	Tof_eq_StartMark;
    string    PowerNoiseSequentialEstimation;
    long    PowerNoiseBufferLength;
};



class NICTvad {
private:


    vector <double>           inp_parvec;
    vector <vector <double> > out_parvec;

	int     winlen;
	int     initlen;
	int     options_id;

    bool    curr;
	bool    prev;
	bool    startmark;
	bool    tof_flag;

    vector <string> kind_in;
	vector <string> kind_out;
	vector <string> kind_pow;
	vector <string> kind_gmm;
    vector <double> initcepmean;

	// オブジェクト保持用
    NICTevent2	*pEvent;
	NICToptions	*pOption ;

	KIND        *pInp_Kind;
	KIND        *pOut_Kind;
	KIND        *pPow_Kind;
	KIND        *pGmm_Kind;

	KIND_CONV   *pTo_pow;
	KIND_CONV   *pTo_gmm;
	KIND_CONV   *pTo_out;

	FRAME_VAD_POW  *pVad_pow;
	FRAME_VAD_GMM  *pVad_gmm;

	VAD         *pVad;


  	struct StrNICTvad cvadOptions;
	struct StrNICTvad *pcvadOptions;

	 // intFloatStarの管理テーブル
    int                     EventUseIndex ;
    vector<intFloatStar*>   EventTbl ;

public:
	NICTvad() ;
    NICTvad(NICTevent2 *event, NICToptions *option) ;
    virtual ~NICTvad() ;

// 初期化
    int Initialize( int argn, char *argv[] );

// 終了処理
    void Terminate( int arg );

//  データ処理
    void Execute( int eventType, EventNICT *event );

// データタイプ・個数取得処理
    void GetDataParam( int *in_size1, int *in_size2, int *out_size1, int *out_size2);

private:
    intFloatStar* GetLocalEvent() ;
};
#endif
