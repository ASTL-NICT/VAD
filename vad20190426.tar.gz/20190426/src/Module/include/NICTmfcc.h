﻿/*-----------------------------------------------------------------------------
 NICTmfcc class
-------------------------------------------------------------------------------
 Copyright (C) 2012 - 2016
   National Institute of Information and Communications Technology.
   All rights reserved.
-----------------------------------------------------------------------------*/

#ifndef MFCC_HH

#define MFCC_HH

#include <vector>

#include "fbank.h"
#include "NICTdelta.h"

#include "NICTevent2.h"
#include "NICToptions.h"
extern "C" {
#include "NICTutil.h"
}

#define DEF_SHORT		1	// short
#define DEF_FLOAT		2	// float
#define DEF_DOUBLE		3	// double


using namespace std;

// MFCC 計算クラス

class MFCC{
private:

  FBANK                      * FBank;     // フィルタバンク分析

  int                          FBankLen;  // フィルタバンク数
  int                          ShiftLen;  // フレームシフト幅
  int                          CepLen;    // MFCC 次元数

  vector <vector <double> >    Parvec;    // 特徴ベクトル (pow+c0+cep)

  // MFCC 特徴量の計算関数

  void calc_parvec(void);

public:
  // コンストラクタとディストラクタ関数
   MFCC(int ceplen,int fbanklen,int zerolen,int winlen,int shiftlen,
	int smpfreq,double lowcutoff,double highcutoff,double preemp);
  ~MFCC(void);

  // 音響分析条件の取得関数
  int    get_ceplen    (void) const;
  int    get_fbanklen  (void) const;
  int    get_winlen    (void) const;
  int    get_shiftlen  (void) const;
  int    get_smpfreq   (void) const;
  double get_lowcutoff (void) const;
  double get_highcutoff(void) const;
  double get_preemp    (void) const;

  // 初期化関数
  void clear(void);

  // 音声波形の入力関数
  void in(const short int          * wave);
  void in(const vector <short int> & wave);

  // 音声波形の入力終了関数
  void flush(void);

  // MFCC 特徴量の取得関数
  int outnum(void) const;
  vector <double> out(void);

};

struct StrNICTmfcc {

    int    		FilterBankOrder;    /* fbanklen  */
    double 		FrameLength;         /* window  */
    double 		FrameShift;          /* shift  */
    double 		ZeroPadLength;       /* zero */
    int   		SamplingFrequency;   /* smpfreq */
    double 		CutoffHighFrequency; /* highcutoff */
    double 		CutoffLowFrequency;  /* lowcutoff  */
    double 		Preemphasis;         /* preemp */
    int 		CepstrumOrder;       /* ceplen */
    int 		DeltaCepstrumWindow; /* deltalen */
    string		Parameter;

};





class NICTmfcc {
private:

	int    options_id;
	// オブジェクト保持用
    NICTevent2	*pEvent;
	NICToptions	*pOption ;
	
	struct StrNICTmfcc cmfccOptions;
	struct StrNICTmfcc *pcmfccOptions;
	
	int  winlen;
	int  shiftlen;
	int  zerolen;
	int  veclen;
	
// 音響特徴量計算用関数

	MFCC  * pCep;                  // 静的特徴量計算オブジェクト
	DELTA * pDel;                  // 1 次時間微分特徴量計算オブジェクト
	DELTA * pAcc;                  // 2 次時間微分特徴量計算オブジェクト

	vector <vector <double> > CepBuf;  // 静的特徴量
	vector <vector <double> > DelBuf;  // 1 次時間微分特徴量
	vector <vector <double> > AccBuf;  // 2 次時間微分特徴量
    vector <string> kind;

// 初期化関数
	void clear( void );
	
// 音声波形の入力関数	
    void in( const short int * wave );

// 音声波形の入力終了関数
    void flush( void );

// 音響特徴量の出力関数
    int outnum( void );
    vector <float> out(const vector <string> & kind);

    // intFloatStarの管理テーブル
    int                     EventUseIndex ;
    vector<intFloatStar*>   EventTbl ;

public:

	NICTmfcc() ;
    NICTmfcc(NICTevent2 *event, NICToptions *option) ;
    virtual ~NICTmfcc() ;

// 初期化
    int Initialize( int argn, char *argv[] );

// 終了処理
    void Terminate( int arg );

// データ処理
    void Execute( int eventType, EventNICT *event );

// データタイプ・個数取得処理
    void GetDataParam( int *in_size1, int *in_size2, int *out_size1, int *out_size2);
private:
    intFloatStar* GetLocalEvent() ;
};



#endif
