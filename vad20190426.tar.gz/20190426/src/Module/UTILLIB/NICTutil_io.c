/*------------------------------------------------------------------------------
// String and file I/O operation Library.
//------------------------------------------------------------------------------
// Copyright (C) 2009 - 2016
//   National Institute of Information and Communications Technology.
//   All rights reserved.
//----------------------------------------------------------------------------*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
//Windows�ܿ����ɲ�
#ifndef _WIN32
#include <unistd.h>
#endif
#include <sys/stat.h>
#include <errno.h>
#include "NICTutil.h"
#include "IOCoding.h"

#define BUFF_SIZE       1000
#define MODE            S_IRUSR|S_IWUSR|S_IXUSR|S_IRGRP|S_IXGRP|S_IROTH|S_IXOTH

static int swapx( char*, int, int);

char *NICTutil_sub_string(
        char    *source,
        char    *dest,
        int delm
    )
{
    char    *s;
    char    *d;

    s = source;
    d = dest;
    while( 1 ) {
        if( *s == delm || *s == '\0' ) {
            *d = '\0';
            break;
        }
        *d = *s;
        d ++;
        s ++;
    }
    s ++;
    return( s );
}

int NICTutil_strnormcmp(
        char    *s,
        char    *d
    )
{
    while( 1 ) {
        if( *d == '*' ) {
            d ++;
            if( *d == '\0' ) {
                return( 0 );
            }
            while( 1 ) {
                if( *s == *d || *d == '*' || *d == '?' ) {
                    if( NICTutil_strnormcmp( s, d ) == 0 ) {
                        return( 0 );
                    }
                }
                s ++;
                if( *s == '\0' ) {
                    return( 1 );
                }
            }
        }
        else if( *d == '?' ) {
            d ++;
            s ++;
        }
        else {
            if( *s != *d ) {
                return( 1 );
            }
            if( *s == '\0' ) {
                return( 0 );
            }
            s ++;
            d ++;
        }
    }
}

char    *NICTutil_get_full_path(
        char    *out_path,
        char    *in_path
    )
{
    FILE    *fp;
    int i;
    char    *c;
    char    *d;
    char    buff[ BUFF_SIZE ];

    i = strlen( in_path ) - 1;
    while( 1 ) {
        if( in_path[ i  ] == '/' ) {
            in_path[ i ] = '\0';
            c = in_path;
            d = &( in_path[ i + 1 ] );
            break;
        }
        else if( i == 0 ) {
            c = (char *)".";
            d = in_path;
            break;
        }
        i --;
    }
    sprintf( buff, "cd %s;echo `pwd`", c );
    fp = (FILE *)popen( buff, "r" );
    if (fgets( buff, BUFF_SIZE, fp ) == NULL) {
      out_path = NULL;
    } else {
      buff[ strlen( buff ) - 1 ] = '\0';
      sprintf( out_path, "%s/%s", buff, d );
    }
    pclose( fp );
    return( out_path );
}

typedef struct _get_all_files_area  {
        FILE    *p;
        char    dir[ 500 ];
        char    file[ 500 ];
}   get_all_files_area;

char*   NICTutil_get_all_files(
        char    *dir,
        char    *ext,
        void    **area
    )
{
    char            buff[ 500 ];
    char            *c;
    int         i;
    get_all_files_area  *a;

    if( *area == NULL ) {
        *area = ( void * )calloc( 1, sizeof( get_all_files_area ) );
        a = ( get_all_files_area * )( *area );
//Windows�ܿ����ɲ�
#ifndef _WIN32
        sprintf( buff, "echo %s:;ls -R %s", dir, dir );
#else
        sprintf( buff, "echo %s:;dir /B /S %s", dir, dir );
#endif
        a->p = popen( buff, "r" );
        a->dir[ 0 ] = '\0';
    }
    else {
        a = ( get_all_files_area * )( *area );
    }
    while( 1 ) {
        if( fgets( buff, 500, a->p ) != buff ) {
            pclose( a->p );
            free( a );
            return( NULL );
        }
        c = buff;
        while( 1 ) {
            if( *c == '\n' ) {
                *c = '\0';
                break;
            }
            c ++;
        }
        i = strlen( buff );
        if( buff[ i - 1 ] == ':' ) {
            strcpy( a->dir, buff );
            a->dir[ strlen( buff ) - 1 ] = '\0';
            continue;
        }
        else if( ext == NULL ) {
            sprintf( a->file, "%s/%s", a->dir, buff );
        }
        else if( strcmp( &( buff[ i - strlen( ext ) ] ), ext ) == 0 ) {
            sprintf( a->file, "%s/%s", a->dir, buff );
        }
        else {
            continue;
        }
        return( a->file );
    }
}

int     NICTutil_freadx(
        char    *ptr,
        int     elsize,
        int     nread,
        FILE    *fp
    )
{
    if( fread( ptr, elsize, nread, fp ) != nread ) {
        return( -1 );
    }
    swapx( ptr, elsize, nread );
    return( nread );
}

int NICTutil_freadx2(char *ptr, int elsize, int nread, FILE *fp )
{
    if( fread( ptr, elsize, nread, fp ) != nread ) {
        return( -1 );
    }
    DECODEDATA( ptr, elsize * nread ) ;
    swapx( ptr, elsize, nread );
    return( nread );
}


int NICTutil_fwritex(
        char    *ptr,
        int elsize,
        int nwrite,
        FILE    *fp
    )
{
    swapx( ptr, elsize, nwrite );
    if( fwrite( ptr, elsize, nwrite, fp ) != nwrite ) {
        swapx( ptr, elsize, nwrite );
        return( -1 );
    }
    swapx( ptr, elsize, nwrite );
    return( nwrite );
}


static  int swapx(
        char    *ptr,
        int len,
        int num
    )
{
#if MACHINE_BYTEORDER!=NETWORK_BYTEORDER
    int i;

    for( i = 0; i < num; i ++ ) {
        if( len == sizeof( int ) ) {
            NICTutil_ConvertIntLittleEndian(
                ( void * )( ptr ) );
        }
        else if( len == sizeof( short ) ) {
            NICTutil_ConvertShortLittleEndian(
                ( void * )( ptr ) );
        }
        else if( len == sizeof( double ) ) {
            NICTutil_ConvertDoubleLittleEndian(
                ( void * )( ptr ) );
        }
        ptr += len;
    }

#endif

    return( 0 );
}

int NICTutil_create_dir(
        char    *dir
    )
{
    char    buff[ 1000 ];
    char    *c;

    strcpy(  buff, dir );
    c = buff;
    while( 1 ) {
        if( *c == '/' && c != buff ) {
            *c = '\0';
            if( mkdir( buff, MODE ) != 0 ) {
                if( errno != EEXIST ) {
                    return( 1 );
                }
            }
            *c = '/';
            c ++;
        }
        else if( *c == '\0' && c != buff ) {
            if( mkdir( buff, MODE ) != 0 ) {
                if( errno != EEXIST ) {
                    return( 1 );
                }
            }
            break;
        }
        else if( *c == '\0' ) {
            break;
        }
        else {
            c ++;
        }
    }
    return( 0 );
}

int NICTutil_ConvertFloatLittleEndian (
                  void *val
                  )
{
  typedef union {
    float  f;
    char   c[4];
  } float_char;

  register char  t;

  /* only 6 move of char !!! */
  t = ((float_char *)val)->c[0];
  ((float_char *)val)->c[0] = ((float_char *)val)->c[3];
  ((float_char *)val)->c[3] = t;
  t = ((float_char *)val)->c[1];
  ((float_char *)val)->c[1] = ((float_char *)val)->c[2];
  ((float_char *)val)->c[2] = t;

  return(0);
}

/*
   for conversion between HP-UX and OSF1
*/
int NICTutil_ConvertIntLittleEndian (
                  void *val
                  )
{
  typedef union {
    int  f;
    char   c[4];
  } int_char;

  register char  t;

/* a simpler possibility
   t = ((char *)val)[0]; */

  /* only 6 move of char !!! */
  t = ((int_char *)val)->c[0];
  ((int_char *)val)->c[0] = ((int_char *)val)->c[3];
  ((int_char *)val)->c[3] = t;
  t = ((int_char *)val)->c[1];
  ((int_char *)val)->c[1] = ((int_char *)val)->c[2];
  ((int_char *)val)->c[2] = t;

  return(0);
}


/*
   for conversion between HP-UX and OSF1
*/
int NICTutil_ConvertShortLittleEndian (
                  void *val
                  )
{
  typedef union {
    short f;
    char   c[2];
  } short_char;

  register char  t;

  t = ((short_char *)val)->c[0];
  ((short_char *)val)->c[0] = ((short_char *)val)->c[1];
  ((short_char *)val)->c[1] = t;

  return(0);
}


/*
   for conversion between HP-UX and OSF1
*/
int NICTutil_ConvertDoubleLittleEndian (
                  void *val
                  )
{
  typedef union {
    short f;
    char   c[8];
  } short_char;

  register char  t;

  t = ((short_char *)val)->c[0];
  ((short_char *)val)->c[0] = ((short_char *)val)->c[7];
  ((short_char *)val)->c[7] = t;
  t = ((short_char *)val)->c[1];
  ((short_char *)val)->c[1] = ((short_char *)val)->c[6];
  ((short_char *)val)->c[6] = t;
  t = ((short_char *)val)->c[2];
  ((short_char *)val)->c[2] = ((short_char *)val)->c[5];
  ((short_char *)val)->c[5] = t;
  t = ((short_char *)val)->c[3];
  ((short_char *)val)->c[3] = ((short_char *)val)->c[4];
  ((short_char *)val)->c[4] = t;

  return(0);
}
