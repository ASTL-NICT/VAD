﻿/*------------------------------------------------------------------------------
// Heap memory management Library.
//------------------------------------------------------------------------------
// Copyright (C) 2009 - 2016
//   National Institute of Information and Communications Technology.
//   All rights reserved.
//----------------------------------------------------------------------------*/


#include "NICTutil.h"

void *NICTutil_calloc(
  int nitems,          /* number of elements */
  int size             /* size of each element */
) {
  void * r = (void *) calloc (nitems, size);
  if (r == NULL) fprintf( stderr, "Can not calloc this many bytes: %d\n", nitems * size ) ;
  return r;
}

/* Call example: p=malloc(5);p=NICT_REALLOC(p,6);
   or            p=NULL;     p=NICT_REALLOC(p,6);  (please malloc here)
   But if you use malloc you may have pointer alignment problems. %WEAK%
   So, I use calloc(1,bigNumber), but then we may have memory inefficiency
   because it may be aligned on a boundary of bigNumber. %WEAK%
   */

void *NICTutil_realloc(                       /* return: the new pointer */
  void *pointer,     /* previous pointer */
  int size)        /* new size */
{
  void *r;
  if (pointer == NULL) r = (void *) calloc (1, (size_t)size);
  else                 r = (void *) realloc (pointer, (size_t)size);
  if (r == NULL) fprintf( stderr, "Can't realloc: size = %d\n", size );
  return r;
}

void NICTutil_free( void *pointer )
{
  /* %TODO% check that this pointer is valid.
     Can this be done in a System-independent way? */
  free( pointer );
}

/* NICTutil_calloc2d does not allocate contiguous memory for the matrix.  It
   first allocates a vector of pointers, then for each pointer it
   allocates a vector.  They may or may not be contiguous.
   I also do a trick: I allocate one extra in the vector of pointers,
   so that I can easily find the end (dimension a) in NICTutil_free2d. */

void **NICTutil_calloc2d(
	       int a          /* first index of the array */
             , int b        /* second index of the array (fast-moving) */
             , int c        /* size of each element */
             )
{
  int i;
  void ** p = (void **) NICTutil_calloc( a + 1 , sizeof(void *) );
  if (p == NULL) {
    fprintf( stderr, "NICTutil_calloc2d arg1=%d\n", a);
    return p;
  }
  for (i=0; i<a; i++) {
    p[i] = (void *) NICTutil_calloc( b, c );
    if (p[i] == NULL) fprintf( stderr,"NICTutil_calloc2d arg2=%d\n", b);
 }
  p[a] = NULL;   /* This is the null-termination on the vector of pointers */
  return p;
}

void NICTutil_free2d(void **p)   /* pointer to array allocated with NICTutil_calloc2d */
{
  int i = 0;
  for (i = 0; NULL != p[i]; i++) {
    free( p[i] );
  }
  free( (void *) p );
}

/* EOF */
