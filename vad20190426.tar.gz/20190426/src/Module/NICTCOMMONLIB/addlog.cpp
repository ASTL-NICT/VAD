﻿/*-----------------------------------------------------------------------------
 addlog function
-------------------------------------------------------------------------------
 Copyright (C) 2012 - 2016
   National Institute of Information and Communications Technology.
   All rights reserved.
-----------------------------------------------------------------------------*/

#include<cmath>

#include "addlog.h"

using namespace std;

const double LOG_ADDMIN=-log(-LOG_ZERO);

// 対数和の計算関数

double addlog(double x,double y){
  if(x<y){
    double tmp=x;
    x=y;
    y=tmp;
  }
  double diff=y-x;
  if(diff<LOG_ADDMIN){
    if(x<LOG_ZERO)return(LOG_ZERO);
    else return(x);
  }
  double z=exp(diff);
  return(x+log(1.0+z));
}
