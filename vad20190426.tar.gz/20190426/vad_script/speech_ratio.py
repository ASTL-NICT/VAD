#/bin/python

import sys, os, platform

py_ver = '.'.join(platform.python_version_tuple()[0:2])

ARG_NAME=["file_list"]
OPT_ARG_NAME="vad_result"

if py_ver == "2.7":
    import argparse
    def default_str(format_str=None): 
        if format_str is None:
            return "%(default)"
        else:
            return "%(default)." + format_str

    class ArgParser:
        def __init__(self, **kwargs):
            self.ap_ = argparse.ArgumentParser(**kwargs)
        def add_opt(self, *args, **kwargs):
            self.ap_.add_argument(*args, **kwargs)
        def parse(self, *args):
            for arg in ARG_NAME:
                self.ap_.add_argument(arg, metavar=arg.upper(),
                        help='The same file list used to obtain VAD result.')
            self.ap_.add_argument(
                    OPT_ARG_NAME, metavar=OPT_ARG_NAME.upper(), nargs='?',
                    help='VAD result file obtained with file list. (default: stdin)')
            return self.ap_.parse_args(*args)

elif py_ver == "2.6":
    import optparse
    def default_str(format_str):
        # ignoer format_str
        return "%default"

    class ArgParser:
        def __init__(self, **kwargs):
            self.ap_ = optparse.OptionParser(
                    usage="Usage: %prog [options] " \
                            + " ".join(ARG_NAME) \
                            + '[' + OPT_ARG_NAME + ']',
                    **kwargs)
        def add_opt(self, *args, **kwargs):
            self.ap_.add_option(*args, **kwargs)
        def parse(self, *args):
            (opts, arg_list) = self.ap_.parse_args(*args)
            if len(arg_list) < len(ARG_NAME):
                print "Error: ", len(arg_list), "args found, while", \
                        len(ARG_NAME), "args required, at least."
                sys.exit(1)
            for (aname, avalue) in zip(ARG_NAME, arg_list):
                setattr(opts, aname, avalue)
            # If arg_list is longer than ARG_NAME by one, it is the 
            # one and only optional argument.
            if len(arg_list) == len (ARG_NAME) + 1:
                setattr(opts, OPT_ARG_NAME, arg_list[-1])
            return opts
else:
    print "Error: python version", py_ver, "not supported."
    sys.exit(1)
        

def ParseConfig(args):
    CONFIG = dict()
    try:
        config_file = open(args.config)
    except:
        print "Error: Cannot open config", args.config
        raise

    for line in config_file:
        line = line.strip()
        if len(line) == 0 or line[0] == '#': continue
        field = line.split(':')
        # field[0] = module name
        # field[1] = "param_name = param_value"
        param_setting = field[1].split('=')
        if CONFIG.has_key(field[0]):
            CONFIG[field[0]][param_setting[0]] = param_setting[1]
        else:
            CONFIG[field[0]] = dict({param_setting[0]: param_setting[1]})
    return CONFIG

parser = ArgParser(
        description='Calculate speech length ratio in file');
parser.add_opt('-a', '--audio_format', dest='audio_format',
        choices=['w', 'r'], default='w', metavar='FORMAT',
        help='Format of audio files in file list. w = wav, r = raw(no header). \
                All files must be in the same format. (default: "' \
                + default_str("s") + '")')
parser.add_opt('-b', '--byte_per_sample', dest='precision',
        type=int, default=2, metavar='BYTE',
        help='Only 2 is supported by VAD, now, \
                while this script work with other values. \
                (default: ' + default_str("d") + ' byte)')
parser.add_opt('-c', '--channel', dest='channel',
        type=int, default=1, metavar='CH',
        help='Only 1 is supported by VAD, now, \
                while this script work with other values. \
                (default: ' + default_str("d") + ' ch)')
parser.add_opt('-q', '--frame_freq', dest='frame_freq',
        type=float, default=10.0, metavar='MSEC',
        help='frame frequency in msec. (default: '\
                + default_str("3f") + ' msec)');
parser.add_opt('-s', '--sample_rate', dest='sampling',
        type=int, default=16000, metavar='Hz',
        help='Only 16000 is supported by VAD, now, \
                while this script work with other values.\
                (default: ' + default_str("d") + ' Hz)')
parser.add_opt('-C', '--config', dest='config',
        #type=agparse.FileType(), default=None, metavar='CONFIG',
        default=None, metavar='CONFIG',
        help='SignalProcessingConfigFile in .ini file. NOT .ini file itself. \
                If -q and/or -s are used with -C option, those values are \
                replaced with the ones given in the config file.');
parser.add_opt('-E', '--exact', dest='exact_vad',
        action='store_true', default=False,
        help='Output VAD segment/duration without margin')
parser.add_opt('-S', '--show_segment', dest='show_segment', 
        action='store_true', default=False,
        help='Show VAD result, that is, speech segment(s). \
                This option must be used with -C option.')

args = parser.parse()
nOneSecByte = args.precision*args.sampling*args.channel

CONFIG = None
if args.show_segment:
    if args.config is None:
        print "Error: Need -C option to show results. See usage."
        parser.print_help()
        sys.exit(1)
    else:
        CONFIG = ParseConfig(args)
        args.frame_freq = float(CONFIG['NICTvad']['FrameShift'])
        args.sampling = float(CONFIG['NICTvad']['SamplingFrequency'])

if args.exact_vad:
    if args.config is None:
        print "Error: Need -C option for exact result. See usage."
        parser.print_help()
        sys.exit(1)

file_info = list();
file_list = open(args.file_list)
for full_path_filename in file_list:
    f = full_path_filename.strip();
    size = os.path.getsize(f)
    if args.audio_format == 'w': size -= 44
    file_info.append((f, (1000.0 * size) / nOneSecByte));
nFile = len(file_info)

if CONFIG is not None and args.exact_vad is True:
    st_offset = float(CONFIG['NICTvad']['PrerollLength']) * args.frame_freq
    ed_offset = float(CONFIG['NICTvad']['AfterrollLength']) * args.frame_freq
else:
    st_offset = 0.0
    ed_offset = 0.0

speech_seg = list()
frame_count = 0
in_speech = False
num = 0
if hasattr(args, "vad_result") and args.vad_result is not None:
    vad_result = open(args.vad_result)
else:
    vad_result = sys.stdin

for line in vad_result:
    if not line.startswith("==="):
        frame_count+=1
        continue

    ln = line.strip()[3:]
    if ln == "new file":
        in_speech = False
        sum_dur = 0
        frame_count = 0
        speech_msec = 0.0
        del speech_seg[:]
    elif ln == "speech start":
        st = frame_count * args.frame_freq + st_offset
        in_speech = True
    elif ln == "speech end":
        ed = frame_count * args.frame_freq - ed_offset
        speech_seg.append((st, ed))
        speech_msec = ed - st
        sum_dur += speech_msec
        in_speech = False
    elif ln == "EOF":
        filename, file_msec = file_info[num]
        if num > nFile:
            print "%s Error(no info)" % filename
        else:
            ratio = 100.0 * sum_dur / file_msec
            if file_msec > 0:
                print '%s %d msec speech in file of length %d msec. (%.2f%%)' \
                        % (filename, sum_dur, file_msec, ratio)
            else:
                print '%s Error(empty)' % (filename)
            
            file_info[num] = (filename, file_msec, speech_msec)
            num += 1;

        if args.show_segment:
            def print_seg(seg, N=1, ID=1):
                (s, e) = seg
                print "  #VAD [%d/%d]: %.1f - %.1f" % (ID, N, s, e)
            N = len(speech_seg)
            if N > 1:
                for n, seg in enumerate(speech_seg):
                    print_seg(seg, N, n+1)
            elif N == 1:
                print_seg(speech_seg[0], N)


if num == 0:
    print "Error: No VAD result input."
elif num < nFile:
    print "Error: Result file has less results than the files in file list."
elif num > nFile:
    print "Error: Result file has more results than the files in file list."
