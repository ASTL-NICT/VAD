VADスクリプト(vad_flist.bash)マニュアル

NICTmmcvを利用した音声区間検出ツールvad_flist.bashについて説明します。

[1] 機能
　VADスクリプトは、音声ファイル名が記載されたVAD対象ファイルリストを
　引数に実行すると、各音声ファイルの音声始終端位置、および、
　ファイルに占める発声区間長の比率を算出します。


[2] 処理フロー
  NICTmmcvは所定のバイナリ形式で音声イベント（音声開始の検知、音声
  終了の検知等）を時系列で出力します。音声開始時刻／終了時刻などの
  情報を抽出するためには、このイベント系列を解釈しなければなりません。

  vad_flist.bashは、NICTmmcv、NICTmmcvが出力する(バイナリ)音声イベント
  をテキスト化するframesync2txtと、音声イベントの時系列を時刻情報に
  変換するspeech_ratio.pyからなり、以下のような処理によってVADの結果を
  出力します。

  NICTmmcvは一定時間分の音声を処理するごとに音声イベントを出力します。
  したがって、イベントの数からそのイベントが発生した、音声データ先頭
  からの相対的な時刻が取得できます。
  続くframesyncはNICTmmcvの出力するバイナリデータのヘッダに書かれた
  イベントIDを対応する文字列に変換します。
  最後にspeech_ratio.pyがテキスト化されたイベント時系列から音声開始
  や終了を検知した（データ先頭からの相対）時刻を計算し、VAD結果を
  出力します。


[3] 使い方
  1. 準備
    (0) VADに必要な次の4個のファイルが存在することを確認してください。
          1. model/gmm512_MMSE.20091201  
          2. model/lab
          3. model/meanfile26
          4. model/sil

    (1) srcでコンパイルしたNICTmmcv, framesync2txtをこのディレクトリに
        コピーする、もしくはシンボリックリンクを張ってください。

    (2) NICTmmcv_flist.ini, config_frontファイル内に設定されたファイル
        パス(特に上述のmodelディレクトリ)や設定値を必要に応じで修正して
        ください。なお、多くの数値パラメータは変更不可であり、それら
        を変更するとNICTmmcvが正しく動作しない可能性があるので、注意
        してください。（doc/ini_manual.txtを参照してください。）

    (3) vad_flist.bash内で使われているspeech_ratio.pyはpython2.6および
        2.7で動作します。


  2. VAD対象ファイルリストの作成
    VAD対象ファイルをフルパスで記述したテキストファイルを作成します。
    １行につき１ファイル名を記述します。
    なお、本VADスクリプトでは、wav形式のみが可能です。(.iniファイルを設定
    rawファイルに変更することも可能ですが、説明は省略します。）

  3. VADの実行
    １で作成したVAD対象ファイルリストを引数として下記コマンドを実行
    します。結果は標準出力に出力します。必要ならば出力結果をファイル
    にリダイレクトしてください。

      % ${YOUR_PATH}/vad_flist.bash [-E] (VAD対象ファイルリスト) \
          [ > (出力ファイル) ]
      　
    なお、オプション -E については、下記<*4>を参照してください。


[4] VAD結果の出力フォーマット
  処理中に何らかのエラーがあれば、結果が全く表示されないか、結果の中に
  "Error"と表示されます。
  VADが正常に行われると、標準出力、あるいは結果ファイルに以下の形式で
  各ファイルのVAD結果が出力されます。なお、時間の単位はすべてミリ秒
  (msec)です。
  
    <ファイル名> <Ls> msec speech in file of length <Lf> msec (<R>%)
      #VAD [1/<N>]: <S1> - <E1>
      #VAD [2/<N>]: <S2> - <E2>
      ...         ... ...
      #VAD [<N>/<N>]: <SN> - <EN>

      <Ls>: 検出した音声区間の総時間( = <E1>-<S1> + ... + <EN>-<SN>)
      <Lf>: 音声ファイル中の音声データ時間長
      <R>:  ファイル中の音声の割合( = 100 x Ls/Lf)
      <N>:　検出した音声区間の個数<*1>
      <Sn>: n番目の音声区間の開始時刻<*2>
      <En>: n番目の音声区間の終了時刻<*3>

      <*1> １ファイルに１発声しか存在しない場合でも、複数の音声区間を
           検出する場合があります。

      <*2> VADの前マージン分だけ実際の検出時刻より前の時刻<*4>
           Sn =  NICTmmcvが検出した始端時刻 - 前マージン
           前マージン = NICTvad:PrerollLength 
                                * NICTvad:FrameShift ミリ秒 <*5>

      <*3> VADの後マージン分だけ実際の検出時刻より後の時刻<*4>
           En = NICTmmcvが検出した終端時刻 - 後マージン
           後マージン = NICTvad:AfterrollLength
                                * NICTvad:FrameShift ミリ秒 <*5>

      <*4> 前後のマージンを含めない時刻を出力したい場合には、
           vad_flist.bashにオプション"-E"をつけて実行してください。

      <*5> NICTvad:PrerollLength等は、ファイル"config_front"の設定値

  ------------------------------------------------------------------
    VAD結果の表示例
  ------------------------------------------------------------------
    001.wav 4140 msec speech in file of length 5472 msec. (75.66%)
      #VAD [1/2]: 340.0 - 1810.0
      #VAD [2/2]: 2480.0 - 5150.0
    002.wav 1470 msec speech in file of length 2128 msec. (69.08%)
      #VAD [1/1]: 340.0 - 1810.0
    003.wav 2250 msec speech in file of length 2624 msec. (85.75%)
      #VAD [1/1]: 370.0 - 2620.0ば
    004.wav 2080 msec speech in file of length 2768 msec. (75.14%)
      #VAD [1/1]: 380.0 - 2460.0
    005.wav 2860 msec speech in file of length 3696 msec. (77.38%)
      #VAD [1/1]: 340.0 - 3200.0
    006.wav 2660 msec speech in file of length 3344 msec. (79.55%)
      #VAD [1/1]: 360.0 - 3020.0
  ------------------------------------------------------------------

[5] 実行例 
  garinko.lstを与えた時の実行結果を示します。

  (1) -Eなし
    % bash vad_flist.bash garinko.lst
    garinko.wav 2840 msec speech in file of length 5500 msec. (51.64%)
      #VAD [1/1]: 1210.0 - 4050.0

  (2) -Eあり
    % bash vad_flist.bash -E garinko.lst
    garinko.wav 2240 msec speech in file of length 5500 msec. (40.73%)
      #VAD [1/1]: 1510.0 - 3750.0


以上
